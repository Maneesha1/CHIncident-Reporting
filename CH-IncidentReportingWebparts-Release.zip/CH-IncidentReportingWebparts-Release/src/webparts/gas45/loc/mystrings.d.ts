declare interface IGas45WebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'Gas45WebPartStrings' {
  const strings: IGas45WebPartStrings;
  export = strings;
}

import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import * as strings from 'Gas45WebPartStrings';
import Gas45Event from './components/Gas45Event';
//import PscElectricEvent from './components/PscElectricEvent';
import { IGas45Props } from './components/IGas45Props';
import SPHttpService from '../../services/SPHttpService';
import HttpService from '../../services/HttpService';
import PnPService from '../../services/PnPService';
import * as Consts from '../../common/constants';


export interface IGas45WebPartProps {
  description: string;
  itemId: number;
  formMode: Consts.FORMMODE;
}

export default class Gas45WebPart extends BaseClientSideWebPart<IGas45WebPartProps> {

  protected onInit(): Promise<void> {
    const queryString: string = window.location.search;
    if (queryString) {
      const urlParams = new URLSearchParams(queryString.toUpperCase());
      if (urlParams.get('REPID')) {
        this.properties.itemId = Number(urlParams.get('REPID'));
        this.properties.formMode = Consts.FORMMODE.Edit;
      }
      else {
        this.properties.formMode = Consts.FORMMODE.New;
      }
    }
    else {
      this.properties.formMode = Consts.FORMMODE.New;
    }

    SPHttpService.init(this.context.spHttpClient, this.context.pageContext.site.absoluteUrl);
    HttpService.init(this.context.httpClient, this.context.pageContext.site.absoluteUrl);
    PnPService.init(this.context);

    return super.onInit();
  }


  public render(): void {
    const element: React.ReactElement<IGas45Props> = React.createElement(
      Gas45Event,
      {
        siteUrl: this.context.pageContext.site.absoluteUrl,
        context: this.context,
        currentUser: this.context.pageContext.user,
        httpClnt: this.context.httpClient,
        itemId: this.properties.itemId,
        formMode: this.properties.formMode,
       description: this.properties.description
      }
    );

    ReactDom.render(element, this.domElement);
  }






  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}

import { HttpClient, SPHttpClient } from '@microsoft/sp-http';
import { SPUser } from '@microsoft/sp-page-context';
import { BaseWebPartContext } from '@microsoft/sp-webpart-base';
import { IItem } from '@pnp/sp/items';
import * as Consts from '../../../common/constants';

export interface ISpillsreportProps {
  siteUrl: string;
  context: BaseWebPartContext;
  currentUser: SPUser;
  httpClnt: HttpClient;
  itemId: number;
  formMode: Consts.FORMMODE;
}


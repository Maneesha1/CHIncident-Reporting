import * as React from 'react';
import styles from './Spillsreport.module.scss';
import { ISpillsreportProps } from './ISpillsreportProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { TextField, Dropdown, IDropdownOption, DefaultButton, PrimaryButton, CommandBarButton, TooltipHost, ChoiceGroup, IChoiceGroupOption } from 'office-ui-fabric-react';
import { FontIcon } from 'office-ui-fabric-react/lib/Icon';
import { DateTimePicker, DateConvention, TimeConvention, TimeDisplayControlType } from '@pnp/spfx-controls-react/lib/DateTimePicker';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import ListService from '../../../services/ListService';
import PnPService from '../../../services/PnPService';
import HttpService from "../../../services/HttpService";
import SPHttpService from "../../../services/SPHttpService";
import * as Consts from '../../../common/constants';
import { IMasterList } from '../../../models/IMasterList';
import { IFileInfo } from '../../../models/IFileInfo';
import { ISpillsreportState } from './ISpillsreportState';
import { IUserProfile } from '../../../models/IUserProfile';
import { SubmitDialog } from "../../../common/components/SubmitDialog";
import { ConfirmDialog } from "../../../common/components/ConfirmDialog";
import PDFService from "../../../services/PDFService";
import WordService from "../../../services/WordService";
import { SendEmailDialog } from '../../../common/components/SendEmailDialog';


import Utilities from "../../../services/Utilities";
export default class Spillsreport extends React.Component<ISpillsreportProps, ISpillsreportState> {

  private fileAttachRef;
  private isAdmin: boolean = false;
  private isContributor: boolean = false;
  private currentUserId: number;
  private attachments: string[] = [];

  constructor(props: ISpillsreportProps, state: ISpillsreportState) {
    super(props);
    this.state = {
      footer: null,
      masterListData: null,
      statusDialogText: null,
      confirmDialogText: null,
      onConfirmDialog: null,
      errorMessage: null,
      showStatusDialog: false,
      showEmailDialog: false,
      submitDialogTitle: "Success",
      submitDialogText: null,
      statusDialogTitle: null,
      submittedDate: null,
      isLatestVersion: false,
      showUnlockBtn: false,
      reportJson: null,
      showSubmitDialog: false,
      showSaveBtn: false,
      showSubmitBtn: false,
      incReportStatus: null,
      selHazardtoHuman: null,
      incVersion: null,
      SpillOccurredDt: null,
      AddressIncidentOccurred: null,
      item: null,
      showConfirmDialog: false,
      utilityCompanyIncidentNumber: null,
      utilityId: null,
      utilityName: null,
      selPersonnelReportingId: null,
      selPersonnelReportingEMail: null,
      selPersonnelReportingName: null,
      personnelReportingEmail: null,
      personnelReportingPhone: null,
      SpillReportedDt: null,
      TD: null,
      selMaterialTypeSpilled: null,
      MaterialTypeSpilled: [],
      selReasonforSpill: null,
      ReasonforSpill: [],
      SpillQuantity: null,

      selspillQuantityUnit: null,
      SpillQuantityUnit: [],
      selPCBDetermination: null,
      PCBDetermination: [],
      PCMDeterminationMEthod: [],
      selPCMDeterminationMEthod: null,
      PCMDeterminationComments: null,
      TransformCapitalMonthYear: null,
      LatitudeEquipmentImpacted: null,
      LongitudeEquipmentImpacted: null,
      TownLocalityIncidentOccurred: null,

      CountyIncidentOccurred: [],
      selCountyIncidentOccurred: null,
      FacilityType: [],
      selFacilityType: null,
      SpillDescription: null,
      UpdatedSpillDesc: null,
      EmergencyMeasure: null,
      RecoverdMaterialQty: null,
      HazardtoHuman: [],
      AgencyNotified: null,
      CHGEForemanonSite: null,
      /* AgencyNotifiedDt: null, */
      CHGEForemanonSitePhone: null,
      EnvironmentalSOC: [],
      selEnvironmentalSOC: null,
      EnvironmentalCleanupContractor: [],
      selEnvironmentalCleanupContractor: null,

      ContractorOnSiteDt: null,
      EnvironmentalComments: null,
      DecSpfiill: null,
      attachmentFiles: [],
      tooltips: null,
      PolePadVehicleNum: null,
      OperatingDistricts: [],
      selOperatingDistrict: null,
      TransformerNum: null,
      InjuriesSustained: [],
      selInjuriesSustained: null,
      ClearOfStreamsPonds: null
    };
    this.fileAttachRef = React.createRef();
  }

  /** Event Handlers **/
  private onAttchSelect(e) {
    e.preventDefault();
    this.fileAttachRef.current.click();
  }
  /* Attachment file change event */
  private onAttachmentChange(event) {
    let resultFile = event.target.files;
    let fileInfos: IFileInfo[] = [];
    let promArr: Promise<any>[] = [];

    for (var i = 0; i < resultFile.length; i++) {
      var file = resultFile[i];
      var reader = new FileReader();
      promArr.push(new Promise((resolve, reject) => {
        reader.onload = ((fileToRead) => {
          return (e) => {
            //Push the converted file into array
            fileInfos.push({
              "name": fileToRead.name,
              "content": e.target.result
            });
            resolve();
          };
        })(file);
        reader.readAsArrayBuffer(file);
      }));
    }
    Promise.all(promArr).then(() => {
      this.setState({
        attachmentFiles: [...this.state.attachmentFiles, ...fileInfos]
      });
    });
  }

  private onCancelClick() {
    window.location.href = this.props.siteUrl;
  }

  private onDeleteAttachment(event, index) {
    let attachments = this.state.attachmentFiles;
    attachments.splice(index, 1);
    this.setState({
      attachmentFiles: attachments
    });
  }

  private onDropDownChange(event, selItem: IDropdownOption) {
    this.setState({
      ...this.state,
      [event.target.id]: selItem.text,
    });
  }

  private onExportPDFClick() {
    PDFService.ExportToPDFFromHTML(this.state.item["UtilityCompanyIncidentNumber"], this.state.item["Title"], this.state.reportJson);
  }

  /* export to word */
  private onExportWordClick() {
    WordService.generateDocument(this.state.item["UtilityCompanyIncidentNumber"], this.state.item["Title"], this.state.reportJson);
  }

  /* export to word */
  private onPrintlick() {
    Utilities.printHtml(this.state.item["UtilityCompanyIncidentNumber"], this.state.item["Title"], this.state.reportJson);
  }

  /* Get latitude and longitude for given address */
  private async onGetLatLongClick() {
    let addressParts: string[] = [];

    if (this.state.AddressIncidentOccurred) {
      addressParts.push(this.state.AddressIncidentOccurred);
    }
    if (this.state.TownLocalityIncidentOccurred) {
      addressParts.push(this.state.TownLocalityIncidentOccurred);
    }
    if (this.state.selCountyIncidentOccurred) {
      addressParts.push(this.state.selCountyIncidentOccurred);
    }

    const resp = await HttpService.GetLatLongFromAddress(addressParts.join());
    const resJson = await resp.json();
    if (resJson && resJson.resourceSets.length > 0) {
      this.setState({
        LatitudeEquipmentImpacted: resJson.resourceSets[0].resources[0].point.coordinates[0].toString(),
        LongitudeEquipmentImpacted: resJson.resourceSets[0].resources[0].point.coordinates[1].toString()
      });
    }
  }

  private onOccurDateChange(value) {
    this.setState(
      {
        ...this.state,
        SpillOccurredDt: value
      }
    );
  }

  /* private onAgencyNotifiedDateChange(value) {
    this.setState(
      {
        ...this.state,
        AgencyNotifiedDt: value
      }
    );
  } */



  private onContrOnSiteDateChange(value) {
    this.setState(
      {
        ...this.state,
        ContractorOnSiteDt: value
      }
    );
  }

  private onPeoplePickerChange(items: any[]) {
    if (items.length > 0) {
      PnPService.getUserProfileProperties(items[0].loginName).then((userProps: IUserProfile) => {
        this.setState({
          selPersonnelReportingId: items[0].id,
          selPersonnelReportingEMail: userProps.WorkEmail,
          personnelReportingEmail: userProps.WorkEmail,
          personnelReportingPhone: userProps.WorkPhone
        });
      });
    }
    else {
      this.setState({
        selPersonnelReportingId: null,
        selPersonnelReportingEMail: null,
        personnelReportingEmail: null,
        personnelReportingPhone: null
      });
    }
  }

  private onTextChange(event) {
    const value = event.target.value;
    this.setState(
      {
        ...this.state,
        [event.target.name]: value
      }
    );
  }

  private onUtilityRepDateChange(value) {
    this.setState(
      {
        ...this.state,
        SpillReportedDt: value
      }
    );
  }

  private onTransfCapDateChange(value) {
    this.setState(
      {
        ...this.state,
        TransformCapitalMonthYear: value ? ("0" + (value.getMonth() + 1)).slice(-2) + "/" + value.getFullYear() : null
      }
    );
  }

  private onChoiceChange(ev: React.FormEvent<HTMLElement>, option: IChoiceGroupOption) {
    this.setState({
      ClearOfStreamsPonds: option.key == "Yes" ? true : false
    });
  }

  /**Helper Functions **/
  private bindAttachmentsFromList(resultFile) {
    let fileInfos: IFileInfo[] = [];
    let promArr: Promise<any>[] = [];

    for (var i = 0; i < resultFile.length; i++) {
      var attFile = resultFile[i];
      ((file) => {
        promArr.push(new Promise((resolve, reject) => {
          fetch(Consts.SITEURLS.ROOTSITE + file.ServerRelativeUrl).then(e => {
            let content = e.arrayBuffer();
            content.then(c => {
              fileInfos.push({
                "name": file.FileName,
                "content": c,
                "url": Consts.SITEURLS.ROOTSITE + file.ServerRelativeUrl
              });
              resolve();
            });
          });
        }));
      })(attFile);
    }

    Promise.all(promArr).then(() => {
      this.setState({
        attachmentFiles: fileInfos
      });
    });
  }

  private getDropDownOptions(items: IMasterList[], category: string, removeDuplicates: boolean = false, key: string = "", multiselect: boolean = false): IDropdownOption[] {
    let values: any[] = items.filter(item => item.Category == category);
    if (removeDuplicates) {
      values = this.removeDuplicatesFromArray(values, key);
    }
    let ddlOptions: IDropdownOption[] = [];
    if (!multiselect) {
      ddlOptions.push({ key: "", text: "" });
    }
    values.map(item => ddlOptions.push({
      key: item.SubCategory, text: item.SubCategory
    }));
    ddlOptions.sort((a, b) => a.text.localeCompare(b.text));
    return ddlOptions;
  }

  private async loadReportData() {
    let allowSave: boolean = false;
    let allowSubmit: boolean = false;
    let allowUnlock: boolean = false;
    let submittedDt: Date = null;

    PnPService.getItemById(Consts.LISTTITLES.SPL, this.props.itemId, Consts.SELECTFIELDS.SPL, Consts.EXPANDFIELDS.SPL).then((item) => {

      if (item["Attachments"] == true) {
        item["AttachmentFiles"].forEach(file => {
          console.log(`${file.FileName}-${file.FileNameAsPath}-${file.ServerRelativePath}-${file.ServerRelativeUrl}`);
          this.attachments.push(file.FileName);
        });
        this.bindAttachmentsFromList(item["AttachmentFiles"]);
      }

      /* check save & submit conditions */
      if (this.isAdmin || this.isContributor) {
        /*Allow editing if it is a draft request */
        if (item[Consts.COMMONFIELDS.IncReportStatus] == Consts.INCSTATUS.Saved) {
          allowSave = true;
          allowSubmit = true;
        }
        /*Allow editing on latest versions of submitted request */
        else if (item[Consts.COMMONFIELDS.IncReportStatus] == Consts.INCSTATUS.Submitted && item[Consts.COMMONFIELDS.IsLatestVersion]) {

          if (item[Consts.COMMONFIELDS.SubmittedDate]) {

            submittedDt = new Date(item[Consts.COMMONFIELDS.SubmittedDate]);
            let elapsedTime = (new Date().getTime() - submittedDt.getTime()) / (1000 * 60 * 60);

            /*Allow editing within specified hours or if admin unlocked form */
            if (elapsedTime <= Consts.SpillreportEditHours || item[Consts.COMMONFIELDS.LockStatus] == Consts.LOCKSTATUS.UNLOCKED) {
              allowSave = true;
              allowSubmit = true;
            }

            /*Allow unlock beyond specified time if user is admin */
            if (elapsedTime > Consts.SpillreportEditHours && this.isAdmin && item[Consts.COMMONFIELDS.LockStatus] != Consts.LOCKSTATUS.UNLOCKED) {
              allowUnlock = true;
            }
          }
        }
      }

      /* Build HTML Table for Export to PDF, WORD and Send Mail */
      let repTable = Utilities.buildItemHTMLTable(item, Consts.SELECTFIELDS.SPL);

      this.setState({
        item: item,
        reportJson: repTable,
        utilityCompanyIncidentNumber: item[Consts.SPLFIELDS.UtilityCompanyIncidentNumber],
        utilityId: item[Consts.SPLFIELDS.UtilityId],
        utilityName: item[Consts.SPLFIELDS.UtilityName],
        selPersonnelReportingId: item[Consts.SPLFIELDS.UtilityPersonnelReportingId],
        selPersonnelReportingEMail: item[Consts.SPLFIELDS.UtilityPersonnelReporting] ? item[Consts.SPLFIELDS.UtilityPersonnelReporting]["EMail"] : null,
        selPersonnelReportingName: item[Consts.SPLFIELDS.UtilityPersonnelReporting] ? item[Consts.SPLFIELDS.UtilityPersonnelReporting]["Title"] : null,
        personnelReportingEmail: item[Consts.SPLFIELDS.UtilityPersonnelEmail],
        personnelReportingPhone: item[Consts.SPLFIELDS.UtilityPersonnelPhone],
        SpillReportedDt: item[Consts.SPLFIELDS.SpillReportedDt] ? new Date(item[Consts.SPLFIELDS.SpillReportedDt]) : null,
        SpillOccurredDt: item[Consts.SPLFIELDS.SpillOccurredDt] ? new Date(item[Consts.SPLFIELDS.SpillOccurredDt]) : null,
        TD: item[Consts.SPLFIELDS.TD],
        selMaterialTypeSpilled: item[Consts.SPLFIELDS.MaterialTypeSpilled],
        selReasonforSpill: item[Consts.SPLFIELDS.ReasonForSpill],
        SpillQuantity: item[Consts.SPLFIELDS.SpillQuantity],
        selspillQuantityUnit: item[Consts.SPLFIELDS.SpillQuantityUnit],
        selPCBDetermination: item[Consts.SPLFIELDS.PCBDetermination],
        selPCMDeterminationMEthod: item[Consts.SPLFIELDS.PCMDeterminationMEthod],
        PCMDeterminationComments: item[Consts.SPLFIELDS.PCMDeterminationComments],
        TransformCapitalMonthYear: item[Consts.SPLFIELDS.TransformCapitalMonthYear],
        AddressIncidentOccurred: item[Consts.SPLFIELDS.AddressIncidentOccurred],
        LatitudeEquipmentImpacted: item[Consts.SPLFIELDS.LatitudeEquipmentImpacted],
        LongitudeEquipmentImpacted: item[Consts.SPLFIELDS.LongitudeEquipmentImpacted],
        TownLocalityIncidentOccurred: item[Consts.SPLFIELDS.TownLocalityIncidentOccurred],
        selCountyIncidentOccurred: item[Consts.SPLFIELDS.CountyIncidentOccurred],
        selFacilityType: item[Consts.SPLFIELDS.FacilityType],
        SpillDescription: item[Consts.SPLFIELDS.SpillDescription],
        UpdatedSpillDesc: item[Consts.SPLFIELDS.UpdatedSpillDesc],
        EmergencyMeasure: item[Consts.SPLFIELDS.EmergencyMeasure],
        RecoverdMaterialQty: item[Consts.SPLFIELDS.RecoverdMaterialQty],

        selHazardtoHuman: item[Consts.SPLFIELDS.HazardtoHuman],
        AgencyNotified: item[Consts.SPLFIELDS.AgencyNotified],
        CHGEForemanonSite: item[Consts.SPLFIELDS.CHGEForemanonSite],
        /* AgencyNotifiedDt: item[Consts.SPLFIELDS.AgencyNotifiedDt] ? new Date(item[Consts.SPLFIELDS.AgencyNotifiedDt]) : null, */

        CHGEForemanonSitePhone: item[Consts.SPLFIELDS.CHGEForemanonSitePhone],
        selEnvironmentalSOC: item[Consts.SPLFIELDS.EnvironmentalSOC],
        selEnvironmentalCleanupContractor: item[Consts.SPLFIELDS.EnvironmentalCleanupContractor],

        ContractorOnSiteDt: item[Consts.SPLFIELDS.ContractorOnSiteDt] ? new Date(item[Consts.SPLFIELDS.ContractorOnSiteDt]) : null,

        EnvironmentalComments: item[Consts.SPLFIELDS.EnvironmentalComments],
        DecSpfiill: item[Consts.SPLFIELDS.DecSpfiill],

        PolePadVehicleNum: item[Consts.SPLFIELDS.PolePadVehicleNumber],
        selOperatingDistrict: item[Consts.SPLFIELDS.OperatingDistrict],
        selInjuriesSustained: item[Consts.SPLFIELDS.InjuriesSustained],
        TransformerNum: item[Consts.SPLFIELDS.TransformerNum],
        ClearOfStreamsPonds: item[Consts.SPLFIELDS.ClearofStreamsPonds],

        incVersion: item[Consts.SPLFIELDS.IncVersion],
        submittedDate: submittedDt,
        isLatestVersion: item[Consts.SPLFIELDS.IsLatestVersion],
        incReportStatus: item[Consts.SPLFIELDS.IncReportStatus],
        showSaveBtn: allowSave,
        showSubmitBtn: allowSubmit,
        showUnlockBtn: allowUnlock
      });
    }).catch(err => {
      console.log(err);
    });
  }

  private removeDuplicatesFromArray(arr: any[], key: string): any[] {
    return arr.reduce((accumulator, currentValue) => {
      const value = currentValue[key];
      if (!accumulator.some(item => item[key] === value)) {
        accumulator.push(currentValue);
      }
      return accumulator;
    }, []);
  }

  private saveIncident() {
    let incidentNumber: string;
    let url: string;

    if (this.props.formMode == Consts.FORMMODE.New) {
      let dt: Date = new Date();
      let year = dt.getFullYear();
      let month = ("0" + (dt.getMonth() + 1)).slice(-2);
      let date = ("0" + dt.getDate()).slice(-2);
      incidentNumber = `${Consts.REPORTCODES.SPL}-${year}${month}${date}-Draft`;
    }
    else if (this.props.formMode == Consts.FORMMODE.Edit) {
      incidentNumber = this.state.utilityCompanyIncidentNumber;
    }

    let body: string = JSON.stringify({
      '__metadata': {
        'type': Consts.LISTITEMENTTYPES.SPL
      },
      'Title': Consts.REPORTNAMES.SPL,
      [Consts.SPLFIELDS.UtilityCompanyIncidentNumber]: incidentNumber,
      [Consts.SPLFIELDS.UtilityId]: Consts.UtilityId,
      [Consts.SPLFIELDS.UtilityName]: Consts.UtilityName,
      [Consts.SPLFIELDS.UtilityPersonnelReportingId]: this.state.selPersonnelReportingId,
      [Consts.SPLFIELDS.UtilityPersonnelEmail]: this.state.personnelReportingEmail,
      [Consts.SPLFIELDS.UtilityPersonnelPhone]: this.state.personnelReportingPhone,
      [Consts.SPLFIELDS.SpillReportedDt]: this.state.SpillReportedDt,

      [Consts.SPLFIELDS.SpillOccurredDt]: this.state.SpillOccurredDt,
      [Consts.SPLFIELDS.TD]: this.state.TD,
      [Consts.SPLFIELDS.MaterialTypeSpilled]: this.state.selMaterialTypeSpilled,
      [Consts.SPLFIELDS.ReasonForSpill]: this.state.selReasonforSpill,
      [Consts.SPLFIELDS.SpillQuantity]: this.state.SpillQuantity,
      [Consts.SPLFIELDS.SpillQuantityUnit]: this.state.selspillQuantityUnit,
      [Consts.SPLFIELDS.PCBDetermination]: this.state.selPCBDetermination,
      [Consts.SPLFIELDS.PCMDeterminationMEthod]: this.state.selPCMDeterminationMEthod,
      [Consts.SPLFIELDS.PCMDeterminationComments]: this.state.PCMDeterminationComments,
      [Consts.SPLFIELDS.LatitudeEquipmentImpacted]: this.state.LatitudeEquipmentImpacted,
      [Consts.SPLFIELDS.LongitudeEquipmentImpacted]: this.state.LongitudeEquipmentImpacted,
      [Consts.SPLFIELDS.TownLocalityIncidentOccurred]: this.state.TownLocalityIncidentOccurred,
      [Consts.SPLFIELDS.CountyIncidentOccurred]: this.state.selCountyIncidentOccurred,
      [Consts.SPLFIELDS.FacilityType]: this.state.selFacilityType,
      [Consts.SPLFIELDS.SpillDescription]: this.state.SpillDescription,
      [Consts.SPLFIELDS.UpdatedSpillDesc]: this.state.UpdatedSpillDesc,
      [Consts.SPLFIELDS.EmergencyMeasure]: this.state.EmergencyMeasure,
      [Consts.SPLFIELDS.RecoverdMaterialQty]: this.state.RecoverdMaterialQty,
      [Consts.SPLFIELDS.HazardtoHuman]: this.state.selHazardtoHuman,
      [Consts.SPLFIELDS.AgencyNotified]: this.state.AgencyNotified,
      [Consts.SPLFIELDS.CHGEForemanonSite]: this.state.CHGEForemanonSite,
      /* [Consts.SPLFIELDS.AgencyNotifiedDt]: this.state.AgencyNotifiedDt, */
      [Consts.SPLFIELDS.CHGEForemanonSitePhone]: this.state.CHGEForemanonSitePhone,
      [Consts.SPLFIELDS.EnvironmentalSOC]: this.state.selEnvironmentalSOC,
      [Consts.SPLFIELDS.EnvironmentalCleanupContractor]: this.state.selEnvironmentalCleanupContractor,
      [Consts.SPLFIELDS.ContractorOnSiteDt]: this.state.ContractorOnSiteDt,
      [Consts.SPLFIELDS.EnvironmentalComments]: this.state.EnvironmentalComments,
      [Consts.SPLFIELDS.DecSpfiill]: this.state.DecSpfiill,
      [Consts.SPLFIELDS.AddressIncidentOccurred]: this.state.AddressIncidentOccurred,
      [Consts.SPLFIELDS.TransformCapitalMonthYear]: this.state.TransformCapitalMonthYear,
      [Consts.SPLFIELDS.PolePadVehicleNumber]: this.state.PolePadVehicleNum,
      [Consts.SPLFIELDS.OperatingDistrict]: this.state.selOperatingDistrict,
      [Consts.SPLFIELDS.InjuriesSustained]: this.state.selInjuriesSustained,
      [Consts.SPLFIELDS.TransformerNum]: this.state.TransformerNum,
      [Consts.SPLFIELDS.ClearofStreamsPonds]: this.state.ClearOfStreamsPonds,
      [Consts.COMMONFIELDS.IncVersion]: Utilities.getNextMinorVersion(this.state.incVersion),
      [Consts.COMMONFIELDS.IncReportStatus]: Consts.INCSTATUS.Saved,
      [Consts.COMMONFIELDS.SubmittedDate]: new Date(),
      [Consts.COMMONFIELDS.LastEditedById]: this.currentUserId
    });

    /* if creating new incident or creating a new version of a submitted incident*/
    if (this.props.formMode == Consts.FORMMODE.New || this.state.incReportStatus == Consts.INCSTATUS.Submitted) {
      url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.SPL}')/items`;

      /* create list item */
      SPHttpService.Post(url, body).then((res) => {
        res.json().then((resJson) => {
          console.log(resJson);
          if (resJson && resJson.Id > 0) {
            /* attach files */
            PnPService.attachFilesToListItem(Consts.LISTTITLES.SPL, resJson.Id, this.state.attachmentFiles).then(() => {
              this.setState({
                showSubmitDialog: true,
                submitDialogText: `Incident report ${incidentNumber} saved successfully`
              });
            });

            /*Mark the current version as old*/
            if (this.state.incReportStatus == Consts.INCSTATUS.Submitted) {
              let reqBody: string = JSON.stringify({
                '__metadata': {
                  'type': Consts.LISTITEMENTTYPES.SPL
                },
                [Consts.SPLFIELDS.LockStatus]: Consts.LOCKSTATUS.LOCKED,
                [Consts.SPLFIELDS.IsLatestVersion]: false
              });

              let reqUrl = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.SPL}')/items(${this.props.itemId})`;
              SPHttpService.Update(reqUrl, reqBody).catch(err => console.log(err));
            }
          }
          else {
            this.setState({ errorMessage: "test" });
          }
        });
      }).catch((err) => {
        this.setState({ errorMessage: err });
      });
    }
    else if (this.props.formMode == Consts.FORMMODE.Edit && this.state.incReportStatus == Consts.INCSTATUS.Saved) {
      url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.SPL}')/items(${this.props.itemId})`;
      /* update list item and attach files */
      SPHttpService.Update(url, body).then((res) => {
        PnPService.attachFilesToListItem(Consts.LISTTITLES.SPL, this.props.itemId, this.state.attachmentFiles, this.attachments).then(() => {
          this.setState({
            showSubmitDialog: true,
            submitDialogText: `Incident report ${incidentNumber} saved successfully`
          });
        });
      }).catch((err) => {
        this.setState({ errorMessage: err });
      });
    }
  }

  private submitIncident() {
    let url: string;
    let incidentNumber: string;
    let promiseIncNumber: Promise<any>[] = [];

    //Generate new incident number if it is new report
    if (this.props.formMode == Consts.FORMMODE.New ||
      Math.floor(this.state.incVersion) == 0) {
      promiseIncNumber.push(ListService.getNextIncidentNumber(Consts.REPORTCODES.SPL).then((incNum: number) => {
        let dt: Date = new Date();
        let year = dt.getFullYear();
        let month = ("0" + (dt.getMonth() + 1)).slice(-2);
        let date = ("0" + dt.getDate()).slice(-2);
        let num = incNum < 10 ? `0${incNum}` : incNum;
        incidentNumber = `${Consts.REPORTCODES.SPL}-${year}${month}${date}-${num}`;
      })
      );
    }
    else {
      incidentNumber = this.state.utilityCompanyIncidentNumber;
    }

    Promise.all(promiseIncNumber).then(() => {
      let body: string = JSON.stringify({
        '__metadata': {
          'type': Consts.LISTITEMENTTYPES.SPL
        },
        'Title': Consts.REPORTNAMES.SPL,
        [Consts.SPLFIELDS.UtilityCompanyIncidentNumber]: incidentNumber,
        [Consts.SPLFIELDS.UtilityId]: Consts.UtilityId,
        [Consts.SPLFIELDS.UtilityName]: Consts.UtilityName,
        [Consts.SPLFIELDS.UtilityPersonnelReportingId]: this.state.selPersonnelReportingId,
        [Consts.SPLFIELDS.UtilityPersonnelEmail]: this.state.personnelReportingEmail,
        [Consts.SPLFIELDS.UtilityPersonnelPhone]: this.state.personnelReportingPhone,
        [Consts.SPLFIELDS.SpillReportedDt]: this.state.SpillReportedDt,
        [Consts.SPLFIELDS.SpillOccurredDt]: this.state.SpillOccurredDt,
        [Consts.SPLFIELDS.TD]: this.state.TD,
        [Consts.SPLFIELDS.MaterialTypeSpilled]: this.state.selMaterialTypeSpilled,
        [Consts.SPLFIELDS.ReasonForSpill]: this.state.selReasonforSpill,
        [Consts.SPLFIELDS.SpillQuantity]: this.state.SpillQuantity,
        [Consts.SPLFIELDS.SpillQuantityUnit]: this.state.selspillQuantityUnit,
        [Consts.SPLFIELDS.PCBDetermination]: this.state.selPCBDetermination,
        [Consts.SPLFIELDS.PCMDeterminationMEthod]: this.state.selPCMDeterminationMEthod,
        [Consts.SPLFIELDS.PCMDeterminationComments]: this.state.PCMDeterminationComments,
        [Consts.SPLFIELDS.LatitudeEquipmentImpacted]: this.state.LatitudeEquipmentImpacted,
        [Consts.SPLFIELDS.LongitudeEquipmentImpacted]: this.state.LongitudeEquipmentImpacted,
        [Consts.SPLFIELDS.TownLocalityIncidentOccurred]: this.state.TownLocalityIncidentOccurred,
        [Consts.SPLFIELDS.CountyIncidentOccurred]: this.state.selCountyIncidentOccurred,
        [Consts.SPLFIELDS.FacilityType]: this.state.selFacilityType,
        [Consts.SPLFIELDS.SpillDescription]: this.state.SpillDescription,
        [Consts.SPLFIELDS.UpdatedSpillDesc]: this.state.UpdatedSpillDesc,
        [Consts.SPLFIELDS.EmergencyMeasure]: this.state.EmergencyMeasure,
        [Consts.SPLFIELDS.RecoverdMaterialQty]: this.state.RecoverdMaterialQty,
        [Consts.SPLFIELDS.AddressIncidentOccurred]: this.state.AddressIncidentOccurred,
        [Consts.SPLFIELDS.HazardtoHuman]: this.state.selHazardtoHuman,
        [Consts.SPLFIELDS.TransformCapitalMonthYear]: this.state.TransformCapitalMonthYear,
        [Consts.SPLFIELDS.AgencyNotified]: this.state.AgencyNotified,
        [Consts.SPLFIELDS.CHGEForemanonSite]: this.state.CHGEForemanonSite,
        /* [Consts.SPLFIELDS.AgencyNotifiedDt]: this.state.AgencyNotifiedDt, */
        [Consts.SPLFIELDS.CHGEForemanonSitePhone]: this.state.CHGEForemanonSitePhone,
        [Consts.SPLFIELDS.EnvironmentalSOC]: this.state.selEnvironmentalSOC,
        [Consts.SPLFIELDS.EnvironmentalCleanupContractor]: this.state.selEnvironmentalCleanupContractor,

        [Consts.SPLFIELDS.ContractorOnSiteDt]: this.state.ContractorOnSiteDt,
        [Consts.SPLFIELDS.EnvironmentalComments]: this.state.EnvironmentalComments,
        [Consts.SPLFIELDS.DecSpfiill]: this.state.DecSpfiill,
        [Consts.SPLFIELDS.PolePadVehicleNumber]: this.state.PolePadVehicleNum,
        [Consts.SPLFIELDS.OperatingDistrict]: this.state.selOperatingDistrict,
        [Consts.SPLFIELDS.InjuriesSustained]: this.state.selInjuriesSustained,
        [Consts.SPLFIELDS.ClearofStreamsPonds]: this.state.ClearOfStreamsPonds,
        [Consts.SPLFIELDS.TransformerNum]: this.state.TransformerNum,
        [Consts.COMMONFIELDS.IncVersion]: (Math.floor(this.state.incVersion) + 1).toString(),
        [Consts.SPLFIELDS.SubmittedDate]: new Date(),
        [Consts.SPLFIELDS.IncReportStatus]: Consts.INCSTATUS.Submitted,
        [Consts.COMMONFIELDS.IsLatestVersion]: true,
        [Consts.COMMONFIELDS.SendEmail]: true,
        [Consts.COMMONFIELDS.LastEditedById]: this.currentUserId
      });

      if (this.props.formMode == Consts.FORMMODE.New ||
        (this.props.formMode == Consts.FORMMODE.Edit && this.state.incReportStatus == Consts.INCSTATUS.Submitted)) {

        url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.SPL}')/items`;

        SPHttpService.Post(url, body).then((res) => {
          res.json().then((resJson) => {
            if (resJson && resJson.Id > 0) {
              PnPService.attachFilesToListItem(Consts.LISTTITLES.SPL, resJson.Id, this.state.attachmentFiles).then(() => {
                this.setState({
                  showSubmitDialog: true,
                  submitDialogText: `Incident report ${incidentNumber} submitted successfully`
                });
              });
              /*Mark the current version as old*/
              if (this.props.formMode == Consts.FORMMODE.Edit) {
                let reqBody: string = JSON.stringify({
                  '__metadata': {
                    'type': Consts.LISTITEMENTTYPES.SPL
                  },
                  [Consts.COMMONFIELDS.LockStatus]: Consts.LOCKSTATUS.LOCKED,
                  [Consts.COMMONFIELDS.IsLatestVersion]: false
                });

                let reqUrl = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.SPL}')/items(${this.props.itemId})`;
                SPHttpService.Update(reqUrl, reqBody).catch(err => console.log(err));
              }
            }
            else {
              this.setState({ errorMessage: "test" });
            }
          });
        }).catch((err) => {
          this.setState({ errorMessage: err });
        });
      }
      else if (this.props.formMode == Consts.FORMMODE.Edit && this.state.incReportStatus == Consts.INCSTATUS.Saved) {
        url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.SPL}')/items(${this.props.itemId})`;
        SPHttpService.Update(url, body).then((res) => {
          PnPService.attachFilesToListItem(Consts.LISTTITLES.SPL, this.props.itemId, this.state.attachmentFiles, this.attachments).then(() => {
            this.setState({
              showSubmitDialog: true,
              submitDialogText: `Incident report ${incidentNumber} submitted successfully`
            });
          });
        }).catch((err) => {
          this.setState({ errorMessage: err });
        });
      }
    });
  }
  private unlockReport() {

    let body: string = JSON.stringify({
      '__metadata': {
        'type': Consts.LISTITEMENTTYPES.SPL
      },
      [Consts.SPLFIELDS.LockStatus]: Consts.LOCKSTATUS.UNLOCKED
    });

    let url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.SPL}')/items(${this.props.itemId})`;
    SPHttpService.Update(url, body).then((res) => {
      this.setState({
        showConfirmDialog: false,
        showSubmitDialog: true,
        submitDialogText: `Incident report is unlocked`
      });
    }).catch((err) => {
      this.setState({ errorMessage: err });
    });
  }

  public componentDidMount() {
    /* load form boilerplate text */
    let formConfigPromise: Promise<any> = ListService.getFormConfigData(Consts.REPORTCODES.SPL);

    /* load form tooltips */
    let formTooltipsPromise: Promise<any> = ListService.getFormTooltips(Consts.REPORTCODES.SPL);

    /* load master list data for dropdowns */
    let masterListDataPromise: Promise<any> = ListService.getMasterListData(Consts.REPORTCODES.SPL);

    /* get current user permissions */
    let userGroupsPromise = PnPService.getCurrentUserGroups();

    Promise.all([formConfigPromise, formTooltipsPromise, masterListDataPromise, userGroupsPromise]).then((results) => {

      let footer: string = "";
      let tooltips = [];
      let items: IMasterList[] = [];

      /*boilerplate text */
      if (results[0] && results[0].value.length > 0) {
        footer = results[0].value[0]["Footer"];
      }

      /* get tooltips*/
      if (results[1] && results[1].value.length > 0) {
        results[1].value.forEach(item => {
          tooltips.push({
            key: item["Field"], value: item["Tooltip"]
          });
        });
      }

      /*master list data*/
      if (results[2]) {
        items = results[2].value;
      }

      /* user groups */
      if (results[3]) {
        this.isAdmin = results[3].indexOf(Consts.AdminGroup) > -1;
        this.isContributor = results[3].indexOf(Consts.ContributorsGroup) > -1;
      }

      /* update state */
      this.setState({
        footer: footer,
        tooltips: tooltips,
        masterListData: items,

        MaterialTypeSpilled: this.getDropDownOptions(items, "Material Type Spilled"),
        ReasonforSpill: this.getDropDownOptions(items, "Cause of Spill"),
        PCBDetermination: this.getDropDownOptions(items, "PCB Determination"),
        PCMDeterminationMEthod: this.getDropDownOptions(items, "PCB Determination Method"),
        SpillQuantityUnit: this.getDropDownOptions(items, "Spilled Units"),
        CountyIncidentOccurred: this.getDropDownOptions(items, "County"),
        FacilityType: this.getDropDownOptions(items, "Facility Type"),
        HazardtoHuman: this.getDropDownOptions(items, "Hazard to Human"),
        EnvironmentalSOC: this.getDropDownOptions(items, "Environmental SOC"),
        EnvironmentalCleanupContractor: this.getDropDownOptions(items, "Environmental Cleanup Contractor"),
        OperatingDistricts: this.getDropDownOptions(items, "Operating Districts"),
        InjuriesSustained: this.getDropDownOptions(items, "Injuries Sustained")
      });

      /* get current user profile properties for new request */
      var date = new Date();
      date.setSeconds(0);
      PnPService.spLoggedInUserDetails().then((user) => {
        this.currentUserId = user.Id;
        if (this.props.formMode == Consts.FORMMODE.New && (this.isAdmin || this.isContributor)) {
          this.setState({
            selPersonnelReportingId: user.Id,
            selPersonnelReportingEMail: this.props.currentUser.email,
            personnelReportingEmail: this.props.currentUser.email,
            personnelReportingPhone: user.WorkPhone,
            SpillReportedDt: date,
            SpillOccurredDt: date,
            showSaveBtn: true,
            showSubmitBtn: true
          });
        }
        else if (this.props.formMode == Consts.FORMMODE.Edit) {
          this.loadReportData();
        }
      });
    });
  }

  private getToolTipForField(fieldName: string): string {
    let tooltips = this.state.tooltips;
    let tooltip = "";
    if (tooltips && tooltips.length > 0) {
      let item = tooltips.filter(t => t.key == fieldName);
      if (item.length > 0) {
        tooltip = item[0].value;
      }
    }
    return tooltip;
  }

  public render(): React.ReactElement<ISpillsreportProps> {
    const getKey = `datetime-${new Date().getTime()}`; /*Dummy key to forece render DateTime picker - to handle bug */
    const imgLogoI: string = require("../../../images/logoi.png");

    let tMonth, tYear;

    if (this.state.TransformCapitalMonthYear) {
      let transfMonthYear = this.state.TransformCapitalMonthYear.split("/");
      tMonth = Number(transfMonthYear[0]) - 1;
      tYear = transfMonthYear[1];
    }

    const {
      selPersonnelReportingId,
      personnelReportingEmail,
      personnelReportingPhone,
      SpillReportedDt,
      SpillOccurredDt,
      selReasonforSpill,
      AddressIncidentOccurred,
      selMaterialTypeSpilled,
      LatitudeEquipmentImpacted,
      LongitudeEquipmentImpacted,
      SpillDescription,
      selFacilityType,
      TownLocalityIncidentOccurred,
      selCountyIncidentOccurred,
      ClearOfStreamsPonds,
      selEnvironmentalSOC,
      CHGEForemanonSite,
      CHGEForemanonSitePhone
    } = this.state;

    let isFormValid: boolean = false;
    if (selPersonnelReportingId
      && personnelReportingEmail
      && personnelReportingPhone
      && SpillReportedDt
      && SpillOccurredDt
      && selReasonforSpill
      && TownLocalityIncidentOccurred
      && selMaterialTypeSpilled
      && AddressIncidentOccurred
      && selCountyIncidentOccurred
      && LatitudeEquipmentImpacted
      && LongitudeEquipmentImpacted
      && selFacilityType
      && selEnvironmentalSOC
      && SpillDescription
      && ClearOfStreamsPonds != null
      && CHGEForemanonSite
      && CHGEForemanonSitePhone
    ) {
      isFormValid = true;
    }
    return (
      <div>
        <div className={styles["content-megacontainer"]}>
          <form>
            <div className={styles["container-n"]}>
              <h4 className={styles["heading1"]}>System Operations Spill Report</h4>
            </div>
            {this.props.formMode == Consts.FORMMODE.Edit && this.state.reportJson &&
              <div style={{ marginLeft: "65%" }}>
                {/* <CommandBarButton iconProps={{ iconName: "PDF" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Export as PDF" onClick={() => this.onExportPDFClick()} /> */}
                <CommandBarButton iconProps={{ iconName: "WordDocument" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Export as Word" onClick={() => this.onExportWordClick()} />
                <CommandBarButton iconProps={{ iconName: "Print" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Print / Save as PDF" onClick={() => this.onPrintlick()} />
                <CommandBarButton iconProps={{ iconName: "Mail" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Email" onClick={() => this.setState({ showEmailDialog: true })} />
              </div>
            }
            <hr className={styles["line"]} />
            <div className={styles["s"]}>
              {this.props.formMode == Consts.FORMMODE.Edit &&
                <p>Utilty Incident Number : <span className={styles["span1"]}>{this.state.utilityCompanyIncidentNumber}</span>
                  <span className={styles["span2"]}>CHGE "1001"</span>
                </p>
              }
              <p>Utilty Name : <span className={styles["span3"]}> Central Hudson Gas & Electric Corp.</span></p>
            </div>
            <div className={styles["content-container"]}>
              <p className={styles["heading"]}>Reporting Details<a href="#"><TooltipHost content={this.getToolTipForField("Reporting Details")}><img src={imgLogoI} /></TooltipHost></a></p>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Personnel Reporting <span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <PeoplePicker
                        context={this.props.context}
                        personSelectionLimit={1}
                        ensureUser={true}
                        onChange={(items) => this.onPeoplePickerChange(items)}
                        principalTypes={[PrincipalType.User]}
                        resolveDelay={100}
                        defaultSelectedUsers={[this.state.selPersonnelReportingEMail]} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Email<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="personnelReportingEmail" value={this.state.personnelReportingEmail} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Phone Number<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="personnelReportingPhone" value={this.state.personnelReportingPhone} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>
                  <h5 className={styles["heading"]}>Date and Time Reported<span className={styles["star"]}>*</span><a href="#"><TooltipHost content={this.getToolTipForField("Date and Time Reported")}><img src={imgLogoI} /></TooltipHost></a></h5>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.SpillReportedDt} onChange={(val) => this.onUtilityRepDateChange(val)} />
                </div>
                <div className={styles["column-2"]}>
                  <h5 className={styles["heading"]}>Date and Time Spill Discovered<span className={styles["star"]}>*</span><a href="#"><TooltipHost content={this.getToolTipForField("Date and Time Spill Occurred")}><img src={imgLogoI} /></TooltipHost></a></h5>
                  {/* <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.SpillOccurredDt} onChange={(val) => this.onOccurDateChange(val)} /> */}
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.SpillOccurredDt} onChange={(val) => this.onOccurDateChange(val)} />
                </div>
              </div>
              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>T# or D#<a href="#"><TooltipHost content={this.getToolTipForField("T# or D#")}><img src={imgLogoI} /></TooltipHost></a></label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="TD" value={this.state.TD} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Cause of Spill <span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selReasonforSpill" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.selReasonforSpill} options={this.state.ReasonforSpill} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>PCB Determination :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selPCBDetermination" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.selPCBDetermination} options={this.state.PCBDetermination} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>PCB Determination <br />Method :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selPCMDeterminationMEthod" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.selPCMDeterminationMEthod} options={this.state.PCMDeterminationMEthod} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>PCB Determination<br /> Comments:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='PCMDeterminationComments' value={this.state.PCMDeterminationComments} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Type of Material Spilled<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selMaterialTypeSpilled" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.selMaterialTypeSpilled} options={this.state.MaterialTypeSpilled} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Quantity Spilled :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="SpillQuantity" type="number" value={this.state.SpillQuantity} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Quantity Spilled Units:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selspillQuantityUnit" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.selspillQuantityUnit} options={this.state.SpillQuantityUnit} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Transformer Capitalization<br /> Month and Year:</label>
                    </div>
                    <div className={styles["react-datepicker-wrapper"]}>
                      <DatePicker className={styles["react-datepicker__input-container"]}
                        selected={this.state.TransformCapitalMonthYear ? new Date(tYear, tMonth) : null}
                        onChange={(value) => this.onTransfCapDateChange(value)}
                        minDate={new Date("1920/01")}
                        maxDate={new Date("2021/12")}
                        dateFormat="MM/yyyy"
                        showMonthYearPicker
                      />
                      {/* <DateTimePicker key={getKey} dateConvention={DateConvention.Date} value={this.state.TransformCapitalMonthYear} onChange={(val) => this.onTransfCapDateChange(val)} /> */}
                    </div>
                  </div>
                </div>
              </div>
              <h5 className={styles["heading"]}>Area Details<a href="#"><TooltipHost content={this.getToolTipForField("Area Details")}><img src={imgLogoI} /></TooltipHost></a></h5>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Address of Incident <span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='AddressIncidentOccurred' value={this.state.AddressIncidentOccurred} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Operating District :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selOperatingDistrict" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.selOperatingDistrict} options={this.state.OperatingDistricts} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Latitude <span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='LatitudeEquipmentImpacted' value={this.state.LatitudeEquipmentImpacted} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Town / Locality of <br /> Incident<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.TownLocalityIncidentOccurred} name='TownLocalityIncidentOccurred' onChange={(e) => this.onTextChange(e)} />

                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Pole/Pad/Vehicle #:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='PolePadVehicleNum' value={this.state.PolePadVehicleNum} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>

                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                    </div>
                    <div className={styles["input-container"]}>
                      <br />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}></label>
                    </div>
                    <div className={styles["input-container"]}>
                      <DefaultButton className={styles["longbutton"]} text="Get Latitude and Longitude" onClick={() => this.onGetLatLongClick()} />
                    </div>
                  </div>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Longitude<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.LongitudeEquipmentImpacted} name='LongitudeEquipmentImpacted' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>County of Incident<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selCountyIncidentOccurred" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.selCountyIncidentOccurred} options={this.state.CountyIncidentOccurred} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Type of Facility<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selFacilityType" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.selFacilityType} options={this.state.FacilityType} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Spill Description <span className={styles["star"]}>*</span>:<a href="#"><TooltipHost content={this.getToolTipForField("Spill Description")}><img src={imgLogoI} /></TooltipHost></a></label>
                    </div>
                    <div className={styles["text-area-container"]}>
                      <TextField multiline rows={3} name='SpillDescription' value={this.state.SpillDescription} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Updated Spill Description :</label>
                    </div>
                    <div className={styles["text-area-container"]}>
                      <TextField multiline rows={3} name='UpdatedSpillDesc' value={this.state.UpdatedSpillDesc} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Emergency Measures to <br />Contain Spill <a href="#"><TooltipHost content={this.getToolTipForField("Emergency Measures to to Contain Spill")}><img src={imgLogoI} /></TooltipHost></a></label>
                    </div>
                    <div className={styles["text-area-container"]}>
                      <TextField multiline rows={3} name='EmergencyMeasure' type="text" value={this.state.EmergencyMeasure} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["two-columns-container"]}></div>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Transformer S/N:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='TransformerNum' value={this.state.TransformerNum} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      {/* <label className={styles["label"]}>Emergency Measures to to Contain Spill <a href="#"><TooltipHost content={this.getToolTipForField("Emergency Measures to to Contain Spill")}><img src={imgLogoI} /></TooltipHost></a></label> */}
                    </div>
                    <div className={styles["input-container"]}>
                      {/* <TextField name='EmergencyMeasure' type="text" value={this.state.EmergencyMeasure} onChange={(e) => this.onTextChange(e)} /> */}
                    </div>
                  </div>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Quantity of <br />Recovered Material :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.RecoverdMaterialQty} name='RecoverdMaterialQty' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Possible hazards to <br />human health :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selHazardtoHuman" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.selHazardtoHuman} options={this.state.HazardtoHuman} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                </div>

                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Clear of streams, ponds<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <ChoiceGroup options={[{ key: 'Yes', text: 'Yes' }, { key: 'No', text: 'No' }]}
                        onChange={(ev, o) => this.onChoiceChange(ev, o)}
                        selectedKey={this.state.ClearOfStreamsPonds != null && (this.state.ClearOfStreamsPonds ? "Yes" : "No")}></ChoiceGroup>
                    </div>
                  </div>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      {/* <label className={styles["label"]}>Additional Preventative Measures to Contain Spill:</label> */}
                    </div>
                    <div className={styles["input-container"]}>
                      {/* <TextField name='AdditionalPreventiveMeasure' type="text" value={this.state.AdditionalPreventiveMeasure} onChange={(e) => this.onTextChange(e)} /> */}
                    </div>
                  </div>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Injuries sustained :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selInjuriesSustained" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.selInjuriesSustained} options={this.state.InjuriesSustained} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Environmental SOC<br /> Contacted<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selEnvironmentalSOC" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.selEnvironmentalSOC} options={this.state.EnvironmentalSOC} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>
                  <h5 className={styles["heading"]}>Agenices Notified<a href="#"><TooltipHost content={this.getToolTipForField("Other Agenices Notified")}><img src={imgLogoI} /></TooltipHost></a></h5>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>NYSDEC (800-457-7362) Spill #:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.DecSpfiill} name='DecSpfiill' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Other Agencies :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='AgencyNotified' type="text" value={this.state.AgencyNotified} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>

                </div>
                <div className={styles["column-2"]}>
                  <h5 className={styles["heading"]}>CHGE Foreman/Crew Rep. Onsite<a href="#"><TooltipHost content={this.getToolTipForField("CHGE Foreman/Crew Rep. Onsite")}><img src={imgLogoI} /></TooltipHost></a></h5>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Name <span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='CHGEForemanonSite' value={this.state.CHGEForemanonSite} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Phone # <span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='CHGEForemanonSitePhone' value={this.state.CHGEForemanonSitePhone} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Environmental Cleanup Contractor :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selEnvironmentalCleanupContractor" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.selEnvironmentalCleanupContractor} options={this.state.EnvironmentalCleanupContractor} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>
                  <h5 className={styles["heading"]}>Contractor on site time<a href="#"><TooltipHost content={this.getToolTipForField("Contractor on site time")}><img src={imgLogoI} /></TooltipHost></a></h5>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.ContractorOnSiteDt} onChange={(val) => this.onContrOnSiteDateChange(val)} />

                  < div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Additional Attachments:</label>
                      <PrimaryButton className={styles["attach"]} onClick={(e) => this.onAttchSelect(e)}>Choose Files</PrimaryButton>
                      <input type="file" ref={this.fileAttachRef} multiple={true} onChange={(e) => this.onAttachmentChange(e)} hidden />
                      {
                        this.state.attachmentFiles.length > 0 &&
                        <ul className={styles["attachment-list-alignment"]}>
                          {this.state.attachmentFiles.map((file: IFileInfo, index: number) => {
                            return (<li>{file.url ? (<a download={file.name} href={file.url} data-interception="off" target="_blank">{file.name}</a>) : <i>{file.name}</i>} <FontIcon iconName="Delete" onClick={(e) => this.onDeleteAttachment(e, index)} /></li>);
                          })
                          }
                        </ul>
                      }
                    </div>
                  </ div>
                </div>

                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                    </div>
                    <div className={styles["text-area-container"]}>
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Environmental Comments :</label>
                    </div>
                    <div className={styles["text-area-container"]}>
                      <TextField multiline rows={3} name='EnvironmentalComments' value={this.state.EnvironmentalComments} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["bottomButton"] + ' ' + styles["btn-gap"]}>
                <DefaultButton className={styles["bottomButton__one"]} text="Cancel" onClick={(e) => this.onCancelClick()} />
                {
                  this.state.showSaveBtn &&
                  <DefaultButton className={styles["bottomButton__two"]} text="Save" onClick={() => this.saveIncident()} />
                }
                {
                  this.state.showSubmitBtn &&
                  <PrimaryButton className={styles["bottomButton__three"]} text="Submit" disabled={!isFormValid} onClick={() => this.submitIncident()} />
                }
                {
                  this.state.showUnlockBtn &&
                  <PrimaryButton className={styles["bottomButton__three"]} text="Unlock Report"
                    onClick={() => this.setState({
                      showConfirmDialog: true,
                      confirmDialogText: "Are you sure you want to unlock this report?",
                      onConfirmDialog: () => this.unlockReport()
                    })} />
                }
              </div>
            </div>
            <hr className={styles["line"]} />
            <div className={styles["v"]}>
              <p className={styles["message"]}>{this.state.footer}</p>
            </div>
          </form>
        </div>
        <SubmitDialog
          showDialog={this.state.showSubmitDialog}
          hideDialog={() => { this.setState({ showSubmitDialog: false }); }}
          dialogTitle={this.state.submitDialogTitle}
          dialogText={this.state.submitDialogText}
          siteUrl={this.props.siteUrl}
          reportsPageUrl={this.props.siteUrl + Consts.REPORTPAGEURLS.SPL}
          className={styles.dialogContent} />
        <ConfirmDialog
          showDialog={this.state.showConfirmDialog}
          hideDialog={() => { this.setState({ showConfirmDialog: false }); }}
          onConfirm={this.state.onConfirmDialog}
          dialogText={this.state.confirmDialogText}
          className={styles.dialogContent} />
        <SendEmailDialog
          showDialog={this.state.showEmailDialog}
          hideDialog={() => { this.setState({ showEmailDialog: false }); }}
          title={this.state.item && this.state.item["Title"]}
          incidentNumber={this.state.utilityCompanyIncidentNumber}
          mailBody={this.state.reportJson}
          className={styles.dialogContent} />
      </div>);
  }
}
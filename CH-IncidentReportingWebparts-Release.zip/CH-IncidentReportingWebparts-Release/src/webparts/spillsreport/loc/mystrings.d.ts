declare interface ISpillsreportWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpillsreportWebPartStrings' {
  const strings: ISpillsreportWebPartStrings;
  export = strings;
}

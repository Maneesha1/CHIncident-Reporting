import { IItem } from '@pnp/sp/items';
import { IDropdownOption } from 'office-ui-fabric-react';
import { IFileInfo } from "../../../models/IFileInfo";
import { IMasterList } from '../../../models/IMasterList';

export interface IDotGasState {
    item: IItem;
    utilityCompanyIncidentNumber: string;
    utilityId:string;
    utilityName:string;
    selPersonnelReportingId: string;
    selPersonnelReporting: string;
    selPersonnelReportingName: string;
    personnelReportingPhone: string;
    personnelReportingEmail: string;

    addressIncidentOccurred: string;
    closestCrossStreetToIncident: string;
    incidentDescription: string;
    incidentOccurredDt: Date;
    incidentReportedToUtilityCompanyDt: Date;
    latitudeEquipmentImpacted: string;
    longitudeEquipmentImpacted: string;
    madeSafeDt: Date;
    servicesInterruptedCount: string;
    selTown: string;
    selCounty: string;
    selMediaCoverage: string;
    dispatchDt: Date;
    crewArrivalDt: Date;
    reportUpdateDt: Date;
    reportUpdateDesc: string;
    employeePriClass: string;
    dOTReportDt: Date;
    dOTReportNumber: string;
    dOTTroubleDispatch: string;
    utilityReportedDt: Date;

    incVersion: number;
    incReportStatus: string;
    submittedDate: Date;
    isLatestVersion: boolean;

    attachmentFiles: IFileInfo[];
    masterListData: IMasterList[];
    counties: IDropdownOption[];
    mediaCoverageOptions: IDropdownOption[];

    showSubmitDialog: boolean;
    showConfirmDialog: boolean;
    showEmailDialog: boolean;
    submitDialogTitle: string;
    submitDialogText: string;
    confirmDialogText: string;
    onConfirmDialog: () => void;
    errorMessage: string;
    showSaveBtn: boolean;
    showSubmitBtn: boolean;
    showUnlockBtn: boolean;
    reportJson: string;

    footer: string;
    tooltips: any[];
}
declare interface IDotGasWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'DotGasWebPartStrings' {
  const strings: IDotGasWebPartStrings;
  export = strings;
}

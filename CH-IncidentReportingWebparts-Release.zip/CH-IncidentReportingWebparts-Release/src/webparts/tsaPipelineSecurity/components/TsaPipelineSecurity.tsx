import * as React from 'react';
import styles from './TsaPipelineSecurity.module.scss';
import { ITsaPipelineSecurityProps } from './ITsaPipelineSecurityProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { TextField, Dropdown, IDropdownOption, DefaultButton, PrimaryButton, CommandBarButton, TooltipHost } from 'office-ui-fabric-react';
import { FontIcon } from 'office-ui-fabric-react/lib/Icon';
import { DateTimePicker, TimeConvention, TimeDisplayControlType } from '@pnp/spfx-controls-react/lib/DateTimePicker';
import ListService from '../../../services/ListService';
import PnPService from '../../../services/PnPService';
import HttpService from "../../../services/HttpService";
import SPHttpService from "../../../services/SPHttpService";
import * as Consts from '../../../common/constants';
import { IMasterList } from '../../../models/IMasterList';
import { IFileInfo } from '../../../models/IFileInfo';
import { ITsaPipelineSecurityState } from './ITsaPipelineSecurityState';
import { IUserProfile } from '../../../models/IUserProfile';
import { SubmitDialog } from "../../../common/components/SubmitDialog";
import { ConfirmDialog } from "../../../common/components/ConfirmDialog";
import PDFService from "../../../services/PDFService";
import WordService from "../../../services/WordService";
import Utilities from "../../../services/Utilities";
import { SendEmailDialog } from '../../../common/components/SendEmailDialog';

export default class TsaPipelineSecurity extends React.Component<ITsaPipelineSecurityProps, ITsaPipelineSecurityState> {

  private fileAttachRef;
  private isAdmin: boolean = false;
  private isContributor: boolean = false;
  private currentUserId: number;
  private attachments: string[] = [];

  constructor(props: ITsaPipelineSecurityProps, state: ITsaPipelineSecurityState) {
    super(props);
    this.state = {
      item: null,
      masterListData: null,
      utilityCompanyIncidentNumber: null,
      utilityId: null,
      utilityName: null,
      selPersonnelReportingId: null,
      selPersonnelReporting: null,
      selPersonnelReportingName: null,
      personnelReportingPhone: null,
      personnelReportingEmail: null,
      incidentReportedToUtilityCompanyDt: null,

      addressIncidentOccurred: null,
      closestCrossStreetToIncident: null,
      selCounty: null,
      incidentDescription: null,
      latitudeEquipmentImpacted: null,
      longitudeEquipmentImpacted: null,
      selTown: null,
      tSOCStaffNotified: null,
      incidentReportedToTSOCDt: null,
      selagencyNotified: [],
      selShortDescription: null,
      incidentOccurredDt: null,
      attachmentFiles: [],
      towns: [],
      counties: [],
      shortDescription: [],
      agencyNotified: [],
      incVersion: 0,
      incReportStatus: null,
      submittedDate: null,
      isLatestVersion: false,
      showSubmitDialog: false,
      showConfirmDialog: false,
      showEmailDialog: false,
      submitDialogTitle: "Success",
      submitDialogText: null,
      confirmDialogText: null,
      onConfirmDialog: null,
      errorMessage: null,
      showSaveBtn: false,
      showSubmitBtn: false,
      showUnlockBtn: false,
      reportJson: null,

      footer: null,
      tooltips: null
    };
    this.fileAttachRef = React.createRef();
  }

  /** Event Handlers **/
  /* Attachment button select event */
  private onAttchSelect(e) {
    e.preventDefault();
    this.fileAttachRef.current.click();
  }

  /* Attachment file change event */
  private onAttachmentChange(event) {
    let resultFile = event.target.files;
    let fileInfos: IFileInfo[] = [];
    let promArr: Promise<any>[] = [];
    for (var i = 0; i < resultFile.length; i++) {
      var file = resultFile[i];
      var reader = new FileReader();
      promArr.push(new Promise((resolve, reject) => {
        reader.onload = ((fileToRead) => {
          return (e) => {
            //Push the converted file into array
            fileInfos.push({
              "name": fileToRead.name,
              "content": e.target.result
            });
            resolve();
          };
        })(file);
        reader.readAsArrayBuffer(file);
      }));
    }
    /* Load attachments to state after they are all read */
    Promise.all(promArr).then(() => {
      this.setState({
        attachmentFiles: [...this.state.attachmentFiles, ...fileInfos]
      });
    });
  }

  /* Cancel button click event */
  private onCancelClick() {
    window.location.href = this.props.siteUrl;
  }

  /* Delete attachment event */
  private onDeleteAttachment(event, index) {
    let attachments = this.state.attachmentFiles;
    attachments.splice(index, 1);
    this.setState({
      attachmentFiles: attachments
    });
  }

  /* onchange event for single select dropdowns */
  private onDropDownChange(event, selItem: IDropdownOption) {
    this.setState({
      ...this.state,
      [event.target.id]: selItem.text,
    });
  }

  /* export to pdf */
  private onExportPDFClick() {
    PDFService.ExportToPDFFromHTML(this.state.item["UtilityCompanyIncidentNumber"], this.state.item["Title"], this.state.reportJson);
  }

  /* export to word */
  private onExportWordClick() {
    WordService.generateDocument(this.state.item["UtilityCompanyIncidentNumber"], this.state.item["Title"], this.state.reportJson);
  }

  /* export to word */
  private onPrintlick() {
    Utilities.printHtml(this.state.item["UtilityCompanyIncidentNumber"], this.state.item["Title"], this.state.reportJson);
  }

  /* Get latitude and longitude for given address */
  private async onGetLatLongClick() {
    let addressParts: string[] = [];
    if (this.state.addressIncidentOccurred) {
      addressParts.push(this.state.addressIncidentOccurred);
    }
    if (this.state.closestCrossStreetToIncident) {
      addressParts.push(this.state.closestCrossStreetToIncident);
    }
    if (this.state.selTown) {
      addressParts.push(this.state.selTown);
    }
    if (this.state.selCounty) {
      addressParts.push(this.state.selCounty);
    }
    const resp = await HttpService.GetLatLongFromAddress(addressParts.join());
    const resJson = await resp.json();
    if (resJson && resJson.resourceSets.length > 0) {
      this.setState({
        latitudeEquipmentImpacted: resJson.resourceSets[0].resources[0].point.coordinates[0].toString(),
        longitudeEquipmentImpacted: resJson.resourceSets[0].resources[0].point.coordinates[1].toString()
      });
    }
  }

  /* onchange event for multi select dropdown */
  private onMultiDropdownChange(event, selItem: IDropdownOption) {
    this.setState({
      ...this.state,
      [event.target.id]: selItem.selected ? [...this.state[event.target.id], selItem.text] : this.state[event.target.id].filter(key => key !== selItem.key)
    });
  }

  /* DateTime Picker incidentOccurredDt*/
  private onOccurDateChange(value) {
    this.setState(
      {
        ...this.state,
        incidentOccurredDt: value
      }
    );
  }

  private onIncReportToTSOCDtChange(value) {
    this.setState(
      {
        ...this.state,
        incidentReportedToTSOCDt: value
      }
    );
  }

  /* people picker change event */
  private onPeoplePickerChange(items: any[]) {
    if (items.length > 0) {
      PnPService.getUserProfileProperties(items[0].loginName).then((userProps: IUserProfile) => {
        this.setState({
          selPersonnelReportingId: items[0].id,
          selPersonnelReporting: userProps.WorkEmail,
          personnelReportingEmail: userProps.WorkEmail,
          personnelReportingPhone: userProps.WorkPhone
        });
      });
    }
    else {
      this.setState({
        selPersonnelReportingId: null,
        selPersonnelReporting: null,
        personnelReportingEmail: null,
        personnelReportingPhone: null
      });
    }
  }

  /* text field change event */
  private onTextChange(event) {
    const value = event.target.value;
    this.setState(
      {
        ...this.state,
        [event.target.name]: value
      }
    );
  }

  /**Helper Functions **/
  private bindAttachmentsFromList(resultFile) {
    let fileInfos: IFileInfo[] = [];
    let promArr: Promise<any>[] = [];
    for (var i = 0; i < resultFile.length; i++) {
      var attFile = resultFile[i];
      ((file) => {
        promArr.push(new Promise((resolve, reject) => {
          fetch(Consts.SITEURLS.ROOTSITE + file.ServerRelativeUrl).then(e => {
            let content = e.arrayBuffer();
            content.then(c => {
              fileInfos.push({
                "name": file.FileName,
                "content": c,
                "url": Consts.SITEURLS.ROOTSITE + file.ServerRelativeUrl
              });
              resolve();
            });
          });
        }));
      })(attFile);
    }
    Promise.all(promArr).then(() => {
      this.setState({
        attachmentFiles: fileInfos
      });
    });
  }

  /* load dropdown values from Master List */
  private getDropDownOptions(items: IMasterList[], category: string, removeDuplicates: boolean = false, key: string = "", multiselect: boolean = false,): IDropdownOption[] {
    let values: any[] = items.filter(item => item.Category == category);
    if (removeDuplicates) {
      values = this.removeDuplicatesFromArray(values, key);
    }
    let ddlOptions: IDropdownOption[] = [];
    if (!multiselect) {
      ddlOptions.push({ key: "", text: "" });
    }
    values.map(item => ddlOptions.push({
      key: item.SubCategory, text: item.SubCategory
    }));
    ddlOptions.sort((a, b) => a.text.localeCompare(b.text));
    return ddlOptions;
  }

  /*Load report data based on ID in query string */
  private async loadReportData() {
    let allowSave: boolean = false;
    let allowSubmit: boolean = false;
    let allowUnlock: boolean = false;
    let submittedDt: Date = null;

    PnPService.getItemById(Consts.LISTTITLES.TSA, this.props.itemId, Consts.SELECTFIELDS.TSA, Consts.EXPANDFIELDS.TSA).then((item) => {
      if (item["Attachments"] == true) {
        item["AttachmentFiles"].forEach(file => {
          console.log(`${file.FileName}-${file.FileNameAsPath}-${file.ServerRelativePath}-${file.ServerRelativeUrl}`);
          this.attachments.push(file.FileName);
        });
        this.bindAttachmentsFromList(item["AttachmentFiles"]);
      }
      /* check save & submit conditions */
      if (this.isAdmin || this.isContributor) {
        /*Allow editing if it is a draft request */
        if (item[Consts.COMMONFIELDS.IncReportStatus] == Consts.INCSTATUS.Saved) {
          allowSave = true;
          allowSubmit = true;
        }
        /*Allow editing on latest versions of submitted request */
        else if (item[Consts.COMMONFIELDS.IncReportStatus] == Consts.INCSTATUS.Submitted && item[Consts.COMMONFIELDS.IsLatestVersion]) {

          if (item[Consts.COMMONFIELDS.SubmittedDate]) {

            submittedDt = new Date(item[Consts.COMMONFIELDS.SubmittedDate]);
            let elapsedTime = (new Date().getTime() - submittedDt.getTime()) / (1000 * 60 * 60);

            /*Allow editing within specified hours or if admin unlocked form */
            if (elapsedTime <= Consts.EditHours || item[Consts.COMMONFIELDS.LockStatus] == Consts.LOCKSTATUS.UNLOCKED) {
              allowSave = true;
              allowSubmit = true;
            }

            /*Allow unlock beyond specified time if user is admin */
            if (elapsedTime > Consts.EditHours && this.isAdmin && item[Consts.COMMONFIELDS.LockStatus] != Consts.LOCKSTATUS.UNLOCKED) {
              allowUnlock = true;
            }
          }
        }
      }
      /* Build HTML Table for Export to PDF, WORD and Send Mail */
      let repTable = Utilities.buildItemHTMLTable(item, Consts.SELECTFIELDS.TSA);

      /* update state to load form with data */
      this.setState({
        item: item,
        reportJson: repTable,
        utilityCompanyIncidentNumber: item[Consts.TSAFIELDS.UtilityCompanyIncidentNumber],
        utilityId: item[Consts.TSAFIELDS.UtilityId],
        utilityName: item[Consts.TSAFIELDS.UtilityName],
        selPersonnelReportingId: item[Consts.TSAFIELDS.UtilityPersonnelReportingId],
        selPersonnelReporting: item[Consts.TSAFIELDS.UtilityPersonnelReporting] ? item[Consts.TSAFIELDS.UtilityPersonnelReporting]["EMail"] : null,
        selPersonnelReportingName: item[Consts.TSAFIELDS.UtilityPersonnelReporting] ? item[Consts.TSAFIELDS.UtilityPersonnelReporting]["Title"] : null,
        personnelReportingEmail: item[Consts.TSAFIELDS.UtilityPersonnelEmail],
        personnelReportingPhone: item[Consts.TSAFIELDS.UtilityPersonnelPhone],
        incidentReportedToUtilityCompanyDt: item[Consts.TSAFIELDS.IncidentReportedToUtilityCompanyDt] ? new Date(item[Consts.TSAFIELDS.IncidentReportedToUtilityCompanyDt]) : null,
        addressIncidentOccurred: item[Consts.TSAFIELDS.AddressIncidentOccurred],
        closestCrossStreetToIncident: item[Consts.TSAFIELDS.ClosestCrossStreetToIncident],
        selCounty: item[Consts.TSAFIELDS.CountyIncidentOccurred],
        incidentDescription: item[Consts.TSAFIELDS.IncidentDescription],
        latitudeEquipmentImpacted: item[Consts.TSAFIELDS.LatitudeEquipmentImpacted],
        longitudeEquipmentImpacted: item[Consts.TSAFIELDS.LongitudeEquipmentImpacted],
        selTown: item[Consts.TSAFIELDS.TownLocalityIncidentOccurred],
        tSOCStaffNotified: item[Consts.TSAFIELDS.TSOCStaffNotified],
        incidentReportedToTSOCDt: item[Consts.TSAFIELDS.IncidentReportedToTSOCDt] ? new Date(item[Consts.TSAFIELDS.IncidentReportedToTSOCDt]) : null,
        selagencyNotified: item[Consts.TSAFIELDS.AgencyNotified] ? item[Consts.TSAFIELDS.AgencyNotified].split(", ") : [],
        selShortDescription: item[Consts.TSAFIELDS.TSAShortDescription],
        incidentOccurredDt: item[Consts.TSAFIELDS.IncidentOccurredDt] ? new Date(item[Consts.TSAFIELDS.IncidentOccurredDt]) : null,
        incVersion: item[Consts.COMMONFIELDS.IncVersion],
        submittedDate: submittedDt,
        isLatestVersion: item[Consts.COMMONFIELDS.IsLatestVersion],
        incReportStatus: item[Consts.COMMONFIELDS.IncReportStatus],
        showSaveBtn: allowSave,
        showSubmitBtn: allowSubmit,
        showUnlockBtn: allowUnlock
      });
    }).catch(err => {
      console.log(err);
    });
  }

  /* remove duplicates from a given array*/
  private removeDuplicatesFromArray(arr: any[], key: string): any[] {
    return arr.reduce((accumulator, currentValue) => {
      const value = currentValue[key];
      if (!accumulator.some(item => item[key] === value)) {
        accumulator.push(currentValue);
      }
      return accumulator;
    }, []);
  }

  /* create or update incident when user clicks on save button */
  private saveIncident() {
    let incidentNumber: string;
    let url: string;
    if (this.props.formMode == Consts.FORMMODE.New) {
      let dt: Date = new Date();
      let year = dt.getFullYear();
      let month = ("0" + (dt.getMonth() + 1)).slice(-2);
      let date = ("0" + dt.getDate()).slice(-2);
      incidentNumber = `${Consts.REPORTCODES.TSA}-${year}${month}${date}-Draft`;
    }
    else if (this.props.formMode == Consts.FORMMODE.Edit) {
      incidentNumber = this.state.utilityCompanyIncidentNumber;
    }
    let body: string = JSON.stringify({
      '__metadata': {
        'type': Consts.LISTITEMENTTYPES.TSA
      },
      'Title': Consts.REPORTNAMES.TSA,
      [Consts.TSAFIELDS.UtilityCompanyIncidentNumber]: incidentNumber,
      [Consts.TSAFIELDS.UtilityId]: Consts.UtilityId,
      [Consts.TSAFIELDS.UtilityName]: Consts.UtilityName,
      [Consts.TSAFIELDS.UtilityPersonnelReportingId]: this.state.selPersonnelReportingId,
      [Consts.TSAFIELDS.UtilityPersonnelEmail]: this.state.personnelReportingEmail,
      [Consts.TSAFIELDS.UtilityPersonnelPhone]: this.state.personnelReportingPhone,
      [Consts.TSAFIELDS.IncidentReportedToUtilityCompanyDt]: this.state.incidentReportedToUtilityCompanyDt,
      [Consts.TSAFIELDS.IncidentReportedToTSOCDt]: this.state.incidentReportedToTSOCDt,
      [Consts.TSAFIELDS.IncidentOccurredDt]: this.state.incidentOccurredDt,
      [Consts.TSAFIELDS.TSOCStaffNotified]: this.state.tSOCStaffNotified,
      [Consts.TSAFIELDS.IncidentDescription]: this.state.incidentDescription,
      [Consts.TSAFIELDS.LatitudeEquipmentImpacted]: this.state.latitudeEquipmentImpacted,
      [Consts.TSAFIELDS.LongitudeEquipmentImpacted]: this.state.longitudeEquipmentImpacted,
      [Consts.TSAFIELDS.AddressIncidentOccurred]: this.state.addressIncidentOccurred,
      [Consts.TSAFIELDS.ClosestCrossStreetToIncident]: this.state.closestCrossStreetToIncident,
      [Consts.TSAFIELDS.TownLocalityIncidentOccurred]: this.state.selTown,
      [Consts.TSAFIELDS.CountyIncidentOccurred]: this.state.selCounty,
      [Consts.TSAFIELDS.AgencyNotified]: this.state.selagencyNotified && this.state.selagencyNotified.join(", "),
      [Consts.TSAFIELDS.TSAShortDescription]: this.state.selShortDescription,
      [Consts.COMMONFIELDS.IncVersion]: Utilities.getNextMinorVersion(this.state.incVersion),
      [Consts.COMMONFIELDS.IncReportStatus]: Consts.INCSTATUS.Saved,
      [Consts.COMMONFIELDS.SubmittedDate]: new Date(),
      [Consts.COMMONFIELDS.LastEditedById]: this.currentUserId
    });

    /* if creating new incident or creating a new version of a submitted incident*/
    if (this.props.formMode == Consts.FORMMODE.New || this.state.incReportStatus == Consts.INCSTATUS.Submitted) {
      url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.TSA}')/items`;

      /* create list item */
      SPHttpService.Post(url, body).then((res) => {
        res.json().then((resJson) => {
          if (resJson && resJson.Id > 0) {
            /* attach files */
            PnPService.attachFilesToListItem(Consts.LISTTITLES.TSA, resJson.Id, this.state.attachmentFiles).then(() => {
              this.setState({
                showSubmitDialog: true,
                submitDialogText: `Incident report ${incidentNumber} saved successfully`
              });
            });
            /*Mark the current version as old*/
            if (this.state.incReportStatus == Consts.INCSTATUS.Submitted) {
              let reqBody: string = JSON.stringify({
                '__metadata': {
                  'type': Consts.LISTITEMENTTYPES.TSA
                },
                [Consts.COMMONFIELDS.LockStatus]: Consts.LOCKSTATUS.LOCKED,
                [Consts.COMMONFIELDS.IsLatestVersion]: false
              });

              let reqUrl = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.TSA}')/items(${this.props.itemId})`;
              SPHttpService.Update(reqUrl, reqBody).catch(err => console.log(err));
            }
          } else {
            this.setState({ errorMessage: "test" });
          }
        });
      }).catch((err) => {
        this.setState({ errorMessage: err });
      });
    }
    else if (this.props.formMode == Consts.FORMMODE.Edit && this.state.incReportStatus == Consts.INCSTATUS.Saved) {
      url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.TSA}')/items(${this.props.itemId})`;
      /* update list item and attach files */
      SPHttpService.Update(url, body).then((res) => {
        PnPService.attachFilesToListItem(Consts.LISTTITLES.TSA, this.props.itemId, this.state.attachmentFiles, this.attachments).then(() => {
          this.setState({
            showSubmitDialog: true,
            submitDialogText: `Incident report ${incidentNumber} saved successfully`
          });
        });
      }).catch((err) => {
        this.setState({ errorMessage: err });
      });
    }
  }

  /* submit incident when user clicks on submit button */
  private submitIncident() {
    let url: string;
    let incidentNumber: string;
    let promiseIncNumber: Promise<any>[] = [];
    //Generate new incident number if it is new report
    if (this.props.formMode == Consts.FORMMODE.New ||
      Math.floor(this.state.incVersion) == 0) {
      promiseIncNumber.push(ListService.getNextIncidentNumber(Consts.REPORTCODES.TSA).then((incNum: number) => {
        let dt: Date = new Date();
        let year = dt.getFullYear();
        let month = ("0" + (dt.getMonth() + 1)).slice(-2);
        let date = ("0" + dt.getDate()).slice(-2);
        let num = incNum < 10 ? `0${incNum}` : incNum;
        incidentNumber = `${Consts.REPORTCODES.TSA}-${year}${month}${date}-${num}`;
      })
      );
    }
    else {
      incidentNumber = this.state.utilityCompanyIncidentNumber;
    }
    /* create incident after incident number is identified */
    Promise.all(promiseIncNumber).then(() => {
      let body: string = JSON.stringify({
        '__metadata': {
          'type': Consts.LISTITEMENTTYPES.TSA
        },
        'Title': Consts.REPORTNAMES.TSA,
        [Consts.TSAFIELDS.UtilityCompanyIncidentNumber]: incidentNumber,
        [Consts.TSAFIELDS.UtilityName]: Consts.UtilityName,
        [Consts.TSAFIELDS.UtilityId]: Consts.UtilityId,
        [Consts.TSAFIELDS.UtilityPersonnelReportingId]: this.state.selPersonnelReportingId,
        [Consts.TSAFIELDS.UtilityPersonnelEmail]: this.state.personnelReportingEmail,
        [Consts.TSAFIELDS.UtilityPersonnelPhone]: this.state.personnelReportingPhone,
        [Consts.TSAFIELDS.IncidentReportedToUtilityCompanyDt]: this.state.incidentReportedToUtilityCompanyDt,

        [Consts.TSAFIELDS.IncidentReportedToTSOCDt]: this.state.incidentReportedToTSOCDt,
        [Consts.TSAFIELDS.IncidentOccurredDt]: this.state.incidentOccurredDt,
        [Consts.TSAFIELDS.TSOCStaffNotified]: this.state.tSOCStaffNotified,
        [Consts.TSAFIELDS.IncidentDescription]: this.state.incidentDescription,
        [Consts.TSAFIELDS.LatitudeEquipmentImpacted]: this.state.latitudeEquipmentImpacted,
        [Consts.TSAFIELDS.LongitudeEquipmentImpacted]: this.state.longitudeEquipmentImpacted,
        [Consts.TSAFIELDS.AddressIncidentOccurred]: this.state.addressIncidentOccurred,
        [Consts.TSAFIELDS.ClosestCrossStreetToIncident]: this.state.closestCrossStreetToIncident,
        [Consts.TSAFIELDS.TownLocalityIncidentOccurred]: this.state.selTown,
        [Consts.TSAFIELDS.CountyIncidentOccurred]: this.state.selCounty,
        [Consts.TSAFIELDS.AgencyNotified]: this.state.selagencyNotified && this.state.selagencyNotified.join(", "),
        [Consts.TSAFIELDS.TSAShortDescription]: this.state.selShortDescription,
        [Consts.COMMONFIELDS.IncVersion]: (Math.floor(this.state.incVersion) + 1).toString(),
        [Consts.COMMONFIELDS.SubmittedDate]: new Date(),
        [Consts.COMMONFIELDS.IncReportStatus]: Consts.INCSTATUS.Submitted,
        [Consts.COMMONFIELDS.IsLatestVersion]: true,
        [Consts.COMMONFIELDS.SendEmail]: true,
        [Consts.COMMONFIELDS.LastEditedById]: this.currentUserId
      });

      /* new list item will be created if this is a new incident or new version of an existing incident*/
      if (this.props.formMode == Consts.FORMMODE.New ||
        (this.props.formMode == Consts.FORMMODE.Edit && this.state.incReportStatus == Consts.INCSTATUS.Submitted)) {
        url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.TSA}')/items`;
        SPHttpService.Post(url, body).then((res) => {
          res.json().then((resJson) => {
            if (resJson && resJson.Id > 0) {
              PnPService.attachFilesToListItem(Consts.LISTTITLES.TSA, resJson.Id, this.state.attachmentFiles).then(() => {
                this.setState({
                  showSubmitDialog: true,
                  submitDialogText: `Incident report ${incidentNumber} submitted successfully`
                });
              });
              /*Mark the current version as old*/
              if (this.props.formMode == Consts.FORMMODE.Edit) {
                let reqBody: string = JSON.stringify({
                  '__metadata': {
                    'type': Consts.LISTITEMENTTYPES.TSA
                  },
                  [Consts.COMMONFIELDS.LockStatus]: Consts.LOCKSTATUS.LOCKED,
                  [Consts.COMMONFIELDS.IsLatestVersion]: false
                });
                let reqUrl = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.TSA}')/items(${this.props.itemId})`;
                SPHttpService.Update(reqUrl, reqBody).catch(err => console.log(err));
              }
            }
            else {
              this.setState({ errorMessage: "test" });
            }
          });
        }).catch((err) => {
          this.setState({ errorMessage: err });
        });
      }
      /* if a draft request is submitted, list item will be updated*/
      else if (this.props.formMode == Consts.FORMMODE.Edit && this.state.incReportStatus == Consts.INCSTATUS.Saved) {
        url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.TSA}')/items(${this.props.itemId})`;
        SPHttpService.Update(url, body).then((res) => {
          PnPService.attachFilesToListItem(Consts.LISTTITLES.TSA, this.props.itemId, this.state.attachmentFiles, this.attachments).then(() => {
            this.setState({
              showSubmitDialog: true,
              submitDialogText: `Incident report ${incidentNumber} submitted successfully`
            });
          });
        }).catch((err) => {
          this.setState({ errorMessage: err });
        });
      }
    });
  }

  /* change lock status of form to unlocked*/
  private unlockReport() {
    let body: string = JSON.stringify({
      '__metadata': {
        'type': Consts.LISTITEMENTTYPES.TSA
      },
      [Consts.COMMONFIELDS.LockStatus]: Consts.LOCKSTATUS.UNLOCKED
    });
    let url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.TSA}')/items(${this.props.itemId})`;
    SPHttpService.Update(url, body).then((res) => {
      this.setState({
        showConfirmDialog: false,
        showSubmitDialog: true,
        submitDialogText: `Incident report is unlocked`
      });
    }).catch((err) => {
      this.setState({ errorMessage: err });
    });
  }
  public componentDidMount() {
    /* load form boilerplate text */
    let formConfigPromise: Promise<any> = ListService.getFormConfigData(Consts.REPORTCODES.TSA);

    /* load form tooltips */
    let formTooltipsPromise: Promise<any> = ListService.getFormTooltips(Consts.REPORTCODES.TSA);

    /* load master list data for dropdowns */
    let masterListDataPromise: Promise<any> = ListService.getMasterListData(Consts.REPORTCODES.TSA);

    /* get current user permissions */
    let userGroupsPromise = PnPService.getCurrentUserGroups();

    Promise.all([formConfigPromise, formTooltipsPromise, masterListDataPromise, userGroupsPromise]).then((results) => {

      let footer: string = "";
      let tooltips = [];
      let items: IMasterList[] = [];

      /*boilerplate text */
      if (results[0] && results[0].value.length > 0) {
        footer = results[0].value[0]["Footer"];
      }

      /* get tooltips*/
      if (results[1] && results[1].value.length > 0) {
        results[1].value.forEach(item => {
          tooltips.push({
            key: item["Field"], value: item["Tooltip"]
          });
        });
      }

      /*master list data*/
      if (results[2]) {
        items = results[2].value;
      }

      /* user groups */
      if (results[3]) {
        this.isAdmin = results[3].indexOf(Consts.AdminGroup) > -1;
        this.isContributor = results[3].indexOf(Consts.ContributorsGroup) > -1;
      }

      /* update state */
      this.setState({
        footer: footer,
        tooltips: tooltips,
        masterListData: items,

        counties: this.getDropDownOptions(items, "County"),
        shortDescription: this.getDropDownOptions(items, "TSA Short Decription"),
        agencyNotified: this.getDropDownOptions(items, "Agencies Notified", false, "", true),
      });

      /* get current user profile properties for new request */
      var date = new Date();
      date.setSeconds(0);
      PnPService.spLoggedInUserDetails().then((user) => {
        this.currentUserId = user.Id;
        if (this.props.formMode == Consts.FORMMODE.New && (this.isAdmin || this.isContributor)) {
          this.setState({
            selPersonnelReportingId: user.Id,
            selPersonnelReporting: this.props.currentUser.email,
            personnelReportingEmail: this.props.currentUser.email,
            personnelReportingPhone: user.WorkPhone,
            incidentReportedToUtilityCompanyDt: date,
            showSaveBtn: true,
            showSubmitBtn: true
          });
        }
        else if (this.props.formMode == Consts.FORMMODE.Edit) {
          this.loadReportData();
        }
      });
    });
  }

  /* get tooltip of a fie,d from state */
  private getToolTipForField(fieldName: string): string {
    let tooltips = this.state.tooltips;
    let tooltip = "";
    if (tooltips && tooltips.length > 0) {
      let item = tooltips.filter(t => t.key == fieldName);
      if (item.length > 0) {
        tooltip = item[0].value;
      }
    }
    return tooltip;
  }

  public render(): React.ReactElement<ITsaPipelineSecurityProps> {
    const getKey = `datetime-${new Date().getTime()}`; /*Dummy key to forece render DateTime picker - to handle bug */
    const imgLogoI: string = require("../../../images/logoi.png");
    const {
      selPersonnelReportingId,
      personnelReportingEmail,
      personnelReportingPhone,
      incidentReportedToTSOCDt,
      incidentOccurredDt,
      incidentReportedToUtilityCompanyDt,
      addressIncidentOccurred
    } = this.state;

    /* validate mandatory fields on the form and enable submit button */
    let isFormValid: boolean = false;
    if (selPersonnelReportingId
      && personnelReportingEmail
      && personnelReportingPhone
      && incidentReportedToTSOCDt
      && incidentOccurredDt
      && incidentReportedToUtilityCompanyDt
      && addressIncidentOccurred) {
      isFormValid = true;
    }
    return (
      <div id="tsaForm">
        <div className={styles["content-megacontainer"]}>
          <div className={styles["container-n"]}>
            <h4 className={styles["heading1"]}>TSA Pipeline Notification Form</h4>
          </div>
          {this.props.formMode == Consts.FORMMODE.Edit && this.state.reportJson &&
            <div style={{ marginLeft: "65%" }}>
              {/* <CommandBarButton iconProps={{ iconName: "PDF" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Export as PDF" onClick={() => this.onExportPDFClick()} /> */}
              <CommandBarButton iconProps={{ iconName: "WordDocument" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Export as Word" onClick={() => this.onExportWordClick()} />
              <CommandBarButton iconProps={{ iconName: "Print" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Print / Save as PDF" onClick={() => this.onPrintlick()} />
              <CommandBarButton iconProps={{ iconName: "Mail" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Email" onClick={() => this.setState({ showEmailDialog: true })} />
            </div>
          }
          <hr className={styles["line"]} />
          <div className={styles["s"]}>
            {this.props.formMode == Consts.FORMMODE.Edit &&
              <p>Utilty Incident Number : <span className={styles["span1"]}>{this.state.utilityCompanyIncidentNumber}</span>
                <span className={styles["span2"]}>CHGE "1001"</span>
              </p>
            }
            <p>Utilty Name : <span className={styles["span3"]}>Central Hudson Gas & Electric Corp.</span></p>
            <br></br>
          </div>

          <form>
            <div className={styles["content-container"]}>
              <p className={styles["heading"]}>Reporting Details<a href="#"><TooltipHost content={this.getToolTipForField("Reporting Details")}><img src={imgLogoI} /></TooltipHost></a></p>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Personnel Reporting <span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <PeoplePicker
                        context={this.props.context}
                        personSelectionLimit={1}
                        ensureUser={true}
                        onChange={(items) => this.onPeoplePickerChange(items)}
                        principalTypes={[PrincipalType.User]}
                        resolveDelay={100}
                        defaultSelectedUsers={[this.state.selPersonnelReporting]} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Email<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="personnelReportingEmail" value={this.state.personnelReportingEmail} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Phone Number<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="personnelReportingPhone" value={this.state.personnelReportingPhone} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>
                  <h5 className={styles["heading"]}>Date and Time Reported to TSOC<span className={styles["star"]}>*</span><a href="#"><TooltipHost content={this.getToolTipForField("Date and Time Reported to TSOC")}><img src={imgLogoI} /></TooltipHost></a></h5>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.incidentReportedToTSOCDt} onChange={(val) => this.onIncReportToTSOCDtChange(val)} />
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>TSOC Staff who <br />received call:<a href="#"><TooltipHost content={this.getToolTipForField("TSOC Staff who received call")}><img src={imgLogoI} /></TooltipHost></a></label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='tSOCStaffNotified' value={this.state.tSOCStaffNotified} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>

                <div className={styles["column-2"]}>
                  <h5 className={styles["heading"]}>Date and Time the Incident Occurred<span className={styles["star"]}>*</span>
                    <a href="#"><TooltipHost content={this.getToolTipForField("Date and Time the Incident Occurred")}><img src={imgLogoI} /></TooltipHost></a></h5>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.incidentOccurredDt} onChange={(val) => this.onOccurDateChange(val)} />
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>TSA Incident <br /> Short Descriptions<a href="#"><TooltipHost content={this.getToolTipForField("TSA Incident Short Description")}><img src={imgLogoI} /></TooltipHost></a></label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selShortDescription" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.selShortDescription} options={this.state.shortDescription} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Incident Description/<br /> Action Taken<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["text-area-container"]}>
                      <TextField multiline rows={3} name='incidentDescription' value={this.state.incidentDescription} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["two-columns-container"]}></div>
              <h5 className={styles["heading"]}>Areas Details<a href="#"><TooltipHost content={this.getToolTipForField("Areas Details")}><img src={imgLogoI} /></TooltipHost></a></h5>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Address or Approx.<br /> Location of Incident<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.addressIncidentOccurred} name='addressIncidentOccurred' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}></label>
                    </div>
                    <div className={styles["input-container"]}>
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Latitude :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.latitudeEquipmentImpacted} name='latitudeEquipmentImpacted' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>

                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Town / Locality of <br />Incident :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.selTown} name='selTown' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>

                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Location Description/<br />Cross Street:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.closestCrossStreetToIncident} name='closestCrossStreetToIncident' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}></label>
                    </div>
                    <div className={styles["input-container"]}>
                      <DefaultButton className={styles["longbutton"]} text="Get Latitude and Longitude" onClick={() => this.onGetLatLongClick()} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Longitude :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.longitudeEquipmentImpacted} name='longitudeEquipmentImpacted' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>County of Incident :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selCounty" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.selCounty} options={this.state.counties} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles["two-columns-container"]}></div>
              <h5 className={styles["heading"]}>Personnel / Agencies Notified:<a href="#"><TooltipHost content={this.getToolTipForField("Personnel / Agencies Notified")}><img src={imgLogoI} /></TooltipHost></a></h5>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Personnel / Agencies Notified:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selagencyNotified" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKeys={this.state.selagencyNotified} options={this.state.agencyNotified} multiSelect onChange={(e, o) => this.onMultiDropdownChange(e, o)} />
                    </div>
                  </div>
                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Additional Attachments:</label>
                      <PrimaryButton className={styles["attach"]} onClick={(e) => this.onAttchSelect(e)}>Choose Files</PrimaryButton>
                      <input type="file" ref={this.fileAttachRef} multiple={true} onChange={(e) => this.onAttachmentChange(e)} hidden />
                      {
                        this.state.attachmentFiles.length > 0 &&
                        <ul className={styles["attachment-list-alignment"]}>
                          {this.state.attachmentFiles.map((file: IFileInfo, index: number) => {
                            return (<li>{file.url ? (<a download={file.name} href={file.url} data-interception="off" target="_blank">{file.name}</a>) : <i>{file.name}</i>} <FontIcon iconName="Delete" onClick={(e) => this.onDeleteAttachment(e, index)} /></li>);
                          })
                          }
                        </ul>
                      }
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["bottomButton"] + ' ' + styles["btn-gap"]}>
                <DefaultButton className={styles["bottomButton__one"]} text="Cancel" onClick={(e) => this.onCancelClick()} />
                {
                  this.state.showSaveBtn &&
                  <DefaultButton className={styles["bottomButton__two"]} text="Save" onClick={() => this.saveIncident()} />
                }
                {
                  this.state.showSubmitBtn &&
                  <PrimaryButton className={styles["bottomButton__three"]} text="Submit" disabled={!isFormValid} onClick={() => this.submitIncident()} />
                }
                {
                  this.state.showUnlockBtn &&
                  <PrimaryButton className={styles["bottomButton__three"]} text="Unlock Report"
                    onClick={() => this.setState({
                      showConfirmDialog: true,
                      confirmDialogText: "Are you sure you want to unlock this report?",
                      onConfirmDialog: () => this.unlockReport()
                    })} />
                }
              </div>
            </div>
            <hr className={styles["line"]} />
            <div className={styles["v"]}>
              <p className={styles["message"]}>{this.state.footer}</p>
            </div>
          </form>
        </div>
        <SubmitDialog
          showDialog={this.state.showSubmitDialog}
          hideDialog={() => { this.setState({ showSubmitDialog: false }); }}
          dialogTitle={this.state.submitDialogTitle}
          dialogText={this.state.submitDialogText}
          siteUrl={this.props.siteUrl}
          reportsPageUrl={this.props.siteUrl + Consts.REPORTPAGEURLS.TSA}
          className={styles.dialogContent} />
        <ConfirmDialog
          showDialog={this.state.showConfirmDialog}
          hideDialog={() => { this.setState({ showConfirmDialog: false }); }}
          onConfirm={this.state.onConfirmDialog}
          dialogText={this.state.confirmDialogText}
          className={styles.dialogContent} />
        <SendEmailDialog
          showDialog={this.state.showEmailDialog}
          hideDialog={() => { this.setState({ showEmailDialog: false }); }}
          title={this.state.item && this.state.item["Title"]}
          incidentNumber={this.state.utilityCompanyIncidentNumber}
          mailBody={this.state.reportJson}
          className={styles.dialogContent} />
      </div>
    );
  }
}
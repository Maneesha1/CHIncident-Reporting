import { IItem } from '@pnp/sp/items';
import { IFilePickerResult } from '@pnp/spfx-controls-react/lib/FilePicker';
import { IDropdownOption, ICheckbox } from 'office-ui-fabric-react';
import { IFileInfo } from '../../../models/IFileInfo';
import { IMasterList } from '../../../models/IMasterList';

export interface ITsaPipelineSecurityState {
    item: IItem;
    utilityCompanyIncidentNumber: string;

    utilityId:string;
    utilityName:string;
    selPersonnelReportingId: string;
    selPersonnelReporting: string;
    selPersonnelReportingName: string;
    personnelReportingEmail: string;
    personnelReportingPhone: string;
    incidentReportedToUtilityCompanyDt: Date;

    addressIncidentOccurred: string;
    closestCrossStreetToIncident: string;
    selCounty: string;
    incidentDescription: string;
    latitudeEquipmentImpacted: string;
    longitudeEquipmentImpacted: string;
    selTown: string;
    tSOCStaffNotified: string;
    incidentReportedToTSOCDt: Date;
    selagencyNotified: string[];
    selShortDescription: string;
    incidentOccurredDt: Date;

    incVersion: number;
    incReportStatus: string;
    submittedDate: Date;
    isLatestVersion: boolean;

    attachmentFiles: IFileInfo[];
    masterListData: IMasterList[];
    towns: IDropdownOption[];
    counties: IDropdownOption[];
    shortDescription: IDropdownOption[];
    agencyNotified: IDropdownOption[];

    showSubmitDialog: boolean;
    showConfirmDialog: boolean;
    showEmailDialog: boolean;
    submitDialogTitle: string;
    submitDialogText: string;
    confirmDialogText: string;
    onConfirmDialog: () => void;
    errorMessage: string;
    showSaveBtn: boolean;
    showSubmitBtn: boolean;
    showUnlockBtn: boolean;
    reportJson: string;

    footer: string;
    tooltips: any[];
}
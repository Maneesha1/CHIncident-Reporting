declare interface ITsaPipelineSecurityWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'TsaPipelineSecurityWebPartStrings' {
  const strings: ITsaPipelineSecurityWebPartStrings;
  export = strings;
}

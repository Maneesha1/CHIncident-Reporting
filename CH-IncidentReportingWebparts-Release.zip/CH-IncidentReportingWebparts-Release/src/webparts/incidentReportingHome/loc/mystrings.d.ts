declare interface IIncidentReportingHomeWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'IncidentReportingHomeWebPartStrings' {
  const strings: IIncidentReportingHomeWebPartStrings;
  export = strings;
}

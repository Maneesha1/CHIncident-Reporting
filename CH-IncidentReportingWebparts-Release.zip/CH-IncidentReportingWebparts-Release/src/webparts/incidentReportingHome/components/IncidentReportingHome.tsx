import * as React from 'react';
import styles from './IncidentReportingHome.module.scss';
import { IIncidentReportingHomeProps } from './IIncidentReportingHomeProps';
import { escape } from '@microsoft/sp-lodash-subset';
import * as Consts from '../../../common/constants';

export default class IncidentReportingHome extends React.Component<IIncidentReportingHomeProps, {}> {
  public render(): React.ReactElement<IIncidentReportingHomeProps> {
    let imgSearch: string = require("../../../images/Search.png");
    let imgCreate: string = require("../../../images/nouncreate1409604.png");
    let imgPsc: string = require("../../../images/PSCicon.png");
    let imgGas: string = require("../../../images/gasicon.png");
    let imgSpills: string = require("../../../images/spills.png");
    let imgMarkouts: string = require("../../../images/markouts.png");
    let imgGL45: string = require("../../../images/gas45.png");
    let imgGL60: string = require("../../../images/gas60.png");
    let imgSaf: string = require("../../../images/safety.png");
    let imgDot: string = require("../../../images/dot.png");
    let imgTsa: string = require("../../../images/tsaicon.png");
    return (
      <div className={styles["wrapper"]}>
        <div className={styles["wrap-container"]}>
          <section className={styles["event-report"]}>
            <h1>Event Reports</h1>
            <div className={styles["box-items"]}>
              <ul>
                <li>
                  <div className={styles["box-content"]}>
                    <img src={imgPsc} />
                    <p>PSC ELECTRIC</p>
                  </div>
                  <div className={styles["box-strip"]}>
                    <a className={styles["search-icon"]} href={this.props.siteUrl + Consts.REPORTPAGEURLS.PSCE}>
                      <img src={imgSearch} />
                    </a>
                    <a className={styles["plus-icon"]} href={this.props.siteUrl + Consts.FORMURLS.PSCE}>
                      <img src={imgCreate} />
                    </a>
                  </div>
                </li>
                <li>
                  <div className={styles["box-content"]}>
                    <img src={imgGas} />
                    <p>PSC GAS OR CO</p>
                  </div>
                  <div className={styles["box-strip"]}>
                    <a className={styles["search-icon"]} href={this.props.siteUrl + Consts.REPORTPAGEURLS.PSCG}>
                      <img src={imgSearch} />
                    </a>
                    <a className={styles["plus-icon"]} href={this.props.siteUrl + Consts.FORMURLS.PSCG}>
                      <img src={imgCreate} />
                    </a>
                  </div>
                </li>
                <li>
                  <div className={styles["box-content"]}>
                    <img src={imgSaf} />
                    <p>SAFETY</p>
                  </div>
                  <div className={styles["box-strip"]}>
                    <a className={styles["search-icon"]} href={this.props.siteUrl + Consts.REPORTPAGEURLS.SAF}>
                      <img src={imgSearch} />
                    </a>
                    <a className={styles["plus-icon"]} href={this.props.siteUrl + Consts.FORMURLS.SAF}>
                      <img src={imgCreate} />
                    </a>
                  </div>
                </li>
                <li>
                  <div className={styles["box-content"]}>
                    <img src={imgSpills} />
                    <p>SPILLS</p>
                  </div>
                  <div className={styles["box-strip"]}>
                    <a className={styles["search-icon"]} href={this.props.siteUrl + Consts.REPORTPAGEURLS.SPL}>
                      <img src={imgSearch} />
                    </a>
                    <a className={styles["plus-icon"]} href={this.props.siteUrl + Consts.FORMURLS.SPL}>
                      <img src={imgCreate} />
                    </a>
                  </div>
                </li>
                <li>
                  <div className={styles["box-content"]}>
                    <img src={imgMarkouts} />
                    <p>MARKOUTS</p>
                  </div>
                  <div className={styles["box-strip"]}>
                    <a className={styles["search-icon"]} href={this.props.siteUrl + Consts.REPORTPAGEURLS.GTMO}>
                      <img src={imgSearch} />
                    </a>
                    <a className={styles["plus-icon"]} href={this.props.siteUrl + Consts.FORMURLS.GTMO}>
                      <img src={imgCreate} />
                    </a>
                  </div>
                </li>
                <li>
                  <div className={styles["box-content"]}>
                    <img src={imgGL45} />
                    <p>GAS 45 MIN</p>
                  </div>
                  <div className={styles["box-strip"]}>
                    <a className={styles["search-icon"]} href={this.props.siteUrl + Consts.REPORTPAGEURLS.GL45}>
                      <img src={imgSearch} />
                    </a>
                    <a className={styles["plus-icon"]} href={this.props.siteUrl + Consts.FORMURLS.GL45}>
                      <img src={imgCreate} />
                    </a>
                  </div>
                </li>
                <li>
                  <div className={styles["box-content"]}>
                    <img src={imgGL60} />
                    <p>GAS 60 MIN</p>
                  </div>
                  <div className={styles["box-strip"]}>
                    <a className={styles["search-icon"]} href={this.props.siteUrl + Consts.REPORTPAGEURLS.GL60}>
                      <img src={imgSearch} />
                    </a>
                    <a className={styles["plus-icon"]} href={this.props.siteUrl + Consts.FORMURLS.GL60}>
                      <img src={imgCreate} />
                    </a>
                  </div>
                </li>
                <li>
                  <div className={styles["box-content"]}>
                    <img src={imgDot} />
                    <p>DOT</p>
                  </div>
                  <div className={styles["box-strip"]}>
                    <a className={styles["search-icon"]} href={this.props.siteUrl + Consts.REPORTPAGEURLS.DOT}>
                      <img src={imgSearch} />
                    </a>
                    <a className={styles["plus-icon"]} href={this.props.siteUrl + Consts.FORMURLS.DOT}>
                      <img src={imgCreate} />
                    </a>
                  </div>
                </li>
                <li>
                  <div className={styles["box-content"]}>
                    <img src={imgTsa} />
                    <p>TSA PIPELINE</p>
                  </div>
                  <div className={styles["box-strip"]}>
                    <a className={styles["search-icon"]} href={this.props.siteUrl + Consts.REPORTPAGEURLS.TSA}>
                      <img src={imgSearch} />
                    </a>
                    <a className={styles["plus-icon"]} href={this.props.siteUrl + Consts.FORMURLS.TSA}>
                      <img src={imgCreate} />
                    </a>
                  </div>
                </li>
              </ul>
            </div>
          </section>
          <section className={styles["quick-view"]}>
            <h1>Quick View</h1>
            <div className={styles["box-items"]}>
            <div >
              <ul>
                <li>
                  <div className={styles["box-grid"]}>
                    
                    <a className={styles["dropdown-item"]} href={this.props.siteUrl + Consts.REPORTPAGEURLS.ALLREPORTS + "?filterkey=my"}>My Reports</a>
                  </div>
                </li>
                <li>
                  <div className={styles["box-grid"]}>
                    <a className={styles["dropdown-item"]} href={this.props.siteUrl + Consts.REPORTPAGEURLS.ALLREPORTS + "?filterkey=saved"}>Saved Reports</a>
                  </div>
                </li>
                <li>
                  <div className={styles["box-grid"]}>
                    <a  className={styles["dropdown-item"]} href={this.props.siteUrl + Consts.REPORTPAGEURLS.ALLREPORTS + "?filterkey=submitted"}>Submitted Reports</a>
                  </div>
                </li>
              </ul>
              </div>
            </div>
          </section>
        </div>
        <footer>
          <a className={styles["float-left"]}>Central Hudson Gas & Electric Corp.</a>
          <a className={styles["float-right"]}>© 2020 All rights reserved</a>
        </footer>
      </div>
    );
  }
}

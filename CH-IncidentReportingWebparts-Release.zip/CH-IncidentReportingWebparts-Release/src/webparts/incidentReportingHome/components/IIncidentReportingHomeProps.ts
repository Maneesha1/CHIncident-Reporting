export interface IIncidentReportingHomeProps {
  siteUrl: string;
}

declare interface IPscElectricEventWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'PscElectricEventWebPartStrings' {
  const strings: IPscElectricEventWebPartStrings;
  export = strings;
}

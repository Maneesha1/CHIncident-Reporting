import * as React from 'react';
import styles from './Safety.module.scss';
import { ISafetyProps } from './ISafetyProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { TextField, DefaultButton, PrimaryButton, CommandBarButton, IDropdownOption, Dropdown, TooltipHost } from 'office-ui-fabric-react';
import { FontIcon } from 'office-ui-fabric-react/lib/Icon';
import { DateTimePicker, TimeConvention, TimeDisplayControlType } from '@pnp/spfx-controls-react/lib/DateTimePicker';
import ListService from '../../../services/ListService';
import PnPService from '../../../services/PnPService';
import SPHttpService from "../../../services/SPHttpService";
import * as Consts from '../../../common/constants';
import { IMasterList } from '../../../models/IMasterList';
import { IFileInfo } from '../../../models/IFileInfo';
import { IPSafetyEventState } from './IPSafetyEventState';
import { IUserProfile } from '../../../models/IUserProfile';
import { StatusDialog } from "../../../common/components/StatusDialog";
import { ConfirmDialog } from "../../../common/components/ConfirmDialog";
import { SubmitDialog } from "../../../common/components/SubmitDialog";
import PDFService from "../../../services/PDFService";
import WordService from "../../../services/WordService";
import Utilities from "../../../services/Utilities";
import { SendEmailDialog } from '../../../common/components/SendEmailDialog';


export default class SafetyEvent extends React.Component<ISafetyProps, IPSafetyEventState> {

  private fileAttachRef;
  private isAdmin: boolean = false;
  private isContributor: boolean = false;
  private currentUserId: number;
  private attachments: string[] = [];

  constructor(props: ISafetyProps, state: IPSafetyEventState) {
    super(props);

    this.state = {
      item: null,
      attachmentFiles: [],
      masterListData: null,
      utilityCompanyIncidentNumber: null,
      utilityId: null,
      utilityName: null,
      selPersonnelReportingId: null,
      selPersonnelReportingEMail: null,
      selPersonnelReportingName: null,
      personnelReportingEmail: null,
      personnelReportingPhone: null,

      addressIncidentOccurred: null,
      closestCrossStreetToIncident: null,
      countyIncidentOccurred: null,
      townLocalityIncidentOccurred: null,
      incidentDescription: null,
      incidentOccurredDt: null,
      incidentReportDt: null,
      reportUpdateDt: null,
      reportUpdateDesc: null,
      injuryDescription: null,
      employeeDepartment: null,
      employeePriClass: null,
      safetyDeptPersonnel: null,
      safetyReportType: null,
      supervisorName: null,
      supervisorPhone: null,
      cHInternalNotes: null,

      incVersion: 0,
      incReportStatus: null,
      submittedDate: null,
      isLatestVersion: null,

      countyincidentOccurred: [],
      townlocalityIncidentOccurred: [],
      safetyreportType: [],
      safetydeptPersonnel: [],


      showSubmitDialog: false,
      showConfirmDialog: false,
      showStatusDialog: false,
      showEmailDialog: false,
      submitDialogTitle: "Success",
      submitDialogText: null,
      statusDialogTitle: null,
      statusDialogText: null,
      confirmDialogText: null,
      onConfirmDialog: null,
      errorMessage: null,
      showSaveBtn: false,
      showSubmitBtn: false,
      showUnlockBtn: false,
      //showSubmitToPSCBtn: false,
      reportJson: null,

      footer: null,
      tooltips: null
    };
    this.fileAttachRef = React.createRef();
  }


  /** Event Handlers **/

  /* Attachment button select event */
  private onAttchSelect(e) {
    e.preventDefault();
    this.fileAttachRef.current.click();
  }

  /* Attachment file change event */
  private onAttachmentChange(event) {
    let resultFile = event.target.files;
    let fileInfos: IFileInfo[] = [];
    let promArr: Promise<any>[] = [];

    for (var i = 0; i < resultFile.length; i++) {
      var file = resultFile[i];
      var reader = new FileReader();
      promArr.push(new Promise((resolve, reject) => {
        reader.onload = ((fileToRead) => {
          return (e) => {
            //Push the converted file into array
            fileInfos.push({
              "name": fileToRead.name,
              "content": e.target.result
            });
            resolve();
          };
        })(file);
        reader.readAsArrayBuffer(file);
      }));
    }

    /* Load attachments to state after they are all read */
    Promise.all(promArr).then(() => {
      this.setState({
        attachmentFiles: [...this.state.attachmentFiles, ...fileInfos]
      });
    });
  }

  /* Cancel button click event */
  private onCancelClick() {
    window.location.href = this.props.siteUrl;
  }

  /* Delete attachment event */
  private onDeleteAttachment(event, index) {
    let attachments = this.state.attachmentFiles;
    attachments.splice(index, 1);
    this.setState({
      attachmentFiles: attachments
    });
  }


  private onDropDownChange(event, selItem: IDropdownOption) {
    this.setState({
      ...this.state,
      [event.target.id]: selItem.text,
    });
  }

  /* export to pdf */
  private onExportPDFClick() {
    PDFService.ExportToPDFFromHTML(this.state.item["UtilityCompanyIncidentNumber"], this.state.item["Title"], this.state.reportJson);
  }

  /* export to word */
  private onExportWordClick() {
    WordService.generateDocument(this.state.item["UtilityCompanyIncidentNumber"], this.state.item["Title"], this.state.reportJson);
  }

  /* export to word */
  private onPrintlick() {
    Utilities.printHtml(this.state.item["UtilityCompanyIncidentNumber"], this.state.item["Title"], this.state.reportJson);
  }

  /* people picker change event */
  private onPeoplePickerChange(items: any[]) {
    if (items.length > 0) {
      PnPService.getUserProfileProperties(items[0].loginName).then((userProps: IUserProfile) => {
        this.setState({
          selPersonnelReportingId: items[0].id,
          selPersonnelReportingEMail: userProps.WorkEmail,
          personnelReportingEmail: userProps.WorkEmail,
          personnelReportingPhone: userProps.WorkPhone
        });
      });
    }
    else {
      this.setState({
        selPersonnelReportingId: null,
        selPersonnelReportingEMail: null,
        personnelReportingEmail: null,
        personnelReportingPhone: null
      });
    }
  }

  /* text field change event */
  private onTextChange(event) {
    const value = event.target.value;
    this.setState(
      {
        ...this.state,
        [event.target.name]: value
      }
    );
  }

  //============================
  // date time incident reported
  //=============================
  private IncidentReportDt(value) {
    this.setState(
      {
        ...this.state,
        incidentReportDt: value
      }
    );
  }


  //===============================
  // date time incident occurred
  //===============================
  private IncidentOccurredDt(value) {
    this.setState(
      {
        ...this.state,
        incidentOccurredDt: value
      }
    );
  }


  //===============================
  // date time report update date 
  //===============================
  private ReportUpdateDt(value) {
    this.setState(
      {
        ...this.state,
        reportUpdateDt: value
      }
    );
  }



  /**Helper Functions **/
  private bindAttachmentsFromList(resultFile) {
    let fileInfos: IFileInfo[] = [];
    let promArr: Promise<any>[] = [];

    for (var i = 0; i < resultFile.length; i++) {
      var attFile = resultFile[i];
      ((file) => {
        promArr.push(new Promise((resolve, reject) => {
          fetch(Consts.SITEURLS.ROOTSITE + file.ServerRelativeUrl).then(e => {
            let content = e.arrayBuffer();
            content.then(c => {
              fileInfos.push({
                "name": file.FileName,
                "content": c,
                "url": Consts.SITEURLS.ROOTSITE + file.ServerRelativeUrl
              });
              resolve();
            });
          });
        }));
      })(attFile);
    }

    Promise.all(promArr).then(() => {
      this.setState({
        attachmentFiles: fileInfos
      });
    });
  }

  private getDropDownOptions(items: IMasterList[], category: string, removeDuplicates: boolean = false, key: string = "", multiselect: boolean = false): IDropdownOption[] {
    let values: any[] = items.filter(item => item.Category == category);
    if (removeDuplicates) {
      values = this.removeDuplicatesFromArray(values, key);
    }
    let ddlOptions: IDropdownOption[] = [];
    if (!multiselect) {
      ddlOptions.push({ key: "", text: "" });
    }
    values.map(item => ddlOptions.push({
      key: item.SubCategory, text: item.SubCategory
    }));
    ddlOptions.sort((a, b) => a.text.localeCompare(b.text));
    return ddlOptions;
  }



  /*Load report data based on ID in query string */

  private async loadReportData() {

    let allowSave: boolean = false;
    let allowSubmit: boolean = false;
    let allowUnlock: boolean = false;
    let submittedDt: Date = null;

    PnPService.getItemById(Consts.LISTTITLES.SAF, this.props.itemId, Consts.SELECTFIELDS.SAF, Consts.EXPANDFIELDS.SAF).then((item) => {

      if (item["Attachments"] == true) {
        item["AttachmentFiles"].forEach(file => {
          console.log(`${file.FileName}-${file.FileNameAsPath}-${file.ServerRelativePath}-${file.ServerRelativeUrl}`);
          this.attachments.push(file.FileName);
        });
        this.bindAttachmentsFromList(item["AttachmentFiles"]);
      }

      /* check save & submit conditions */
      if (this.isAdmin || this.isContributor) {
        /*Allow editing if it is a draft request */
        if (item[Consts.COMMONFIELDS.IncReportStatus] == Consts.INCSTATUS.Saved) {
          allowSave = true;
          allowSubmit = true;
        }
        /*Allow editing on latest versions of submitted request */
        else if (item[Consts.COMMONFIELDS.IncReportStatus] == Consts.INCSTATUS.Submitted && item[Consts.COMMONFIELDS.IsLatestVersion]) {

          if (item[Consts.COMMONFIELDS.SubmittedDate]) {

            submittedDt = new Date(item[Consts.COMMONFIELDS.SubmittedDate]);
            let elapsedTime = (new Date().getTime() - submittedDt.getTime()) / (1000 * 60 * 60);

            /*Allow editing within specified hours or if admin unlocked form */
            if (elapsedTime <= Consts.EditHours || item[Consts.COMMONFIELDS.LockStatus] == Consts.LOCKSTATUS.UNLOCKED) {
              allowSave = true;
              allowSubmit = true;
            }

            /*Allow unlock beyond specified time if user is admin */
            if (elapsedTime > Consts.EditHours && this.isAdmin && item[Consts.COMMONFIELDS.LockStatus] != Consts.LOCKSTATUS.UNLOCKED) {
              allowUnlock = true;
            }
          }
        }
      }

      /* Build HTML Table for Export to PDF, WORD and Send Mail */
      let repTable = Utilities.buildItemHTMLTable(item, Consts.SELECTFIELDS.SAF);

      /* update state to load form with data */
      this.setState({
        item: item,
        reportJson: repTable,
        utilityCompanyIncidentNumber: item[Consts.SAFFIELDS.UtilityCompanyIncidentNumber],
        utilityId: item[Consts.SAFFIELDS.UtilityId],
        utilityName: item[Consts.SAFFIELDS.UtilityName],
        selPersonnelReportingId: item[Consts.SAFFIELDS.UtilityPersonnelReportingId],
        selPersonnelReportingEMail: item[Consts.SAFFIELDS.UtilityPersonnelReporting] ? item[Consts.SAFFIELDS.UtilityPersonnelReporting]["EMail"] : null,
        selPersonnelReportingName: item[Consts.SAFFIELDS.UtilityPersonnelReporting] ? item[Consts.SAFFIELDS.UtilityPersonnelReporting]["Title"] : null,
        personnelReportingEmail: item[Consts.SAFFIELDS.UtilityPersonnelEmail],
        personnelReportingPhone: item[Consts.SAFFIELDS.UtilityPersonnelPhone],

        addressIncidentOccurred: item[Consts.SAFFIELDS.AddressIncidentOccurred],
        closestCrossStreetToIncident: item[Consts.SAFFIELDS.ClosestCrossStreetToIncident],
        countyIncidentOccurred: item[Consts.SAFFIELDS.CountyIncidentOccurred],
        incidentDescription: item[Consts.SAFFIELDS.IncidentDescription],
        incidentOccurredDt: item[Consts.SAFFIELDS.IncidentOccurredDt] ? new Date(item[Consts.SAFFIELDS.IncidentOccurredDt]) : null,
        townLocalityIncidentOccurred: item[Consts.SAFFIELDS.TownLocalityIncidentOccurred],

        incidentReportDt: item[Consts.SAFFIELDS.IncidentReportDt] ? new Date(item[Consts.SAFFIELDS.IncidentReportDt]) : null,
        reportUpdateDt: item[Consts.SAFFIELDS.ReportUpdateDt] ? new Date(item[Consts.SAFFIELDS.ReportUpdateDt]) : null,
        reportUpdateDesc: item[Consts.SAFFIELDS.ReportUpdateDesc],
        injuryDescription: item[Consts.SAFFIELDS.InjuryDescription],
        employeeDepartment: item[Consts.SAFFIELDS.EmployeeDepartment],

        employeePriClass: item[Consts.SAFFIELDS.EmployeePriClass],
        safetyDeptPersonnel: item[Consts.SAFFIELDS.SafetyDeptPersonnel],
        safetyReportType: item[Consts.SAFFIELDS.SafetyReportType],
        supervisorName: item[Consts.SAFFIELDS.SupervisorName],
        supervisorPhone: item[Consts.SAFFIELDS.SupervisorPhone],


        incVersion: item[Consts.COMMONFIELDS.IncVersion],
        submittedDate: submittedDt,
        isLatestVersion: item[Consts.COMMONFIELDS.IsLatestVersion],
        incReportStatus: item[Consts.COMMONFIELDS.IncReportStatus],
        showSaveBtn: allowSave,
        showSubmitBtn: allowSubmit,
        showUnlockBtn: allowUnlock
      });

    }).catch(err => {
      console.log(err);
    });
  }

  /* remove duplicates from a given array*/
  private removeDuplicatesFromArray(arr: any[], key: string): any[] {
    return arr.reduce((accumulator, currentValue) => {
      const value = currentValue[key];
      if (!accumulator.some(item => item[key] === value)) {
        accumulator.push(currentValue);
      }
      return accumulator;
    }, []);
  }

  /* create or update incident when user clicks on save button */
  private saveIncident() {
    let incidentNumber: string;
    let url: string;

    if (this.props.formMode == Consts.FORMMODE.New) {
      let dt: Date = new Date();
      let year = dt.getFullYear();
      let month = ("0" + (dt.getMonth() + 1)).slice(-2);
      let date = ("0" + dt.getDate()).slice(-2);
      incidentNumber = `${Consts.REPORTCODES.SAF}-${year}${month}${date}-Draft`;
    }
    else if (this.props.formMode == Consts.FORMMODE.Edit) {
      incidentNumber = this.state.utilityCompanyIncidentNumber;
    }

    let body: string = JSON.stringify({
      '__metadata': {
        'type': Consts.LISTITEMENTTYPES.SAF
      },
      'Title': Consts.REPORTNAMES.SAF,
      [Consts.SAFFIELDS.UtilityCompanyIncidentNumber]: incidentNumber,
      [Consts.SAFFIELDS.UtilityId]: Consts.UtilityId,
      [Consts.SAFFIELDS.UtilityName]: Consts.UtilityName,
      [Consts.SAFFIELDS.UtilityPersonnelReportingId]: this.state.selPersonnelReportingId,
      [Consts.SAFFIELDS.UtilityPersonnelEmail]: this.state.personnelReportingEmail,
      [Consts.SAFFIELDS.UtilityPersonnelPhone]: this.state.personnelReportingPhone,

      [Consts.SAFFIELDS.AddressIncidentOccurred]: this.state.addressIncidentOccurred,
      [Consts.SAFFIELDS.ClosestCrossStreetToIncident]: this.state.closestCrossStreetToIncident,
      [Consts.SAFFIELDS.CountyIncidentOccurred]: this.state.countyIncidentOccurred,
      [Consts.SAFFIELDS.IncidentDescription]: this.state.incidentDescription,
      [Consts.SAFFIELDS.IncidentOccurredDt]: this.state.incidentOccurredDt,
      [Consts.SAFFIELDS.TownLocalityIncidentOccurred]: this.state.townLocalityIncidentOccurred,
      [Consts.SAFFIELDS.IncidentReportDt]: this.state.incidentReportDt,
      [Consts.SAFFIELDS.ReportUpdateDt]: this.state.reportUpdateDt,
      [Consts.SAFFIELDS.ReportUpdateDesc]: this.state.reportUpdateDesc,
      [Consts.SAFFIELDS.InjuryDescription]: this.state.injuryDescription,
      [Consts.SAFFIELDS.EmployeeDepartment]: this.state.employeeDepartment,
      [Consts.SAFFIELDS.EmployeePriClass]: this.state.employeePriClass,
      [Consts.SAFFIELDS.SafetyReportType]: this.state.safetyReportType,
      [Consts.SAFFIELDS.SupervisorName]: this.state.supervisorName,
      [Consts.SAFFIELDS.SupervisorPhone]: this.state.supervisorPhone,
      [Consts.SAFFIELDS.SafetyDeptPersonnel]: this.state.safetyDeptPersonnel,
      [Consts.COMMONFIELDS.IncVersion]: Utilities.getNextMinorVersion(this.state.incVersion),
      [Consts.COMMONFIELDS.IncReportStatus]: Consts.INCSTATUS.Saved,
      [Consts.COMMONFIELDS.SubmittedDate]: new Date(),
      [Consts.COMMONFIELDS.LastEditedById]: this.currentUserId

    });

    /* if creating new incident or creating a new version of a submitted incident*/
    if (this.props.formMode == Consts.FORMMODE.New || this.state.incReportStatus == Consts.INCSTATUS.Submitted) {
      url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.SAF}')/items`;

      /* create list item */
      SPHttpService.Post(url, body).then((res) => {
        res.json().then((resJson) => {
          if (resJson && resJson.Id > 0) {
            /* attach files */
            PnPService.attachFilesToListItem(Consts.LISTTITLES.SAF, resJson.Id, this.state.attachmentFiles).then(() => {
              this.setState({
                showSubmitDialog: true,
                submitDialogText: `Incident report ${incidentNumber} saved successfully`
              });
            });
            /*Mark the current version as old*/
            if (this.state.incReportStatus == Consts.INCSTATUS.Submitted) {
              let reqBody: string = JSON.stringify({
                '__metadata': {
                  'type': Consts.LISTITEMENTTYPES.SAF
                },
                [Consts.COMMONFIELDS.LockStatus]: Consts.LOCKSTATUS.LOCKED,
                [Consts.COMMONFIELDS.IsLatestVersion]: false
              });

              let reqUrl = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.SAF}')/items(${this.props.itemId})`;
              SPHttpService.Update(reqUrl, reqBody).catch(err => console.log(err));
            }
          } else {
            this.setState({ errorMessage: "test" });
          }
        });
      }).catch((err) => {
        this.setState({ errorMessage: err });
      });
    }
    else if (this.props.formMode == Consts.FORMMODE.Edit && this.state.incReportStatus == Consts.INCSTATUS.Saved) {
      url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.SAF}')/items(${this.props.itemId})`;
      /* update list item and attach files */
      SPHttpService.Update(url, body).then((res) => {
        PnPService.attachFilesToListItem(Consts.LISTTITLES.SAF, this.props.itemId, this.state.attachmentFiles, this.attachments).then(() => {
          this.setState({
            showSubmitDialog: true,
            submitDialogText: `Incident report ${incidentNumber} saved successfully`
          });
        });
      }).catch((err) => {
        this.setState({ errorMessage: err });
      });
    }
  }

  /* submit incident when user clicks on submit button */
  private submitIncident() {
    let url: string;
    let incidentNumber: string;
    let promiseIncNumber: Promise<any>[] = [];

    //Generate new incident number if it is new report
    if (this.props.formMode == Consts.FORMMODE.New ||
      Math.floor(this.state.incVersion) == 0) {
      promiseIncNumber.push(ListService.getNextIncidentNumber(Consts.REPORTCODES.SAF).then((incNum: number) => {
        let dt: Date = new Date();
        let year = dt.getFullYear();
        let month = ("0" + (dt.getMonth() + 1)).slice(-2);
        let date = ("0" + dt.getDate()).slice(-2);
        let num = incNum < 10 ? `0${incNum}` : incNum;
        incidentNumber = `${Consts.REPORTCODES.SAF}-${year}${month}${date}-${num}`;
      })
      );
    }
    else {
      incidentNumber = this.state.utilityCompanyIncidentNumber;
    }
    /* create incident after incident number is identified */
    Promise.all(promiseIncNumber).then(() => {
      let body: string = JSON.stringify({
        '__metadata': {
          'type': Consts.LISTITEMENTTYPES.SAF
        },
        'Title': Consts.REPORTNAMES.SAF,
        [Consts.SAFFIELDS.UtilityCompanyIncidentNumber]: incidentNumber,
        [Consts.SAFFIELDS.UtilityId]: Consts.UtilityId,
        [Consts.SAFFIELDS.UtilityName]: Consts.UtilityName,
        [Consts.SAFFIELDS.UtilityPersonnelReportingId]: this.state.selPersonnelReportingId,
        [Consts.SAFFIELDS.UtilityPersonnelEmail]: this.state.personnelReportingEmail,
        [Consts.SAFFIELDS.UtilityPersonnelPhone]: this.state.personnelReportingPhone,

        [Consts.SAFFIELDS.AddressIncidentOccurred]: this.state.addressIncidentOccurred,
        [Consts.SAFFIELDS.ClosestCrossStreetToIncident]: this.state.closestCrossStreetToIncident,
        [Consts.SAFFIELDS.CountyIncidentOccurred]: this.state.countyIncidentOccurred,
        [Consts.SAFFIELDS.IncidentDescription]: this.state.incidentDescription,
        [Consts.SAFFIELDS.IncidentOccurredDt]: this.state.incidentOccurredDt,
        [Consts.SAFFIELDS.TownLocalityIncidentOccurred]: this.state.townLocalityIncidentOccurred,
        [Consts.SAFFIELDS.IncidentReportDt]: this.state.incidentReportDt,
        [Consts.SAFFIELDS.ReportUpdateDt]: this.state.reportUpdateDt,
        [Consts.SAFFIELDS.ReportUpdateDesc]: this.state.reportUpdateDesc,
        [Consts.SAFFIELDS.InjuryDescription]: this.state.injuryDescription,
        [Consts.SAFFIELDS.EmployeeDepartment]: this.state.employeeDepartment,
        [Consts.SAFFIELDS.EmployeePriClass]: this.state.employeePriClass,
        [Consts.SAFFIELDS.SafetyReportType]: this.state.safetyReportType,
        [Consts.SAFFIELDS.SupervisorName]: this.state.supervisorName,
        [Consts.SAFFIELDS.SupervisorPhone]: this.state.supervisorPhone,
        [Consts.SAFFIELDS.SafetyDeptPersonnel]: this.state.safetyDeptPersonnel,

        [Consts.COMMONFIELDS.IncVersion]: (Math.floor(this.state.incVersion) + 1).toString(),
        [Consts.COMMONFIELDS.SubmittedDate]: new Date(),
        [Consts.COMMONFIELDS.IncReportStatus]: Consts.INCSTATUS.Submitted,
        [Consts.COMMONFIELDS.IsLatestVersion]: true,
        [Consts.COMMONFIELDS.SendEmail]: true,
        [Consts.COMMONFIELDS.LastEditedById]: this.currentUserId
      });

      /* new list item will be created if this is a new incident or new version of an existing incident*/
      if (this.props.formMode == Consts.FORMMODE.New ||
        (this.props.formMode == Consts.FORMMODE.Edit && this.state.incReportStatus == Consts.INCSTATUS.Submitted)) {

        url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.SAF}')/items`;

        SPHttpService.Post(url, body).then((res) => {
          res.json().then((resJson) => {
            if (resJson && resJson.Id > 0) {
              PnPService.attachFilesToListItem(Consts.LISTTITLES.SAF, resJson.Id, this.state.attachmentFiles).then(() => {
                this.setState({
                  showSubmitDialog: true,
                  submitDialogText: `Incident report ${incidentNumber} submitted successfully`
                });
              });

              /*Mark the current version as old*/
              if (this.props.formMode == Consts.FORMMODE.Edit) {
                let reqBody: string = JSON.stringify({
                  '__metadata': {
                    'type': Consts.LISTITEMENTTYPES.SAF
                  },
                  [Consts.COMMONFIELDS.LockStatus]: Consts.LOCKSTATUS.LOCKED,
                  [Consts.COMMONFIELDS.IsLatestVersion]: false
                });

                let reqUrl = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.SAF}')/items(${this.props.itemId})`;
                SPHttpService.Update(reqUrl, reqBody).catch(err => console.log(err));
              }
            }
            else {
              this.setState({ errorMessage: "test" });
            }
          });
        }).catch((err) => {
          this.setState({ errorMessage: err });
        });
      }
      /* if a draft request is submitted, list item will be updated*/
      else if (this.props.formMode == Consts.FORMMODE.Edit && this.state.incReportStatus == Consts.INCSTATUS.Saved) {
        url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.SAF}')/items(${this.props.itemId})`;
        SPHttpService.Update(url, body).then((res) => {
          PnPService.attachFilesToListItem(Consts.LISTTITLES.SAF, this.props.itemId, this.state.attachmentFiles, this.attachments).then(() => {
            this.setState({
              showSubmitDialog: true,
              submitDialogText: `Incident report ${incidentNumber} submitted successfully`
            });
          });
        }).catch((err) => {
          this.setState({ errorMessage: err });
        });
      }
    });
  }

  /* change lock status of form to unlocked*/
  private unlockReport() {

    let body: string = JSON.stringify({
      '__metadata': {
        'type': Consts.LISTITEMENTTYPES.SAF
      },
      [Consts.COMMONFIELDS.LockStatus]: Consts.LOCKSTATUS.UNLOCKED
    });

    let url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.SAF}')/items(${this.props.itemId})`;
    SPHttpService.Update(url, body).then((res) => {
      this.setState({
        showConfirmDialog: false,
        showSubmitDialog: true,
        submitDialogText: `Incident report is unlocked`
      });
    }).catch((err) => {
      this.setState({ errorMessage: err });
    });
  }

  //==========================
  // COMPONENET DID MOUNT 
  //==========================  

  public componentDidMount() {

    /* load form boilerplate text */
    let formConfigPromise: Promise<any> = ListService.getFormConfigData(Consts.REPORTCODES.SAF);

    /* load form tooltips */
    let formTooltipsPromise: Promise<any> = ListService.getFormTooltips(Consts.REPORTCODES.SAF);

    /* load master list data for dropdowns */
    let masterListDataPromise: Promise<any> = ListService.getMasterListData(Consts.REPORTCODES.SAF);

    /* get current user permissions */
    let userGroupsPromise = PnPService.getCurrentUserGroups();

    Promise.all([formConfigPromise, formTooltipsPromise, masterListDataPromise, userGroupsPromise]).then((results) => {

      let footer: string = "";
      let tooltips = [];
      let items: IMasterList[] = [];

      /*boilerplate text */
      if (results[0] && results[0].value.length > 0) {
        footer = results[0].value[0]["Footer"];
      }

      /* get tooltips*/
      if (results[1] && results[1].value.length > 0) {
        results[1].value.forEach(item => {
          tooltips.push({
            key: item["Field"], value: item["Tooltip"]
          });
        });
      }

      /*master list data*/
      if (results[2]) {
        items = results[2].value;
      }

      /* user groups */
      if (results[3]) {
        this.isAdmin = results[3].indexOf(Consts.AdminGroup) > -1;
        this.isContributor = results[3].indexOf(Consts.ContributorsGroup) > -1;
      }

      /* update state */
      this.setState({
        footer: footer,
        tooltips: tooltips,
        masterListData: items,
        countyincidentOccurred: this.getDropDownOptions(items, "County"),

        safetyreportType: this.getDropDownOptions(items, "Safety Report Type"),
        safetydeptPersonnel: this.getDropDownOptions(items, "Safety Department Notified")
      });

      /* get current user profile properties for new request */
      PnPService.spLoggedInUserDetails().then((user) => {
        this.currentUserId = user.Id;
        if (this.props.formMode == Consts.FORMMODE.New && (this.isAdmin || this.isContributor)) {
          this.setState({
            selPersonnelReportingId: user.Id,
            selPersonnelReportingEMail: this.props.currentUser.email,
            personnelReportingEmail: this.props.currentUser.email,
            personnelReportingPhone: user.WorkPhone,
            showSaveBtn: true,
            showSubmitBtn: true
          });
        }
        else if (this.props.formMode == Consts.FORMMODE.Edit) {
          this.loadReportData();
        }
      });
    });
  }

  /* get tooltip of a fie,d from state */
  private getToolTipForField(fieldName: string): string {
    let tooltips = this.state.tooltips;
    let tooltip = "";
    if (tooltips && tooltips.length > 0) {
      let item = tooltips.filter(t => t.key == fieldName);
      if (item.length > 0) {
        tooltip = item[0].value;
      }
    }
    return tooltip;
  }

  public render(): React.ReactElement<ISafetyProps> {
    const getKey = `datetime-${new Date().getTime()}`; /*Dummy key to forece render DateTime picker - to handle bug */
    const imgLogoI: string = require("../../../images/logoi.png");

    const {
      personnelReportingPhone,
      addressIncidentOccurred,
      incidentDescription,
      incidentOccurredDt,
      incidentReportDt,
      employeeDepartment,
      safetyReportType,


    } = this.state;

    let isFormValid: boolean = false;
    if (
      /* validate mandatory fields on the form and enable submit button */
      personnelReportingPhone
      && safetyReportType
      && incidentReportDt
      && employeeDepartment
      && incidentOccurredDt
      && addressIncidentOccurred
      && incidentDescription
    ) {
      isFormValid = true;
    }

    return (
      <div id="safForm">
        <div className={styles["content-megacontainer"]}>

          <div className={styles["container-n"]}>
            <h4 className={styles["heading1"]}>Safety Related Event Notification</h4>
          </div>
          {this.props.formMode == Consts.FORMMODE.Edit && this.state.reportJson &&
            <div style={{ marginLeft: "65%" }}>
              {/* <CommandBarButton iconProps={{ iconName: "PDF" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Export as PDF" onClick={() => this.onExportPDFClick()} /> */}
              <CommandBarButton iconProps={{ iconName: "WordDocument" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Export as Word" onClick={() => this.onExportWordClick()} />
              <CommandBarButton iconProps={{ iconName: "Print" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Print / Save as PDF" onClick={() => this.onPrintlick()} />
              <CommandBarButton iconProps={{ iconName: "Mail" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Email" onClick={() => this.setState({ showEmailDialog: true })} />
            </div>
          }
          <hr className={styles["line"]} />
          <form>
            <div className={styles["s"]}>
              {this.props.formMode == Consts.FORMMODE.Edit &&
                <p>Utilty Incident Number : <span className={styles["span1"]}>{this.state.utilityCompanyIncidentNumber}</span>
                  <span className={styles["span2"]}>CHGE "1001"</span>
                </p>
              }
              <p>Utilty Name : <span className={styles["span3"]}> Central Hudson Gas & Electric Corp.</span></p>
            </div>
            <div className={styles["content-container"]}>
              <p className={styles["heading"]}>Information Received From<a href="#"><TooltipHost content={this.getToolTipForField("Information Received From")}><img src={imgLogoI} /></TooltipHost></a></p>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Personnel Reporting  <span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <PeoplePicker
                        context={this.props.context}
                        personSelectionLimit={1}
                        ensureUser={true}
                        onChange={(items) => this.onPeoplePickerChange(items)}
                        principalTypes={[PrincipalType.User]}
                        resolveDelay={100}
                        defaultSelectedUsers={[this.state.selPersonnelReportingEMail]} />
                    </div>
                  </div>
                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Contact Phone<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="personnelReportingPhone" /* className={styles["input-value"]} */ value={this.state.personnelReportingPhone} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles["two-columns-container"]}></div>
              <h5 className={styles["heading"]}>Date and Time of Report <span className={styles["star"]}>*</span><TooltipHost content={this.getToolTipForField("Date and Time of Report")}><img src={imgLogoI} /></TooltipHost></h5>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown}
                    value={this.state.incidentReportDt}
                    onChange={(val) => this.IncidentReportDt(val)} />
                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Safety Report Type <span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="safetyReportType" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} placeholder="Select an option" selectedKey={this.state.safetyReportType} options={this.state.safetyreportType} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["two-columns-container"]}></div>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Employee's Department<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='employeeDepartment' /* className={styles["input-value"]} */ value={this.state.employeeDepartment}
                        onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Name of Supervisor : </label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='supervisorName' /* className={styles["input-value"]}  */ value={this.state.supervisorName} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Safety Department <br />Personnel notified :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="safetyDeptPersonnel" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} placeholder="Select an option" selectedKey={this.state.safetyDeptPersonnel} options={this.state.safetydeptPersonnel} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>

                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Employee's Pri Class :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='employeePriClass' /* className={styles["input-value"]} */ value={this.state.employeePriClass}
                        onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Supervisor Phone Number :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='supervisorPhone' /* className={styles["input-value"]} */ value={this.state.supervisorPhone} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>



              <div className={styles["two-columns-container"]}></div>
              <h5 className={styles["heading"]}>Date and Time the Incident Occurred <span className={styles["star"]}>*</span><TooltipHost content={this.getToolTipForField("Date and Time the Incident Occurred")}><img src={imgLogoI} /></TooltipHost> </h5>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.incidentOccurredDt} onChange={(val) => this.IncidentOccurredDt(val)} />
                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                  </div>
                </div>
              </div>

              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Injury Description :</label>
                    </div>
                    <div className={styles["text-area-container"]}>
                      <TextField multiline rows={3} name='injuryDescription' value={this.state.injuryDescription} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Incident Description <span className={styles["star"]}>*</span>:</label><br />
                    </div>
                    <div className={styles["text-area-container"]}>
                      <TextField multiline rows={3} name='incidentDescription' value={this.state.incidentDescription} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles["two-columns-container"]}></div>
              <h5 className={styles["heading"]}>Date and Time of Update<TooltipHost content={this.getToolTipForField("Date and Time of Update")}><img src={imgLogoI} /></TooltipHost></h5>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown}
                    value={this.state.reportUpdateDt}
                    onChange={(val) => this.ReportUpdateDt(val)} />
                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                    </div>
                    <div className={styles["input-container"]}>
                    </div>
                  </div>
                </div>
              </div >

              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Description of<br /> Update Information :</label><br />
                    </div>
                    <div className={styles["text-area-container"]}>
                      <TextField multiline rows={3} name='reportUpdateDesc' value={this.state.reportUpdateDesc} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles["two-columns-container"]}></div>
              <h5 className={styles["heading"]}>Area Details<TooltipHost content={this.getToolTipForField("Area Details")}><img src={imgLogoI} /></TooltipHost></h5>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>

                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Address of Incident<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField  /* className={styles["input-value"]} */ name='addressIncidentOccurred'
                        value={this.state.addressIncidentOccurred}
                        onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Town / Locality of Incident :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField  /* className={styles["input-value"]} */ name='townLocalityIncidentOccurred' value={this.state.townLocalityIncidentOccurred}
                        onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>


                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Additional Attachments:</label>
                      <PrimaryButton className={styles["attach"]} onClick={(e) => this.onAttchSelect(e)}>Choose Files</PrimaryButton>
                      <input type="file" ref={this.fileAttachRef} multiple={true} onChange={(e) => this.onAttachmentChange(e)} hidden />
                      {
                        this.state.attachmentFiles.length > 0 &&
                        <ul className={styles["attachment-list-alignment"]}>
                          {this.state.attachmentFiles.map((file: IFileInfo, index: number) => {
                            return (<li>{file.url ? (<a download={file.name} href={file.url} data-interception="off" target="_blank">{file.name}</a>) : <i>{file.name}</i>} <FontIcon iconName="Delete" onClick={(e) => this.onDeleteAttachment(e, index)} /></li>);
                          })
                          }
                        </ul>
                      }
                    </div>
                  </div>
                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Location Description/Cross Street:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='closestCrossStreetToIncident' /* className={styles["input-value"]} */ value={this.state.closestCrossStreetToIncident} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>County of Incident:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="countyIncidentOccurred" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} placeholder="Select an option" selectedKey={this.state.countyIncidentOccurred} options={this.state.countyincidentOccurred} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles["bottomButton"] + ' ' + styles["btn-gap"]}>
                <DefaultButton className={styles["bottomButton__one"]} text="Cancel" onClick={(e) => this.onCancelClick()} />
                {
                  this.state.showSaveBtn &&
                  <DefaultButton className={styles["bottomButton__two"]} text="Save" onClick={() => this.saveIncident()} />
                }
                {
                  this.state.showSubmitBtn &&
                  <PrimaryButton className={styles["bottomButton__three"]} text="Submit" disabled={!isFormValid} onClick={() => this.submitIncident()} />
                }
                {
                  this.state.showUnlockBtn &&
                  <PrimaryButton className={styles["bottomButton__three"]} text="Unlock Report"
                    onClick={() => this.setState({
                      showConfirmDialog: true,
                      confirmDialogText: "Are you sure you want to unlock this report?",
                      onConfirmDialog: () => this.unlockReport()
                    })} />
                }
              </div>
            </div >
            <hr className={styles["line"]} />
            <div className={styles["v"]}>
              <p className={styles["message"]}>{this.state.footer}</p>
            </div>
          </form >
        </div >
        <SubmitDialog
          showDialog={this.state.showSubmitDialog}
          hideDialog={() => { this.setState({ showSubmitDialog: false }); }}
          dialogTitle={this.state.submitDialogTitle}
          dialogText={this.state.submitDialogText}
          siteUrl={this.props.siteUrl}
          reportsPageUrl={this.props.siteUrl + Consts.REPORTPAGEURLS.SAF}
          className={styles.dialogContent} />
        <ConfirmDialog
          showDialog={this.state.showConfirmDialog}
          hideDialog={() => { this.setState({ showConfirmDialog: false }); }}
          onConfirm={this.state.onConfirmDialog}
          dialogText={this.state.confirmDialogText}
          className={styles.dialogContent} />
        <SendEmailDialog
          showDialog={this.state.showEmailDialog}
          hideDialog={() => { this.setState({ showEmailDialog: false }); }}
          title={this.state.item && this.state.item["Title"]}
          incidentNumber={this.state.utilityCompanyIncidentNumber}
          mailBody={this.state.reportJson}
          className={styles.dialogContent} />
      </div >
    );
  }
}

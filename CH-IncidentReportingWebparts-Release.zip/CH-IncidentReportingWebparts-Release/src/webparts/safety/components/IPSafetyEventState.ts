import { IItem } from '@pnp/sp/items';
import { IFilePickerResult } from '@pnp/spfx-controls-react/lib/FilePicker';
import { IDropdownOption } from 'office-ui-fabric-react';
import { IFileInfo } from "../../../models/IFileInfo";
import { IMasterList } from '../../../models/IMasterList';

export interface IPSafetyEventState {
    item: IItem;
    utilityCompanyIncidentNumber: string;
    utilityId: string;
    utilityName:string;
    selPersonnelReportingId: string;
    selPersonnelReportingEMail: string;
    selPersonnelReportingName: string;
    personnelReportingEmail: string;
    personnelReportingPhone: string;
    addressIncidentOccurred: string;
    closestCrossStreetToIncident: string;
    incidentDescription: string;
    incidentOccurredDt: Date;
    injuryDescription: string;
    employeeDepartment: string;
    employeePriClass: string;
    supervisorName: string;
    supervisorPhone: string;
    reportUpdateDt: Date;
    reportUpdateDesc: string;
    incidentReportDt: Date;
    cHInternalNotes: string;
    incVersion: number;
    incReportStatus: string;
    isLatestVersion: string;
    submittedDate: Date;
    safetyReportType: string[];
    townLocalityIncidentOccurred: string;
    countyIncidentOccurred: string[];
    safetyDeptPersonnel: string;

    attachmentFiles: IFileInfo[];
    masterListData: IMasterList[];
    countyincidentOccurred: IDropdownOption[];
    townlocalityIncidentOccurred: IDropdownOption[];
    safetyreportType: IDropdownOption[];
    safetydeptPersonnel: IDropdownOption[];

    showSubmitDialog: boolean;
    showConfirmDialog: boolean;
    showEmailDialog: boolean;
    showStatusDialog: boolean;
    submitDialogTitle: string;
    submitDialogText: string;
    statusDialogTitle: string;
    statusDialogText: string;
    confirmDialogText: string;
    onConfirmDialog: () => void;
    errorMessage: string;
    showSaveBtn: boolean;
    showSubmitBtn: boolean;
    showUnlockBtn: boolean;
    //showSubmitToPSCBtn: boolean;
    reportJson: string;

    footer: string;
    tooltips: any[];
}
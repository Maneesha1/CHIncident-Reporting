declare interface ISafetyWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SafetyWebPartStrings' {
  const strings: ISafetyWebPartStrings;
  export = strings;
}

declare interface IGasTransmissionLineMarkoutWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'GasTransmissionLineMarkoutWebPartStrings' {
  const strings: IGasTransmissionLineMarkoutWebPartStrings;
  export = strings;
}

import { IItem } from '@pnp/sp/items';
import { IFilePickerResult } from '@pnp/spfx-controls-react/lib/FilePicker';
import { IDropdownOption, Sticky } from 'office-ui-fabric-react';
import { IFileInfo } from "../../../models/IFileInfo";
import { IFormConfiguration } from '../../../models/IFormConfiguration';
import { IMasterList } from '../../../models/IMasterList';

export interface IGasTransmissionLineMarkoutState {
    item: IItem;
    selformCompletedById: string;
    selformCompletedByEMail: string;
    supervisorNotifiedDt: Date;
    formCompletedBy: string;
    formCompletedByDt: Date;
    followUpComments: string;
    utilityCompanyIncidentNumber: string;
    utilityId: string;
    utilityName:string;
    incReportStatus: string;
    incVersion: number;
    submittedDate: Date;

    lineDesignation: string[];
    cHDivision: string[];
    supervisorNotified: string[];
    selUtilityPersonnelReporting: string;
    utilityPersonnelPhone: string;
    formConfigData: string;
    isLatestVersion: boolean;

    attachmentFiles: IFileInfo[];
    masterListData: IMasterList[];
    supervisornotified: IDropdownOption[];
    lineDesign: IDropdownOption[];
    chDivision: IDropdownOption[];
    utilityPersonnelReporting: IDropdownOption[];

    showSubmitDialog: boolean;
    showConfirmDialog: boolean;
    showStatusDialog: boolean;
    showEmailDialog: boolean;
    submitDialogTitle: string;
    submitDialogText: string;
    statusDialogTitle: string;
    statusDialogText: string;
    confirmDialogText: string;
    onConfirmDialog: () => void;
    errorMessage: string;
    showSaveBtn: boolean;
    showSubmitBtn: boolean;
    showUnlockBtn: boolean;
    showSubmitToPSCBtn: boolean;
    reportJson: string;

    footer: string;
    tooltips: any[];
}
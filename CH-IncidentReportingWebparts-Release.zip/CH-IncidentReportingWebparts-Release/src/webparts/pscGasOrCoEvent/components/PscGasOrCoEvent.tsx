import * as React from 'react';
import styles from './PscGasOrCoEvent.module.scss';
import { IPscGasOrCoEventProps } from './IPscGasOrCoEventProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { TextField, Dropdown, IDropdownOption, DefaultButton, PrimaryButton, CommandBarButton, TooltipHost } from 'office-ui-fabric-react';
import { FontIcon } from 'office-ui-fabric-react/lib/Icon';
import { DateTimePicker, TimeConvention, TimeDisplayControlType } from '@pnp/spfx-controls-react/lib/DateTimePicker';
import ListService from '../../../services/ListService';
import PnPService from '../../../services/PnPService';
import HttpService from "../../../services/HttpService";
import SPHttpService from "../../../services/SPHttpService";
import * as Consts from '../../../common/constants';
import { IMasterList } from '../../../models/IMasterList';
import { IFileInfo } from '../../../models/IFileInfo';
import { IPscGasOrCoEventState } from './IPscGasOrCoEventState';
import { IUserProfile } from '../../../models/IUserProfile';
import { SubmitDialog } from "../../../common/components/SubmitDialog";
import { ConfirmDialog } from "../../../common/components/ConfirmDialog";
import PDFService from "../../../services/PDFService";
import WordService from "../../../services/WordService";
import Utilities from "../../../services/Utilities";
import { SendEmailDialog } from '../../../common/components/SendEmailDialog';

export default class PscGasOrCoEvent extends React.Component<IPscGasOrCoEventProps, IPscGasOrCoEventState> {

  private fileAttachRef;
  private isAdmin: boolean = false;
  private isContributor: boolean = false;
  private currentUserId: number;
  private attachments: string[] = [];

  constructor(props: IPscGasOrCoEventProps, state: IPscGasOrCoEventState) {
    super(props);
    this.state = {
      item: null,
      attachmentFiles: [],
      masterListData: null,
      utilityCompanyIncidentNumber: null,
      utilityId: null,
      utilityName: null,
      selPersonnelReportingId: null,
      selPersonnelReportingEMail: null,
      selPersonnelReportingName: null,
      personnelReportingEmail: null,
      personnelReportingPhone: null,
      incidentReportedToUtilityCompanyDt: null,
      incidentReportedToDPSDt: null,
      incidentOccurredDt: null,
      dPSStaffNotified: null,
      incidentDescription: null,
      latitudeEquipmentImpacted: null,
      longitudeEquipmentImpacted: null,
      addressIncidentOccurred: null,
      closestCrossStreetToIncident: null,
      servicesInterruptedCount: "0",
      employeeInjuriesReportedCount: "0",
      publicInjuriesReportedCount: "0",
      selTown: null,
      selCounty: null,
      selMediaCoverage: null,
      dispatchDt: null,
      crewArrivalDt: null,
      madeSafeDt: null,
      dispatchGasOrderNumber: null,
      reportUpdateDt: null,
      reportUpdateDesc: null,
      selReportSubType: [],

      incVersion: 0,
      incReportStatus: null,
      submittedDate: null,
      isLatestVersion: false,

      dpsStaffNames: [],
      towns: [],
      counties: [],
      reportSubTypes: [],
      mediaCoverageOptions: [],

      showSubmitDialog: false,
      showConfirmDialog: false,
      showEmailDialog: false,
      submitDialogTitle: "Success",
      submitDialogText: null,
      confirmDialogText: null,
      onConfirmDialog: null,
      errorMessage: null,
      showSaveBtn: false,
      showSubmitBtn: false,
      showUnlockBtn: false,
      reportJson: null,

      footer: null,
      tooltips: null,
    };
    this.fileAttachRef = React.createRef();
  }


  /** Event Handlers **/

  private onAttchSelect(e) {
    e.preventDefault();
    this.fileAttachRef.current.click();
  }

  private onAttachmentChange(event) {
    let resultFile = event.target.files;
    let fileInfos: IFileInfo[] = [];
    let promArr: Promise<any>[] = [];

    for (var i = 0; i < resultFile.length; i++) {
      var file = resultFile[i];
      var reader = new FileReader();
      promArr.push(new Promise((resolve, reject) => {
        reader.onload = ((fileToRead) => {
          return (e) => {
            //Push the converted file into array
            fileInfos.push({
              "name": fileToRead.name,
              "content": e.target.result
            });
            resolve();
          };
        })(file);
        reader.readAsArrayBuffer(file);
      }));
    }
    Promise.all(promArr).then(() => {
      this.setState({
        attachmentFiles: [...this.state.attachmentFiles, ...fileInfos]
      });
    });
  }

  private onCancelClick() {
    window.location.href = this.props.siteUrl;
  }

  private onDeleteAttachment(event, index) {
    let attachments = this.state.attachmentFiles;
    attachments.splice(index, 1);
    this.setState({
      attachmentFiles: attachments
    });
  }

  private onCrewArrivalDateChange(value) {
    this.setState(
      {
        ...this.state,
        crewArrivalDt: value
      }
    );
  }

  private onDispatchDateChange(value) {
    this.setState(
      {
        ...this.state,
        dispatchDt: value
      }
    );
  }

  private onReportUpdateDateChange(value) {
    this.setState(
      {
        ...this.state,
        reportUpdateDt: value
      }
    );
  }

  private onDropDownChange(event, selItem: IDropdownOption) {
    this.setState({
      ...this.state,
      [event.target.id]: selItem.text,
    });
  }

  /* export to pdf */
  private onExportPDFClick() {
    PDFService.ExportToPDFFromHTML(this.state.item["UtilityCompanyIncidentNumber"], this.state.item["Title"], this.state.reportJson);
  }

  /* export to word */
  private onExportWordClick() {
    WordService.generateDocument(this.state.item["UtilityCompanyIncidentNumber"], this.state.item["Title"], this.state.reportJson);
  }

  /* export to word */
  private onPrintlick() {
    Utilities.printHtml(this.state.item["UtilityCompanyIncidentNumber"], this.state.item["Title"], this.state.reportJson);
  }

  /* Get latitude and longitude for given address */
  private async onGetLatLongClick() {
    let addressParts: string[] = [];
    if (this.state.addressIncidentOccurred) {
      addressParts.push(this.state.addressIncidentOccurred);
    }
    if (this.state.closestCrossStreetToIncident) {
      addressParts.push(this.state.closestCrossStreetToIncident);
    }
    if (this.state.selTown) {
      addressParts.push(this.state.selTown);
    }
    if (this.state.selCounty) {
      addressParts.push(this.state.selCounty);
    }

    const resp = await HttpService.GetLatLongFromAddress(addressParts.join());
    const resJson = await resp.json();
    if (resJson && resJson.resourceSets.length > 0) {
      this.setState({
        latitudeEquipmentImpacted: resJson.resourceSets[0].resources[0].point.coordinates[0].toString(),
        longitudeEquipmentImpacted: resJson.resourceSets[0].resources[0].point.coordinates[1].toString()
      });
    }
  }

  private onMadeSafeDateChange(value) {
    this.setState(
      {
        ...this.state,
        madeSafeDt: value
      }
    );
  }

  /* onchange event for multi select dropdown */
  private onMultiDropdownChange(event, selItem: IDropdownOption) {
    this.setState({
      ...this.state,
      [event.target.id]: selItem.selected ? [...this.state[event.target.id], selItem.text] : this.state[event.target.id].filter(key => key !== selItem.key)
    });
  }

  private onOccurDateChange(value) {
    this.setState(
      {
        ...this.state,
        incidentOccurredDt: value
      }
    );
  }

  private onPSCRepDateChange(value) {
    this.setState(
      {
        ...this.state,
        incidentReportedToDPSDt: value
      }
    );
  }

  private onPeoplePickerChange(items: any[]) {
    if (items.length > 0) {
      PnPService.getUserProfileProperties(items[0].loginName).then((userProps: IUserProfile) => {
        this.setState({
          selPersonnelReportingId: items[0].id,
          selPersonnelReportingEMail: userProps.WorkEmail,
          personnelReportingEmail: userProps.WorkEmail,
          personnelReportingPhone: userProps.WorkPhone
        });
      });
    }
    else {
      this.setState({
        selPersonnelReportingId: null,
        selPersonnelReportingEMail: null,
        personnelReportingEmail: null,
        personnelReportingPhone: null
      });
    }
  }


  private onTextChange(event) {
    const value = event.target.value;
    this.setState(
      {
        ...this.state,
        [event.target.name]: value
      }
    );
  }

  private onUtilityRepDateChange(value) {
    this.setState(
      {
        ...this.state,
        incidentReportedToUtilityCompanyDt: value
      }
    );
  }

  /**Helper Functions **/
  private bindAttachmentsFromList(resultFile) {
    let fileInfos: IFileInfo[] = [];
    let promArr: Promise<any>[] = [];

    for (var i = 0; i < resultFile.length; i++) {
      var attFile = resultFile[i];
      ((file) => {
        promArr.push(new Promise((resolve, reject) => {
          fetch(Consts.SITEURLS.ROOTSITE + file.ServerRelativeUrl).then(e => {
            let content = e.arrayBuffer();
            content.then(c => {
              fileInfos.push({
                "name": file.FileName,
                "content": c,
                "url": Consts.SITEURLS.ROOTSITE + file.ServerRelativeUrl
              });
              resolve();
            });
          });
        }));
      })(attFile);
    }

    Promise.all(promArr).then(() => {
      this.setState({
        attachmentFiles: fileInfos
      });
    });
  }

  private getDropDownOptions(items: IMasterList[], category: string, removeDuplicates: boolean = false, key: string = "", multiselect: boolean = false): IDropdownOption[] {
    let values: any[] = items.filter(item => item.Category == category);
    if (removeDuplicates) {
      values = this.removeDuplicatesFromArray(values, key);
    }
    let ddlOptions: IDropdownOption[] = [];
    if (!multiselect) {
      ddlOptions.push({ key: "", text: "" });
    }
    values.map(item => ddlOptions.push({
      key: item.SubCategory, text: item.SubCategory
    }));
    ddlOptions.sort((a, b) => a.text.localeCompare(b.text));
    return ddlOptions;
  }

  private loadIncSubTypes(selIncTypes: string[]): IDropdownOption[] {
    let masterItems: IMasterList[] = this.state.masterListData;
    let incSubTypes: IMasterList[] = [];

    selIncTypes.forEach(selIncType => {
      masterItems.filter(masterItem => masterItem.SubCategory == selIncType).map(item => {
        incSubTypes.push(item);
      });
    });

    incSubTypes = this.removeDuplicatesFromArray(incSubTypes, "Value");
    let ddlOptions: IDropdownOption[] = [];
    incSubTypes.map(item => ddlOptions.push({
      key: item.Value, text: item.Value
    }));

    ddlOptions.sort((a, b) => a.text.localeCompare(b.text));
    return ddlOptions;
  }

  private async loadReportData() {
    let allowSave: boolean = false;
    let allowSubmit: boolean = false;
    let allowUnlock: boolean = false;
    let submittedDt: Date = null;

    PnPService.getItemById(Consts.LISTTITLES.PSCG, this.props.itemId, Consts.SELECTFIELDS.PSCG, Consts.EXPANDFIELDS.PSCG).then((item) => {

      if (item["Attachments"] == true) {
        item["AttachmentFiles"].forEach(file => {
          console.log(`${file.FileName}-${file.FileNameAsPath}-${file.ServerRelativePath}-${file.ServerRelativeUrl}`);
          this.attachments.push(file.FileName);
        });
        this.bindAttachmentsFromList(item["AttachmentFiles"]);
      }

      /* check save & submit conditions */
      if (this.isAdmin || this.isContributor) {
        /*Allow editing if it is a draft request */
        if (item[Consts.COMMONFIELDS.IncReportStatus] == Consts.INCSTATUS.Saved) {
          allowSave = true;
          allowSubmit = true;
        }
        /*Allow editing on latest versions of submitted request */
        else if (item[Consts.COMMONFIELDS.IncReportStatus] == Consts.INCSTATUS.Submitted && item[Consts.COMMONFIELDS.IsLatestVersion]) {

          if (item[Consts.COMMONFIELDS.SubmittedDate]) {

            submittedDt = new Date(item[Consts.COMMONFIELDS.SubmittedDate]);
            let elapsedTime = (new Date().getTime() - submittedDt.getTime()) / (1000 * 60 * 60);

            /*Allow editing within specified hours or if admin unlocked form */
            if (elapsedTime <= Consts.EditHours || item[Consts.COMMONFIELDS.LockStatus] == Consts.LOCKSTATUS.UNLOCKED) {
              allowSave = true;
              allowSubmit = true;
            }

            /*Allow unlock beyond specified time if user is admin */
            if (elapsedTime > Consts.EditHours && this.isAdmin && item[Consts.COMMONFIELDS.LockStatus] != Consts.LOCKSTATUS.UNLOCKED) {
              allowUnlock = true;
            }
          }
        }
      }

      /* Build HTML Table for Export to PDF, WORD and Send Mail */
      let repTable = Utilities.buildItemHTMLTable(item, Consts.SELECTFIELDS.PSCG);

      this.setState({
        item: item,
        reportJson: repTable,
        utilityCompanyIncidentNumber: item[Consts.PSCGFIELDS.UtilityCompanyIncidentNumber],
        utilityId: item[Consts.PSCGFIELDS.UtilityId],
        utilityName: item[Consts.PSCGFIELDS.UtilityName],
        selPersonnelReportingId: item[Consts.PSCGFIELDS.UtilityPersonnelReportingId],
        selPersonnelReportingEMail: item[Consts.PSCGFIELDS.UtilityPersonnelReporting] ? item[Consts.PSCGFIELDS.UtilityPersonnelReporting]["EMail"] : null,
        selPersonnelReportingName: item[Consts.PSCGFIELDS.UtilityPersonnelReporting] ? item[Consts.PSCGFIELDS.UtilityPersonnelReporting]["Title"] : null,
        personnelReportingEmail: item[Consts.PSCGFIELDS.UtilityPersonnelEmail],
        personnelReportingPhone: item[Consts.PSCGFIELDS.UtilityPersonnelPhone],
        incidentReportedToUtilityCompanyDt: item[Consts.PSCGFIELDS.IncidentReportedToUtilityCompanyDt] ? new Date(item[Consts.PSCGFIELDS.IncidentReportedToUtilityCompanyDt]) : null,
        incidentReportedToDPSDt: item[Consts.PSCGFIELDS.IncidentReportedToDPSDt] ? new Date(item[Consts.PSCGFIELDS.IncidentReportedToDPSDt]) : null,
        incidentOccurredDt: item[Consts.PSCGFIELDS.IncidentOccurredDt] ? new Date(item[Consts.PSCGFIELDS.IncidentOccurredDt]) : null,
        dPSStaffNotified: item[Consts.PSCGFIELDS.DPSStaffNotified],
        incidentDescription: item[Consts.PSCGFIELDS.IncidentDescription],
        latitudeEquipmentImpacted: item[Consts.PSCGFIELDS.LatitudeEquipmentImpacted],
        longitudeEquipmentImpacted: item[Consts.PSCGFIELDS.LongitudeEquipmentImpacted],
        addressIncidentOccurred: item[Consts.PSCGFIELDS.AddressIncidentOccurred],
        closestCrossStreetToIncident: item[Consts.PSCGFIELDS.ClosestCrossStreetToIncident],
        servicesInterruptedCount: item[Consts.PSCGFIELDS.ServicesInterruptedCount] ? item[Consts.PSCGFIELDS.ServicesInterruptedCount] : "0",
        employeeInjuriesReportedCount: item[Consts.PSCGFIELDS.EmployeeInjuriesReportedCount] ? item[Consts.PSCGFIELDS.EmployeeInjuriesReportedCount] : "0",
        publicInjuriesReportedCount: item[Consts.PSCGFIELDS.PublicInjuriesReportedCount] ? item[Consts.PSCGFIELDS.PublicInjuriesReportedCount] : "0",
        selTown: item[Consts.PSCGFIELDS.TownLocalityIncidentOccurred],
        selCounty: item[Consts.PSCGFIELDS.CountyIncidentOccurred],
        selMediaCoverage: item[Consts.PSCGFIELDS.MediaCoverage],
        dispatchDt: item[Consts.PSCGFIELDS.DispatchDt] ? new Date(item[Consts.PSCGFIELDS.DispatchDt]) : null,
        crewArrivalDt: item[Consts.PSCGFIELDS.CrewArrivalDt] ? new Date(item[Consts.PSCGFIELDS.CrewArrivalDt]) : null,
        madeSafeDt: item[Consts.PSCGFIELDS.MadeSafeDt] ? new Date(item[Consts.PSCGFIELDS.MadeSafeDt]) : null,
        dispatchGasOrderNumber: item[Consts.PSCGFIELDS.DispatchGasOrderNumber],
        reportUpdateDt: item[Consts.PSCGFIELDS.ReportUpdateDt] ? new Date(item[Consts.PSCGFIELDS.ReportUpdateDt]) : null,
        reportUpdateDesc: item[Consts.PSCGFIELDS.ReportUpdateDesc],
        selReportSubType: item[Consts.PSCGFIELDS.ReportSubType] ? item[Consts.PSCGFIELDS.ReportSubType].split("|") : [],
        incVersion: item[Consts.COMMONFIELDS.IncVersion],
        submittedDate: submittedDt,
        isLatestVersion: item[Consts.COMMONFIELDS.IsLatestVersion],
        incReportStatus: item[Consts.COMMONFIELDS.IncReportStatus],
        showSaveBtn: allowSave,
        showSubmitBtn: allowSubmit,
        showUnlockBtn: allowUnlock
      });


    }).catch(err => {
      console.log(err);
    });
  }

  private removeDuplicatesFromArray(arr: any[], key: string): any[] {
    return arr.reduce((accumulator, currentValue) => {
      const value = currentValue[key];
      if (!accumulator.some(item => item[key] === value)) {
        accumulator.push(currentValue);
      }
      return accumulator;
    }, []);
  }

  private saveIncident() {
    let incidentNumber: string;
    let url: string;

    if (this.props.formMode == Consts.FORMMODE.New) {
      let dt: Date = new Date();
      let year = dt.getFullYear();
      let month = ("0" + (dt.getMonth() + 1)).slice(-2);
      let date = ("0" + dt.getDate()).slice(-2);
      incidentNumber = `${Consts.REPORTCODES.PSCG}-${year}${month}${date}-Draft`;
    }
    else if (this.props.formMode == Consts.FORMMODE.Edit) {
      incidentNumber = this.state.utilityCompanyIncidentNumber;
    }

    let body: string = JSON.stringify({
      '__metadata': {
        'type': Consts.LISTITEMENTTYPES.PSCG
      },
      'Title': Consts.REPORTNAMES.PSCG,
      [Consts.PSCGFIELDS.UtilityCompanyIncidentNumber]: incidentNumber,
      [Consts.PSCGFIELDS.UtilityId]: Consts.UtilityId,
      [Consts.PSCGFIELDS.UtilityName]: Consts.UtilityName,
      [Consts.PSCGFIELDS.UtilityPersonnelReportingId]: this.state.selPersonnelReportingId,
      [Consts.PSCGFIELDS.UtilityPersonnelEmail]: this.state.personnelReportingEmail,
      [Consts.PSCGFIELDS.UtilityPersonnelPhone]: this.state.personnelReportingPhone,
      [Consts.PSCGFIELDS.IncidentReportedToUtilityCompanyDt]: this.state.incidentReportedToUtilityCompanyDt,
      [Consts.PSCGFIELDS.IncidentReportedToDPSDt]: this.state.incidentReportedToDPSDt,
      [Consts.PSCGFIELDS.IncidentOccurredDt]: this.state.incidentOccurredDt,
      [Consts.PSCGFIELDS.DPSStaffNotified]: this.state.dPSStaffNotified,
      [Consts.PSCGFIELDS.IncidentDescription]: this.state.incidentDescription,
      [Consts.PSCGFIELDS.LatitudeEquipmentImpacted]: this.state.latitudeEquipmentImpacted,
      [Consts.PSCGFIELDS.LongitudeEquipmentImpacted]: this.state.longitudeEquipmentImpacted,
      [Consts.PSCGFIELDS.AddressIncidentOccurred]: this.state.addressIncidentOccurred,
      [Consts.PSCGFIELDS.ClosestCrossStreetToIncident]: this.state.closestCrossStreetToIncident,
      [Consts.PSCGFIELDS.ServicesInterruptedCount]: Number(this.state.servicesInterruptedCount),

      [Consts.PSCGFIELDS.EmployeeInjuriesReportedCount]: Number(this.state.employeeInjuriesReportedCount),
      [Consts.PSCGFIELDS.PublicInjuriesReportedCount]: Number(this.state.publicInjuriesReportedCount),

      [Consts.PSCGFIELDS.TownLocalityIncidentOccurred]: this.state.selTown,
      [Consts.PSCGFIELDS.CountyIncidentOccurred]: this.state.selCounty,

      [Consts.PSCGFIELDS.MediaCoverage]: this.state.selMediaCoverage,
      [Consts.PSCGFIELDS.DispatchDt]: this.state.dispatchDt,
      [Consts.PSCGFIELDS.CrewArrivalDt]: this.state.crewArrivalDt,
      [Consts.PSCGFIELDS.MadeSafeDt]: this.state.madeSafeDt,
      [Consts.PSCGFIELDS.DispatchGasOrderNumber]: this.state.dispatchGasOrderNumber,
      [Consts.PSCGFIELDS.ReportUpdateDt]: this.state.reportUpdateDt,
      [Consts.PSCGFIELDS.ReportUpdateDesc]: this.state.reportUpdateDesc,
      [Consts.PSCGFIELDS.ReportSubType]: this.state.selReportSubType && this.state.selReportSubType.join("|"),
      [Consts.COMMONFIELDS.IncVersion]: Utilities.getNextMinorVersion(this.state.incVersion),
      [Consts.COMMONFIELDS.IncReportStatus]: Consts.INCSTATUS.Saved,
      [Consts.COMMONFIELDS.SubmittedDate]: new Date(),
      [Consts.COMMONFIELDS.LastEditedById]: this.currentUserId
    });

    /* if creating new incident or creating a new version of a submitted incident*/
    if (this.props.formMode == Consts.FORMMODE.New || this.state.incReportStatus == Consts.INCSTATUS.Submitted) {
      url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.PSCG}')/items`;

      /* create list item */
      SPHttpService.Post(url, body).then((res) => {
        res.json().then((resJson) => {
          if (resJson && resJson.Id > 0) {
            /* attach files */
            PnPService.attachFilesToListItem(Consts.LISTTITLES.PSCG, resJson.Id, this.state.attachmentFiles).then(() => {
              this.setState({
                showSubmitDialog: true,
                submitDialogText: `Incident report ${incidentNumber} saved successfully`
              });
            });

            /*Mark the current version as old*/
            if (this.state.incReportStatus == Consts.INCSTATUS.Submitted) {
              let reqBody: string = JSON.stringify({
                '__metadata': {
                  'type': Consts.LISTITEMENTTYPES.PSCG
                },
                [Consts.COMMONFIELDS.LockStatus]: Consts.LOCKSTATUS.LOCKED,
                [Consts.COMMONFIELDS.IsLatestVersion]: false
              });

              let reqUrl = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.PSCG}')/items(${this.props.itemId})`;
              SPHttpService.Update(reqUrl, reqBody).catch(err => console.log(err));
            }
          } else {
            this.setState({ errorMessage: "test" });
          }
        });
      }).catch((err) => {
        this.setState({ errorMessage: err });
      });
    }
    else if (this.props.formMode == Consts.FORMMODE.Edit && this.state.incReportStatus == Consts.INCSTATUS.Saved) {
      url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.PSCG}')/items(${this.props.itemId})`;
      /* update list item and attach files */
      SPHttpService.Update(url, body).then((res) => {
        PnPService.attachFilesToListItem(Consts.LISTTITLES.PSCG, this.props.itemId, this.state.attachmentFiles, this.attachments).then(() => {
          this.setState({
            showSubmitDialog: true,
            submitDialogText: `Incident report ${incidentNumber} saved successfully`
          });
        });
      }).catch((err) => {
        this.setState({ errorMessage: err });
      });
    }
  }

  private submitIncident() {
    let url: string;
    let incidentNumber: string;
    let promiseIncNumber: Promise<any>[] = [];

    //Generate new incident number if it is new report
    if (this.props.formMode == Consts.FORMMODE.New ||
      Math.floor(this.state.incVersion) == 0) {
      promiseIncNumber.push(ListService.getNextIncidentNumber(Consts.REPORTCODES.PSCG).then((incNum: number) => {
        let dt: Date = new Date();
        let year = dt.getFullYear();
        let month = ("0" + (dt.getMonth() + 1)).slice(-2);
        let date = ("0" + dt.getDate()).slice(-2);
        let num = incNum < 10 ? `0${incNum}` : incNum;
        incidentNumber = `${Consts.REPORTCODES.PSCG}-${year}${month}${date}-${num}`;
      })
      );
    }
    else {
      incidentNumber = this.state.utilityCompanyIncidentNumber;
    }

    Promise.all(promiseIncNumber).then(() => {
      let body: string = JSON.stringify({
        '__metadata': {
          'type': Consts.LISTITEMENTTYPES.PSCG
        },
        'Title': Consts.REPORTNAMES.PSCG,
        [Consts.PSCGFIELDS.UtilityCompanyIncidentNumber]: incidentNumber,
        [Consts.PSCGFIELDS.UtilityId]: Consts.UtilityId,
        [Consts.PSCGFIELDS.UtilityName]: Consts.UtilityName,
        [Consts.PSCGFIELDS.UtilityPersonnelReportingId]: this.state.selPersonnelReportingId,
        [Consts.PSCGFIELDS.UtilityPersonnelEmail]: this.state.personnelReportingEmail,
        [Consts.PSCGFIELDS.UtilityPersonnelPhone]: this.state.personnelReportingPhone,
        [Consts.PSCGFIELDS.IncidentReportedToUtilityCompanyDt]: this.state.incidentReportedToUtilityCompanyDt,
        [Consts.PSCGFIELDS.IncidentReportedToDPSDt]: this.state.incidentReportedToDPSDt,
        [Consts.PSCGFIELDS.IncidentOccurredDt]: this.state.incidentOccurredDt,

        [Consts.PSCGFIELDS.DPSStaffNotified]: this.state.dPSStaffNotified,
        [Consts.PSCGFIELDS.IncidentDescription]: this.state.incidentDescription,
        [Consts.PSCGFIELDS.LatitudeEquipmentImpacted]: this.state.latitudeEquipmentImpacted,
        [Consts.PSCGFIELDS.LongitudeEquipmentImpacted]: this.state.longitudeEquipmentImpacted,
        [Consts.PSCGFIELDS.AddressIncidentOccurred]: this.state.addressIncidentOccurred,
        [Consts.PSCGFIELDS.ClosestCrossStreetToIncident]: this.state.closestCrossStreetToIncident,
        [Consts.PSCGFIELDS.ServicesInterruptedCount]: Number(this.state.servicesInterruptedCount),

        [Consts.PSCGFIELDS.EmployeeInjuriesReportedCount]: Number(this.state.employeeInjuriesReportedCount),
        [Consts.PSCGFIELDS.PublicInjuriesReportedCount]: Number(this.state.publicInjuriesReportedCount),

        [Consts.PSCGFIELDS.TownLocalityIncidentOccurred]: this.state.selTown,
        [Consts.PSCGFIELDS.CountyIncidentOccurred]: this.state.selCounty,
        [Consts.PSCGFIELDS.MediaCoverage]: this.state.selMediaCoverage,
        [Consts.PSCGFIELDS.DispatchDt]: this.state.dispatchDt,
        [Consts.PSCGFIELDS.CrewArrivalDt]: this.state.crewArrivalDt,
        [Consts.PSCGFIELDS.MadeSafeDt]: this.state.madeSafeDt,
        [Consts.PSCGFIELDS.DispatchGasOrderNumber]: this.state.dispatchGasOrderNumber,
        [Consts.PSCGFIELDS.ReportUpdateDt]: this.state.reportUpdateDt,
        [Consts.PSCGFIELDS.ReportUpdateDesc]: this.state.reportUpdateDesc,
        [Consts.PSCGFIELDS.ReportSubType]: this.state.selReportSubType && this.state.selReportSubType.join("|"),

        [Consts.COMMONFIELDS.IncVersion]: (Math.floor(this.state.incVersion) + 1).toString(),
        [Consts.COMMONFIELDS.SubmittedDate]: new Date(),
        [Consts.COMMONFIELDS.IncReportStatus]: Consts.INCSTATUS.Submitted,
        [Consts.COMMONFIELDS.IsLatestVersion]: true,
        [Consts.COMMONFIELDS.SendEmail]: true,
        [Consts.COMMONFIELDS.LastEditedById]: this.currentUserId
      });

      /* new list item will be created if this is a new incident or new version of an existing incident*/
      if (this.props.formMode == Consts.FORMMODE.New ||
        (this.props.formMode == Consts.FORMMODE.Edit && this.state.incReportStatus == Consts.INCSTATUS.Submitted)) {

        url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.PSCG}')/items`;

        SPHttpService.Post(url, body).then((res) => {
          res.json().then((resJson) => {
            if (resJson && resJson.Id > 0) {
              PnPService.attachFilesToListItem(Consts.LISTTITLES.PSCG, resJson.Id, this.state.attachmentFiles).then(() => {
                this.setState({
                  showSubmitDialog: true,
                  submitDialogText: `Incident report ${incidentNumber} submitted successfully`
                });
              });

              /*Mark the current version as old*/
              if (this.props.formMode == Consts.FORMMODE.Edit) {
                let reqBody: string = JSON.stringify({
                  '__metadata': {
                    'type': Consts.LISTITEMENTTYPES.PSCG
                  },
                  [Consts.COMMONFIELDS.LockStatus]: Consts.LOCKSTATUS.LOCKED,
                  [Consts.COMMONFIELDS.IsLatestVersion]: false
                });

                let reqUrl = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.PSCG}')/items(${this.props.itemId})`;
                SPHttpService.Update(reqUrl, reqBody).catch(err => console.log(err));
              }
            }
            else {
              this.setState({ errorMessage: "test" });
            }
          });
        }).catch((err) => {
          this.setState({ errorMessage: err });
        });
      }
      /* if a draft request is submitted, list item will be updated*/
      else if (this.props.formMode == Consts.FORMMODE.Edit && this.state.incReportStatus == Consts.INCSTATUS.Saved) {
        url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.PSCG}')/items(${this.props.itemId})`;
        SPHttpService.Update(url, body).then((res) => {
          PnPService.attachFilesToListItem(Consts.LISTTITLES.PSCG, this.props.itemId, this.state.attachmentFiles, this.attachments).then(() => {
            this.setState({
              showSubmitDialog: true,
              submitDialogText: `Incident report ${incidentNumber} submitted successfully`
            });
          });
        }).catch((err) => {
          this.setState({ errorMessage: err });
        });
      }
    });
  }

  /* change lock status of form to unlocked*/
  private unlockReport() {

    let body: string = JSON.stringify({
      '__metadata': {
        'type': Consts.LISTITEMENTTYPES.PSCG
      },
      [Consts.COMMONFIELDS.LockStatus]: Consts.LOCKSTATUS.UNLOCKED
    });

    let url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.PSCG}')/items(${this.props.itemId})`;
    SPHttpService.Update(url, body).then((res) => {
      this.setState({
        showConfirmDialog: false,
        showSubmitDialog: true,
        submitDialogText: `Incident report is unlocked`
      });
    }).catch((err) => {
      this.setState({ errorMessage: err });
    });
  }

  public componentDidMount() {
    /* load form boilerplate text */
    let formConfigPromise: Promise<any> = ListService.getFormConfigData(Consts.REPORTCODES.PSCG);

    /* load form tooltips */
    let formTooltipsPromise: Promise<any> = ListService.getFormTooltips(Consts.REPORTCODES.PSCG);

    /* load master list data for dropdowns */
    let masterListDataPromise: Promise<any> = ListService.getMasterListData(Consts.REPORTCODES.PSCG);

    /* get current user permissions */
    let userGroupsPromise = PnPService.getCurrentUserGroups();

    Promise.all([formConfigPromise, formTooltipsPromise, masterListDataPromise, userGroupsPromise]).then((results) => {

      let footer: string = "";
      let tooltips = [];
      let items: IMasterList[] = [];

      /*boilerplate text */
      if (results[0] && results[0].value.length > 0) {
        footer = results[0].value[0]["Footer"];
      }

      /* get tooltips*/
      if (results[1] && results[1].value.length > 0) {
        results[1].value.forEach(item => {
          tooltips.push({
            key: item["Field"], value: item["Tooltip"]
          });
        });
      }

      /*master list data*/
      if (results[2]) {
        items = results[2].value;
      }

      /* user groups */
      if (results[3]) {
        this.isAdmin = results[3].indexOf(Consts.AdminGroup) > -1;
        this.isContributor = results[3].indexOf(Consts.ContributorsGroup) > -1;
      }

      /* update state */
      this.setState({
        footer: footer,
        tooltips: tooltips,
        masterListData: items,
        dpsStaffNames: this.getDropDownOptions(items, "DPS Staff"),
        /* towns: this.getDropDownOptions(items, "Town/Locality"), */
        counties: this.getDropDownOptions(items, "County"),
        reportSubTypes: this.getDropDownOptions(items, "Report SubType", false, "", true),
        mediaCoverageOptions: this.getDropDownOptions(items, "Media Coverage"),
      });

      /* get current user profile properties for new request */
      var date = new Date();
      date.setSeconds(0);
      PnPService.spLoggedInUserDetails().then((user) => {
        this.currentUserId = user.Id;
        if (this.props.formMode == Consts.FORMMODE.New && (this.isAdmin || this.isContributor)) {
          this.setState({
            selPersonnelReportingId: user.Id,
            selPersonnelReportingEMail: this.props.currentUser.email,
            personnelReportingEmail: this.props.currentUser.email,
            personnelReportingPhone: user.WorkPhone,
            incidentReportedToUtilityCompanyDt: date,
            incidentReportedToDPSDt: date,
            incidentOccurredDt: date,
            showSaveBtn: true,
            showSubmitBtn: true
          });
        }
        else if (this.props.formMode == Consts.FORMMODE.Edit) {
          this.loadReportData();
        }
      });
    });
  }

  /* get tooltip of a fie,d from state */
  private getToolTipForField(fieldName: string): string {
    let tooltips = this.state.tooltips;
    let tooltip = "";
    if (tooltips && tooltips.length > 0) {
      let item = tooltips.filter(t => t.key == fieldName);
      if (item.length > 0) {
        tooltip = item[0].value;
      }
    }
    return tooltip;
  }

  public render(): React.ReactElement<IPscGasOrCoEventProps> {
    const getKey = `datetime-${new Date().getTime()}`; /*Dummy key to forece render DateTime picker - to handle bug */
    const imgLogoI: string = require("../../../images/logoi.png");

    const {
      selPersonnelReportingId,
      personnelReportingEmail,
      personnelReportingPhone,
      incidentReportedToUtilityCompanyDt,
      incidentReportedToDPSDt,
      incidentOccurredDt,
      incidentDescription,
      latitudeEquipmentImpacted,
      selReportSubType,
      longitudeEquipmentImpacted,
      addressIncidentOccurred
    } = this.state;

    let isFormValid: boolean = false;
    if (selPersonnelReportingId
      && personnelReportingEmail
      && personnelReportingPhone
      && incidentReportedToUtilityCompanyDt
      && incidentReportedToDPSDt
      && incidentOccurredDt
      && selReportSubType
      && incidentDescription
      && latitudeEquipmentImpacted
      && longitudeEquipmentImpacted
      && addressIncidentOccurred) {
      isFormValid = true;
    }

    return (
      <div id="pscgForm">
        <div className={styles["content-megacontainer"]}>
          <form>
            <div className={styles["container-n"]}>
              <h4 className={styles["heading1"]}>Gas or Carbon Monoxide</h4>
            </div>
            {this.props.formMode == Consts.FORMMODE.Edit && this.state.reportJson &&
              <div style={{ marginLeft: "65%" }}>
                {/* <CommandBarButton iconProps={{ iconName: "PDF" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Export as PDF" onClick={() => this.onExportPDFClick()} /> */}
                <CommandBarButton iconProps={{ iconName: "WordDocument" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Export as Word" onClick={() => this.onExportWordClick()} />
                <CommandBarButton iconProps={{ iconName: "Print" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Print / Save as PDF" onClick={() => this.onPrintlick()} />
                <CommandBarButton iconProps={{ iconName: "Mail" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Email" onClick={() => this.setState({ showEmailDialog: true })} />
              </div>
            }
            <hr className={styles["line"]} />
            <div className={styles["s"]}>
              {this.props.formMode == Consts.FORMMODE.Edit &&
                <p>Utilty Incident Number : <span className={styles["span1"]}>{this.state.utilityCompanyIncidentNumber}</span>
                  <span className={styles["span2"]}>CHGE "1001"</span></p>
              }
              <p>Utilty Name : <span className={styles["span3"]}>Central Hudson Gas & Electric Corp.</span></p>
            </div>
            <div className={styles["content-container"]}>
              <p className={styles["heading"]}>Reporting Details<a href="#"><TooltipHost content={this.getToolTipForField("Reporting Details")}><img src={imgLogoI} /></TooltipHost></a></p>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Personnel Reporting <span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <PeoplePicker
                        context={this.props.context}
                        personSelectionLimit={1}
                        ensureUser={true}
                        onChange={(items) => this.onPeoplePickerChange(items)}
                        principalTypes={[PrincipalType.User]}
                        resolveDelay={100}
                        defaultSelectedUsers={[this.state.selPersonnelReportingEMail]} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Email<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="personnelReportingEmail" value={this.state.personnelReportingEmail} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["space-container2"]}></div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Report Subtype<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selReportSubType" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKeys={this.state.selReportSubType} options={this.state.reportSubTypes} multiSelect onChange={(e, o) => this.onMultiDropdownChange(e, o)} />
                    </div>
                  </div>
                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Phone Number<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="personnelReportingPhone" value={this.state.personnelReportingPhone} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>
                  <h5 className={styles["heading"]}>Date and Time Incident Reported to Utility<span className={styles["star"]}>*</span><a href="#"><TooltipHost content={this.getToolTipForField("Date and Time Incident Reported to Utility")}><img src={imgLogoI} /></TooltipHost></a></h5>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.incidentReportedToUtilityCompanyDt} onChange={(val) => this.onUtilityRepDateChange(val)} />
                </div>
                <div className={styles["column-2"]}>
                  <h5 className={styles["heading"]}>Date and Time Reported to PSC<span className={styles["star"]}>*</span><a href="#"><TooltipHost content={this.getToolTipForField("Date and Time Reported to PSC")}><img src={imgLogoI} /></TooltipHost></a></h5>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.incidentReportedToDPSDt} onChange={(val) => this.onPSCRepDateChange(val)} />
                </div>
              </div>
              <div className={styles["two-columns-container"]}></div>
              <h5 className={styles["heading"]}>Date and Time the Incident Occurred<span className={styles["star"]}>*</span><a href="#"><TooltipHost content={this.getToolTipForField("Date and Time the Incident Occurred")}><img src={imgLogoI} /></TooltipHost></a></h5>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.incidentOccurredDt} onChange={(val) => this.onOccurDateChange(val)} />
                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Name of DPS Staff Notified:<a href="#"><TooltipHost content={this.getToolTipForField("DPS Staff who received call")}><img src={imgLogoI} /></TooltipHost></a></label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="dPSStaffNotified" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.dPSStaffNotified} options={this.state.dpsStaffNames} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Incident Description <span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["text-area-container"]}>
                      <TextField multiline rows={3} name='incidentDescription' value={this.state.incidentDescription} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>
                  <h5 className={styles["heading"]}>Date and Time of Dispatch<a href="#"><TooltipHost content={this.getToolTipForField("Date and Time of Dispatch")}><img src={imgLogoI} /></TooltipHost></a></h5>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.dispatchDt} onChange={(val) => this.onDispatchDateChange(val)} />
                </div>
                <div className={styles["column-2"]}>
                  <h5 className={styles["heading"]}>Date and Time of Crew Arrival<a href="#"><TooltipHost content={this.getToolTipForField("Date and Time of Crew Arrival")}><img src={imgLogoI} /></TooltipHost></a></h5>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.crewArrivalDt} onChange={(val) => this.onCrewArrivalDateChange(val)} />
                </div>
              </div>
              <div className={styles["two-columns-container"]}></div>
              <h5 className={styles["heading"]}>Date and Time of Made Safe Time:<a href="#"><TooltipHost content={this.getToolTipForField("Date and Time of Made Safe Time")}><img src={imgLogoI} /></TooltipHost></a></h5>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.madeSafeDt} onChange={(val) => this.onMadeSafeDateChange(val)} />
                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label></label>
                    </div>
                    <div className={styles["input-container"]}>
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["two-columns-container"]}></div>
              <h5 className={styles["heading"]}>Area Details<a href="#"><TooltipHost content={this.getToolTipForField("Area Details")}><img src={imgLogoI} /></TooltipHost></a></h5>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Address of Incident <span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.addressIncidentOccurred} name='addressIncidentOccurred' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}></label>
                    </div>
                    <div className={styles["input-container"]}>
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Latitude <span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.latitudeEquipmentImpacted} name='latitudeEquipmentImpacted' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Town / Locality of Incident :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.selTown} name='selTown' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Number of Services Interrupted (Approximate):</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='servicesInterruptedCount' type="number" value={this.state.servicesInterruptedCount} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>

                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Location Description/<br />Cross Street:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.closestCrossStreetToIncident} name='closestCrossStreetToIncident' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}></label>
                    </div>
                    <div className={styles["input-container"]}>
                      <DefaultButton className={styles["longbutton"]} text="Get Latitude and Longitude" onClick={() => this.onGetLatLongClick()} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Longitude <span
                        className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.longitudeEquipmentImpacted} name='longitudeEquipmentImpacted' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>County of Incident:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selCounty" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.selCounty} options={this.state.counties} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>CH Order Number :<a href="#"><TooltipHost content={this.getToolTipForField("Trouble, Dispatch, or Gas Order Number")}><img src={imgLogoI} /></TooltipHost></a></label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='dispatchGasOrderNumber' value={this.state.dispatchGasOrderNumber} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["two-columns-container"]}></div>
              <h5 className={styles["heading"]}>Injury Details<a href="#"><TooltipHost content={this.getToolTipForField("Injury Details")}><img src={imgLogoI} /></TooltipHost></a></h5>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Number of Employees Injured:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='employeeInjuriesReportedCount' type="number" value={this.state.employeeInjuriesReportedCount} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>

                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Number of Injuries to members of the public:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name='publicInjuriesReportedCount' type="number" value={this.state.publicInjuriesReportedCount} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>
                  <h5 className={styles["heading"]}>Date and Time of Report Update<a href="#"><TooltipHost content={this.getToolTipForField("Date and Time of Report Update")}><img src={imgLogoI} /></TooltipHost></a></h5>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.reportUpdateDt} onChange={(val) => this.onReportUpdateDateChange(val)} />
                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                    </div>
                    <div className={styles["input-container"]}>
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Description of update information:</label>
                    </div>
                    <div className={styles["text-area-container"]}>
                      <TextField multiline rows={3} name='reportUpdateDesc' value={this.state.reportUpdateDesc} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Media Coverage :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="selMediaCoverage" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.selMediaCoverage} options={this.state.mediaCoverageOptions} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                </div>

                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Additional Attachments:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <PrimaryButton className={styles["attach"]} onClick={(e) => this.onAttchSelect(e)}>Choose Files</PrimaryButton>
                      <input type="file" ref={this.fileAttachRef} multiple={true} onChange={(e) => this.onAttachmentChange(e)} hidden />
                      {
                        this.state.attachmentFiles.length > 0 &&
                        <ul style={{ listStyleType: "none" }}>
                          {this.state.attachmentFiles.map((file: IFileInfo, index: number) => {
                            return (<li>{file.url ? (<a download={file.name} href={file.url} data-interception="off" target="_blank">{file.name}</a>) : <i>{file.name}</i>} <FontIcon iconName="Delete" onClick={(e) => this.onDeleteAttachment(e, index)} /></li>);
                          })
                          }
                        </ul>
                      }
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles["bottomButton"] + ' ' + styles["btn-gap"]}>
                <DefaultButton className={styles["bottomButton__one"]} text="Cancel" onClick={(e) => this.onCancelClick()} />
                {
                  this.state.showSaveBtn &&
                  <DefaultButton className={styles["bottomButton__two"]} text="Save" onClick={() => this.saveIncident()} />
                }
                {
                  this.state.showSubmitBtn &&
                  <PrimaryButton className={styles["bottomButton__three"]} text="Submit" disabled={!isFormValid} onClick={() => this.submitIncident()} />
                }
                {
                  this.state.showUnlockBtn &&
                  <PrimaryButton className={styles["bottomButton__three"]} text="Unlock Report"
                    onClick={() => this.setState({
                      showConfirmDialog: true,
                      confirmDialogText: "Are you sure you want to unlock this report?",
                      onConfirmDialog: () => this.unlockReport()
                    })} />
                }
              </div>
            </div>
            <hr className={styles["line"]} />
            <div className={styles["v"]}>
              <p className={styles["message"]}>{this.state.footer}</p>
            </div>
          </form>
        </div>
        <SubmitDialog
          showDialog={this.state.showSubmitDialog}
          hideDialog={() => { this.setState({ showSubmitDialog: false }); }}
          dialogTitle={this.state.submitDialogTitle}
          dialogText={this.state.submitDialogText}
          siteUrl={this.props.siteUrl}
          reportsPageUrl={this.props.siteUrl + Consts.REPORTPAGEURLS.PSCG}
          className={styles.dialogContent} />
        <ConfirmDialog
          showDialog={this.state.showConfirmDialog}
          hideDialog={() => { this.setState({ showConfirmDialog: false }); }}
          onConfirm={() => this.unlockReport()}
          dialogText="Are you sure you want to unlock this report?"
          className={styles.dialogContent} />
        <SendEmailDialog
          showDialog={this.state.showEmailDialog}
          hideDialog={() => { this.setState({ showEmailDialog: false }); }}
          title={this.state.item && this.state.item["Title"]}
          incidentNumber={this.state.utilityCompanyIncidentNumber}
          mailBody={this.state.reportJson}
          className={styles.dialogContent} />
      </div >
    );
  }
}
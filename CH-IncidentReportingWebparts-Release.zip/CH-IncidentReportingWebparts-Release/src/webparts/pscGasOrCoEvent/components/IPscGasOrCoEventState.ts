import { IItem } from '@pnp/sp/items';
import { IDropdownOption } from 'office-ui-fabric-react';
import { IFileInfo } from "../../../models/IFileInfo";
import { IMasterList } from '../../../models/IMasterList';

export interface IPscGasOrCoEventState {
    item: IItem;
    utilityCompanyIncidentNumber: string;
    utilityId:string;
    utilityName:string;
    selPersonnelReportingId: string;
    selPersonnelReportingEMail: string;
    selPersonnelReportingName: string;
    personnelReportingEmail: string;
    personnelReportingPhone: string;
    incidentReportedToUtilityCompanyDt: Date;
    incidentReportedToDPSDt: Date;
    incidentOccurredDt: Date;
    dPSStaffNotified: string;
    incidentDescription: string;
    latitudeEquipmentImpacted: string;
    longitudeEquipmentImpacted: string;
    addressIncidentOccurred: string;
    closestCrossStreetToIncident: string;
    servicesInterruptedCount: string;
    employeeInjuriesReportedCount: string;
    publicInjuriesReportedCount: string;
    selTown: string;
    selCounty: string;
    selMediaCoverage: string;
    dispatchDt: Date;
    crewArrivalDt: Date;
    madeSafeDt: Date;
    dispatchGasOrderNumber: string;
    reportUpdateDt: Date;
    reportUpdateDesc: string;
    selReportSubType: string[];

    incVersion: number;
    incReportStatus: string;
    submittedDate: Date;
    isLatestVersion: boolean;

    attachmentFiles: IFileInfo[];
    masterListData: IMasterList[];
    dpsStaffNames: IDropdownOption[];
    towns: IDropdownOption[];
    counties: IDropdownOption[];
    reportSubTypes: IDropdownOption[];
    mediaCoverageOptions: IDropdownOption[];

    showSubmitDialog: boolean;
    showConfirmDialog: boolean;
    showEmailDialog: boolean;
    submitDialogTitle: string;
    submitDialogText: string;
    confirmDialogText: string;
    onConfirmDialog: () => void;
    errorMessage: string;
    showSaveBtn: boolean;
    showSubmitBtn: boolean;
    showUnlockBtn: boolean;
    reportJson: string;

    footer: string;
    tooltips: any[];
}
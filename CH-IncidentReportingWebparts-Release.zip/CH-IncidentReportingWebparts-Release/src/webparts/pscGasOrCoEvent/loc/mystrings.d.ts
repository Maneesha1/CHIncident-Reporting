declare interface IPscGasOrCoEventWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'PscGasOrCoEventWebPartStrings' {
  const strings: IPscGasOrCoEventWebPartStrings;
  export = strings;
}

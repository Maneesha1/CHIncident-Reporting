import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneDropdown
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'AllReportsWebPartStrings';
import AllReports from './components/AllReports';
import { IAllReportsProps } from './components/IAllReportsProps';
import PnPService from '../../services/PnPService';
import SPHttpService from '../../services/SPHttpService';
import { SPComponentLoader } from '@microsoft/sp-loader';

export interface IAllReportsWebPartProps {
  reporttype: string;
}

export default class AllReportsWebPart extends BaseClientSideWebPart<IAllReportsWebPartProps> {

  protected onInit(): Promise<void> {
    SPHttpService.init(this.context.spHttpClient, this.context.pageContext.site.absoluteUrl);
    PnPService.init(this.context);
    SPComponentLoader.loadCss("https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css");
    return super.onInit();
  }

  public render(): void {
    //get report filter from query string
    const queryString: string = window.location.search;
    let filter: string = "";
    if (queryString) {
      const urlParams = new URLSearchParams(queryString.toLowerCase());
      if (urlParams.get('filterkey')) {
        filter = urlParams.get('filterkey');
      }
    }

    //report header
    let reportHeader: string = "";
    switch (this.properties.reporttype) {

      case "PSCE":
        reportHeader = "PSC Electric Event Reports";
        break;
      case "PSCG":
        reportHeader = "Gas or CO Reports";
        break;
      case "TSA":
        reportHeader = "TSA Pipeline Security Event Reports";
        break;
      case "SPL":
        reportHeader = "Spill Reports";
        break;
      case "GTMO":
        reportHeader = "Gas Transmisson Markout Reports";
        break;
      case "GL45":
        reportHeader = "Gas Leak 45 and Over Reports";
        break;
      case "GL60":
        reportHeader = "Gas Leak 60 and Over Reports";
        break;
      case "SAF":
        reportHeader = "Safety Reports";
        break;
      case "DOT":
        reportHeader = "DOT Reports";
        break;
      case "All":
        if (filter == "my")
          reportHeader = "My Reports";
        else if (filter == "saved")
          reportHeader = "Saved Reports";
        else if (filter == "submitted")
          reportHeader = "Submitted Reports";
        else
          reportHeader = "All Reports";
        break;
        
      default: break;
    }

    const element: React.ReactElement<IAllReportsProps> = React.createElement(
      AllReports,
      {
        currentUser: this.context.pageContext.user,
        siteUrl: this.context.pageContext.web.absoluteUrl,
        reportCode: this.properties.reporttype,
        reportHeader: reportHeader,
        filter: filter
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          groups: [
            {
              groupFields: [
                PropertyPaneDropdown('reporttype', {
                  label: "Select Reports to Show",
                  options: [
                    { key: "All", text: "All Reports" },
                    { key: "PSCE", text: "PSC Electric Event" },
                    { key: "PSCG", text: "PSC Gas or CO Event" },
                    { key: "TSA", text: "TSA Pipeline Security Event" },
                    { key: "SPL", text: "Spill Report" },
                    { key: "GTMO", text: "Gas Transmission Mark out" },
                    { key: "GL45", text: "Gas Leak 45 and Over" },
                    { key: "GL60", text: "Gas Leak 60 and Over" },
                    { key: "SAF", text: "Safety Event" },
                    { key: "DOT", text: "DOT" },
                  ]
                })
              ]
            }
          ]
        }
      ]
    };
  }
}

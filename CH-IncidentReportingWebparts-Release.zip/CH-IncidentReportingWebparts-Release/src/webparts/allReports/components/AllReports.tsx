import * as React from 'react';
import styles from './AllReports.module.scss';
import { IAllReportsProps } from './IAllReportsProps';
import { escape } from '@microsoft/sp-lodash-subset';
import PnPService from '../../../services/PnPService';
import * as Consts from '../../../common/constants';
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import { DatePicker } from 'office-ui-fabric-react/lib/DatePicker';
import { CSVLink } from 'react-csv';
import { DefaultButton, IconButton, PrimaryButton } from 'office-ui-fabric-react/lib/Button';
import { ConfirmDialog } from "../../../common/components/ConfirmDialog";
import SPHttpService from '../../../services/SPHttpService';
import Pagination from "react-js-pagination";
import "./pagination.css";
import { Toggle } from 'office-ui-fabric-react/lib/Toggle';

export interface IAllReportsState {
  items: IReport[];
  filteredItems: IReport[];
  searchText: string;
  fromDate: Date;
  toDate: Date;
  showLatest: boolean;
  showConfirmDialog: boolean;
  selItemID: number;
  selReportType: string;
  selIncNumber: string;
  selReportListTitle: string;
  selReportListETType: string;
  currentPage: number;
}

export interface IReport {
  ID: number;
  IncidentNumber: string;
  IncidentVersion: string;
  SubmittedDate: Date;
  SubmittedDateString: string;
  ReportType: string;
  IncidentType?: string;
  ReportedBy: string;
  Actions: JSX.Element;
  LastEditedBy: string;
}

export default class AllReports extends React.Component<IAllReportsProps, IAllReportsState> {

  private listTitles: string[];
  private pageUrls: string[];
  private listItemEntityTypes: string[];
  private selFields: any[];
  private expandFields: any[];
  private gtmoFilter: string;

  private columns = [
    {
      keys: ['Incident Number', 'Mark Out ID'],
      name: 'Incident #'
    },
    {
      keys: ['Incident Version', 'Version'],
      name: 'Version'
    },
    {
      keys: ['Time Submitted'],
      name: this.props.filter == "saved" ? 'Last Saved Date/Time' : 'Submitted Date'
    },
    {
      keys: ['Title'],
      name: 'Report Type'
    },
    {
      keys: ['Last Edited By'],
      name: 'Last Edited By'
    },
    {
      keys: ["Actions"],
      name: "Actions"
    }
  ];

  constructor(props: IAllReportsProps, state: IAllReportsState) {
    super(props);
    this.state = {
      items: [],
      filteredItems: [],
      searchText: null,
      fromDate: null,
      toDate: null,
      showLatest: false,
      showConfirmDialog: false,
      selItemID: null,
      selReportType: null,
      selIncNumber: null,
      selReportListTitle: null,
      selReportListETType: null,
      currentPage: 1
    };

    this.listTitles = [];
    this.pageUrls = [];
    this.listItemEntityTypes = [];
    this.selFields = [];
    this.expandFields = [];
  }

  /* get selected reports from lists */
  private async getAllReports(filter: string) {

    if (this.props.reportCode != "All") {
      this.listTitles.push(Consts.LISTTITLES[this.props.reportCode]);
      this.pageUrls.push(Consts.FORMURLS[this.props.reportCode]);
      this.listItemEntityTypes.push(Consts.LISTITEMENTTYPES[this.props.reportCode]);
      this.selFields.push(Consts.SELECTFIELDS[this.props.reportCode]);
      this.expandFields.push(Consts.EXPANDFIELDS[this.props.reportCode]);
    }
    else {
      this.listTitles.push(Consts.LISTTITLES.PSCE, Consts.LISTTITLES.PSCG, Consts.LISTTITLES.TSA, Consts.LISTTITLES.GTMO, Consts.LISTTITLES.GL45, Consts.LISTTITLES.GL60, Consts.LISTTITLES.SAF, Consts.LISTTITLES.DOT, Consts.LISTTITLES.SPL);
      this.pageUrls.push(Consts.FORMURLS.PSCE, Consts.FORMURLS.PSCG, Consts.FORMURLS.TSA, Consts.FORMURLS.GTMO, Consts.FORMURLS.GL45, Consts.FORMURLS.GL60, Consts.FORMURLS.SAF, Consts.FORMURLS.DOT, Consts.FORMURLS.SPL);
      this.listItemEntityTypes.push(Consts.LISTITEMENTTYPES.PSCE, Consts.LISTITEMENTTYPES.PSCG, Consts.LISTITEMENTTYPES.TSA, Consts.LISTITEMENTTYPES.GTMO, Consts.LISTITEMENTTYPES.GL45, Consts.LISTITEMENTTYPES.GL60, Consts.LISTITEMENTTYPES.SAF, Consts.LISTITEMENTTYPES.DOT, Consts.LISTITEMENTTYPES.SPL);
      this.selFields.push(Consts.SELECTFIELDS.PSCE, Consts.SELECTFIELDS.PSCG, Consts.SELECTFIELDS.TSA, Consts.SELECTFIELDS.GTMO, Consts.SELECTFIELDS.GL45, Consts.SELECTFIELDS.GL60, Consts.SELECTFIELDS.SAF, Consts.SELECTFIELDS.DOT, Consts.SELECTFIELDS.SPL);
      this.expandFields.push(Consts.EXPANDFIELDS.PSCE, Consts.EXPANDFIELDS.PSCG, Consts.EXPANDFIELDS.TSA, Consts.EXPANDFIELDS.GTMO, Consts.EXPANDFIELDS.GL45, Consts.EXPANDFIELDS.GL60, Consts.EXPANDFIELDS.SAF, Consts.EXPANDFIELDS.DOT, Consts.EXPANDFIELDS.SPL);
    }

    /* check current user permissions */
    let isAdmin, isContributor = false;
    let userGroups = await PnPService.getCurrentUserGroups();

    if (userGroups) {
      isAdmin = userGroups.indexOf(Consts.AdminGroup) > -1;
      isContributor = userGroups.indexOf(Consts.ContributorsGroup) > -1;
    }

    let promArr: Promise<any>[] = [];
    let useGtmoFilter: boolean = false;

    /* query the selected lists */
    for (let i = 0; i < this.listTitles.length; i++) {
      promArr.push(
        new Promise((resolve, reject) => {

          // For GTMO list, my reports should use FormCompletedBy fields instead of UtilityPersonnelReorting
          if (this.props.filter == "my" && this.listTitles[i] == Consts.LISTTITLES.GTMO) {
            useGtmoFilter = true;
          } else {
            useGtmoFilter = false;
          }

          //Get items from each report list
          PnPService.getListItems(this.listTitles[i], this.selFields[i], this.expandFields[i], useGtmoFilter ? this.gtmoFilter : filter).then((res: any[]) => {
            let reports = [];
            if (res && res.length > 0) {

              res.map(item => {
                let editHours = (item.Title == Consts.REPORTNAMES.SPL) ? Consts.SpillreportEditHours : Consts.EditHours;
                let submittedDt = new Date(item.SubmittedDate);
                let allowEdit: boolean = false;

                if (isAdmin || isContributor) {
                  /*Allow editing if it is a draft request */
                  if (item[Consts.COMMONFIELDS.IncReportStatus] == Consts.INCSTATUS.Saved) {
                    allowEdit = true;
                  }
                  else if (item[Consts.COMMONFIELDS.IsLatestVersion]) {
                    /*Allow editing within specified num of hours */
                    if (item[Consts.COMMONFIELDS.SubmittedDate]) {
                      submittedDt = new Date(item[Consts.COMMONFIELDS.SubmittedDate]);
                      allowEdit = (new Date().getTime() - submittedDt.getTime()) / (1000 * 60 * 60) < editHours ? true : false;
                    }

                    /*Allow editing if admin unlocked form */
                    if (item[Consts.COMMONFIELDS.LockStatus] == Consts.LOCKSTATUS.UNLOCKED) {
                      allowEdit = true;
                    }
                  }
                }

                //build row for each report item
                let reportObj = {};

                /*skip internal fields*/
                let ignoreFields = ["Attachments", "AttachmentFiles", "LockStatus", "Modified", "Editor", "SentToPSC"];

                /*transform data based on field type*/
                this.selFields[i].forEach((field: any) => {
                  if (ignoreFields.indexOf(field.InternalName) == -1) {
                    if (field.Type == "Person") {
                      reportObj[field.DisplayName] = item[field.InternalName] ? item[field.InternalName]["Title"] : "";
                    }
                    else if (field.Type == "Date") {
                      reportObj[field.DisplayName] = item[field.InternalName] ? new Date(item[field.InternalName]).toLocaleString() : "";
                    }
                    else if (field.Type == "YesNo") {
                      reportObj[field.DisplayName] = item[field.InternalName] ? "Yes" : "No";
                    }
                    else if (field.Type == "Number") {
                      reportObj[field.DisplayName] = item[field.InternalName];
                    }
                    else {
                      reportObj[field.DisplayName] = item[field.InternalName];
                    }
                  }
                });

                /* build the action buttons*/
                let actions =
                  <>
                    {!allowEdit &&
                      <IconButton iconProps={{ iconName: "View" }} className={styles.actionIcon}
                        href={this.props.siteUrl + this.pageUrls[i] + "?RepID=" + item.ID}>
                      </IconButton>
                    }
                    {allowEdit &&
                      <IconButton iconProps={{ iconName: "Edit" }} className={styles.actionIcon}
                        href={this.props.siteUrl + this.pageUrls[i] + "?RepID=" + item.ID}>
                      </IconButton>
                    }
                    {isAdmin &&
                      <IconButton iconProps={{ iconName: "Delete" }} className={styles.actionIcon}
                        onClick={() => {
                          this.setState({
                            selItemID: item.ID,
                            selIncNumber: item.UtilityCompanyIncidentNumber,
                            selReportType: item.Title,
                            showConfirmDialog: true,
                            selReportListTitle: this.listTitles[i],
                            selReportListETType: this.listItemEntityTypes[i]
                          });
                        }}>
                      </IconButton>
                    }
                  </>;
                reportObj["Actions"] = actions;
                reports.push(reportObj);
              });
            }
            resolve(reports);
          });
        })
      );
    }

    /* update state after all lists' queries are completed */
    let results: IReport[] = [];
    Promise.all(promArr).then((res: any[]) => {
      res.map((result: IReport[]) => {
        results.push(...result);
      });

      /*sort results*/
      results.sort((a, b) => new Date(a["Time Submitted"]) > new Date(b["Time Submitted"]) ? -1 : (new Date(a["Time Submitted"]) < new Date(b["Time Submitted"]) ? 1 : 0));

      this.setState({
        items: results,
        filteredItems: results
      });
    });
  }

  public componentDidMount() {

    /* build reports filter string*/

    let reportFilter: string = "";
    switch (this.props.filter) {
      case "saved":
        reportFilter = "IncReportStatus eq 'Saved'";
        break;
      case "submitted":
        reportFilter = "IncReportStatus eq 'Submitted'";
        break;
      case "my":
        reportFilter = "UtilityPersonnelReporting/EMail eq '" + this.props.currentUser.email + "' and IncReportStatus ne 'Deleted'";
        //For GTMO list, FormCompletedBy field shows current logged in user
        this.gtmoFilter = "FormCompletedBy/EMail eq '" + this.props.currentUser.email + "' and IncReportStatus ne 'Deleted'";
        break;
      default:
        reportFilter = "IncReportStatus ne 'Deleted'";
        break;
    }

    this.getAllReports(reportFilter);
  }

  /* method to soft delete report */
  private onDelete() {

    this.setState({ showConfirmDialog: false });

    /* update status as deleted and locked */
    let reqBody: string = JSON.stringify({
      '__metadata': {
        'type': this.state.selReportListETType
      },
      [Consts.COMMONFIELDS.IncReportStatus]: Consts.INCSTATUS.Deleted,
      [Consts.COMMONFIELDS.LockStatus]: Consts.LOCKSTATUS.LOCKED,
      [Consts.COMMONFIELDS.IsLatestVersion]: false
    });

    let reqUrl = `/_api/web/lists/getbytitle('${this.state.selReportListTitle}')/items(${this.state.selItemID})`;
    SPHttpService.Update(reqUrl, reqBody)
      .then((res) => {
        //Remove deleted item from state
        let allResults = this.state.items;
        allResults = allResults.filter(result => !(result["ID"] == this.state.selItemID && result["Title"] == this.state.selReportType && result["Incident Number"] == this.state.selIncNumber));

        let filteredResults = this.state.filteredItems;
        filteredResults = filteredResults.filter(result => !(result["ID"] == this.state.selItemID && result["Title"] == this.state.selReportType && result["Incident Number"] == this.state.selIncNumber));

        this.setState({
          items: allResults,
          filteredItems: filteredResults
        });
      })
      .catch(err => console.log(err));
  }

  /* filter items based on typed keyword */
  private onSearchKeyUp(event) {
    this.setState({
      searchText: event.target.value.toLowerCase(),
      currentPage: 1
    });
  }

  /* filter items based on from date selected */
  private onFromDateSelect(date: Date) {
    this.setState({
      fromDate: date,
      currentPage: 1
    });
  }

  /* filter items based on to date selected */
  private onToDateSelect(date: Date) {
    this.setState({
      toDate: date,
      currentPage: 1
    });
  }

  /* on toggle latest version*/
  private onToggleVersionChange(ev: React.MouseEvent<HTMLElement>, checked: boolean) {
    this.setState({
      showLatest: checked,
      currentPage: 1
    });
  }

  /* check and apply filters */
  private getFilteredResults(): IReport[] {
    const { searchText, fromDate, toDate, showLatest } = this.state;
    let results: IReport[] = this.state.items;

    /* apply search keyword filter */
    if (searchText && results.length > 0) {
      results = results.filter(report => (
        (report["Incident Number"] && report["Incident Number"].toLowerCase().indexOf(searchText) != -1)
        || (report["Mark Out ID"] && report["Mark Out ID"].toLowerCase().indexOf(searchText) != -1)
        || (report["Title"] && report["Title"].toLowerCase().indexOf(searchText) != -1)
        || (report["Incident Version"] && report["Incident Version"] == searchText)
        || (report["Version"] && report["Version"] == searchText)
        || (report["Last Edited By"] && report["Last Edited By"].toLowerCase().indexOf(searchText) != -1)
      ));
    }

    /* apply from date filter */
    if (fromDate && results.length > 0) {
      let fromDateNoTime = fromDate ? fromDate.setHours(0, 0, 0, 0) : null;
      let toDateNoTime = toDate ? toDate.setHours(0, 0, 0, 0) : null;

      results = results.filter(report => {
        if (report["Time Submitted"]) {
          let submittedDt = new Date(report["Time Submitted"]).setHours(0, 0, 0, 0);
          return toDate ?
            submittedDt >= fromDateNoTime && submittedDt <= toDateNoTime :
            submittedDt >= fromDateNoTime;
        }
      });
    }

    /* apply to date filter */
    if (toDate && results.length > 0) {
      let fromDateNoTime = fromDate ? fromDate.setHours(0, 0, 0, 0) : null;
      let toDateNoTime = toDate.setHours(0, 0, 0, 0);

      results = results.filter(report => {
        if (report["Time Submitted"]) {
          let submittedDt = new Date(report["Time Submitted"]).setHours(0, 0, 0, 0);
          return fromDateNoTime ? submittedDt >= fromDateNoTime && submittedDt <= toDateNoTime : submittedDt <= toDateNoTime;
        }
      });
    }

    /* apply latet version filter */
    if (showLatest && results.length > 0) {
      results = results.filter(report => report["Is Latest Version"] == "Yes");
    }

    return results;
  }

  public render(): React.ReactElement<IAllReportsProps> {

    let filteredItems = this.getFilteredResults();
    let exportData = [];
    let itemsToDisplay: IReport[] = [];
    if (filteredItems) {
      filteredItems.map((item: IReport) => exportData.push(item));
    }

    //Pagination
    let totalItems = filteredItems ? filteredItems.length : 0;
    let itemsPerPage = 10;
    let currentPage = this.state.currentPage;

    //change to zero based index
    for (let i = (currentPage - 1) * itemsPerPage;
      i < (currentPage - 1) * itemsPerPage + itemsPerPage && i < totalItems;
      i++) {
      itemsToDisplay.push(filteredItems[i]);
    }

    const iconClass = "";
    return (
      <>
        <div className="container-fluid">
          <div className="form-main-container">
            <div className="form-header border-bottom">
              <h2>{this.props.reportHeader}</h2>
            </div>
            <div className="form-container">
              <form>
                <div className="form-row">
                  <div className="form-group col-md-4">
                    <label htmlFor="inputIncident">Search</label>
                    <TextField placeholder="Enter search text" value={this.state.searchText} onKeyUp={(e) => this.onSearchKeyUp(e)}></TextField>
                  </div>
                  <div className="form-group col-md-4">
                    <label htmlFor="inputReportType">From</label>
                    <DatePicker placeholder="Select from date" formatDate={(date) => { return date.toLocaleDateString(); }} showMonthPickerAsOverlay={true}
                      value={this.state.fromDate} onSelectDate={(date) => { this.onFromDateSelect(date); }} />
                  </div>
                  <div className="form-group col-md-4">
                    <label htmlFor="IncidentType">To</label>
                    <DatePicker placeholder="Select to date" formatDate={(date) => { return date.toLocaleDateString(); }} showMonthPickerAsOverlay={true}
                      value={this.state.toDate} minDate={this.state.fromDate} onSelectDate={(date) => { this.onToDateSelect(date); }} />
                  </div>
                  <div className="form-group col-md-4">
                    <div className="icon-input">
                      <Toggle
                        label={<div>Show Latest Versions Only</div>}
                        inlineLabel
                        onText="On"
                        offText="Off"
                        checked={this.state.showLatest}
                        onChange={(ev, checked) => this.onToggleVersionChange(ev, checked)}
                      />
                    </div>
                  </div>
                  <div className="form-group col text-right form-btn">
                    <CSVLink data={exportData} filename={'Reports.csv'}>
                      <PrimaryButton text="Export" style={{ marginRight: '10px' }} />
                    </CSVLink>
                    <DefaultButton className={styles["bottomButton__two"]} text="Clear" onClick={() => this.setState({
                      searchText: null,
                      fromDate: null,
                      toDate: null,
                      showLatest: false,
                      filteredItems: this.state.items
                    })} />
                  </div>
                </div>
              </form>
            </div>
            <hr className="line-ele" />
            <table className="table table-bordered">
              <thead className="table-header">
                <tr>
                  {
                    this.columns.map(col => {
                      return (<th scope="col">{col.name}</th>);
                    })
                  }
                </tr>
              </thead>
              <tbody>
                {itemsToDisplay.map(item => {
                  return (
                    <tr>
                      {
                        /* some reports have different names for the same field, in that case find the field value which is not empty and show it in table */
                        /* for example - incident number is referred as Markout ID in GTMO, whereas in other forms it will be referred as incident number */
                        this.columns.map(col => {
                          let val: string = "";
                          col.keys.map(key => {
                            if (item[key]) {
                              val = item[key];
                            }
                          });
                          return (<td>{val}</td>);
                        })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
            <nav className="grid-pagenation float-right" aria-label="Page navigation ">
              <Pagination
                activePage={currentPage}
                itemsCountPerPage={itemsPerPage}
                totalItemsCount={totalItems}
                pageRangeDisplayed={10}
                onChange={(num) => this.setState({ currentPage: num })}>
              </Pagination>
            </nav>
          </div>
        </div>
        <ConfirmDialog
          showDialog={this.state.showConfirmDialog}
          hideDialog={() => { this.setState({ showConfirmDialog: false, selItemID: null, selIncNumber: null, selReportType: null, selReportListTitle: null, selReportListETType: null }); }}
          onConfirm={() => this.onDelete()}
          dialogText="Are you sure you want to delete this report?"
          className={styles.dialogContent} />
      </>
    );
  }
}

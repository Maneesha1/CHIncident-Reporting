import { SPUser } from '@microsoft/sp-page-context';

export interface IAllReportsProps {
  currentUser: SPUser;
  siteUrl: string;
  reportCode: string;
  reportHeader: string;
  filter: string;
}

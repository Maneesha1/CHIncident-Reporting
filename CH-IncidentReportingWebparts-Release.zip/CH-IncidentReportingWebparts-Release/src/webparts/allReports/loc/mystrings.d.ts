declare interface IAllReportsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AllReportsWebPartStrings' {
  const strings: IAllReportsWebPartStrings;
  export = strings;
}

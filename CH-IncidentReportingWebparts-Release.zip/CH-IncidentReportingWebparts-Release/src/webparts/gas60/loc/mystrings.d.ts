declare interface IGas60WebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'Gas60WebPartStrings' {
  const strings: IGas60WebPartStrings;
  export = strings;
}

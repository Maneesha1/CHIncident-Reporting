import { IItem } from '@pnp/sp/items';
import { IFilePickerResult } from '@pnp/spfx-controls-react/lib/FilePicker';
import { IDropdownOption } from 'office-ui-fabric-react';
import { IFileInfo } from "../../../models/IFileInfo";
import { IMasterList } from '../../../models/IMasterList';

export interface IPGas60EventState {
    item: IItem;
    utilityCompanyIncidentNumber: string;
    utilityId: string;
    utilityName: string;
    selPersonnelReportingId: string;
    selPersonnelReportingEMail: string;
    selPersonnelReportingName: string;
    personnelReportingEmail: string;
    personnelReportingPhone: string;
    cHDivision: string[];
    chDivision: IDropdownOption[];
    CustomerName: string;
    CustomerAddress: string;
    CustomerTownZip: string;
    DispatchGasOrderNumber: string;
    OrderRecievedDt: Date;
    CallReceived: string;
    EmployeeDispatchedDt: Date;
    employeeDispatched: string;
    EmployeeName: string;
    MadeSafeDt: Date;
    FirstQualifiedUtilityDt: Date;
    ReceivedTimetoDispatch: string;
    ReceivedTimetoArrive: string;
    WhyResponsemorethan60: string;
    SupervisorAssigned: string;
    RecommendtoRemedy: string;
    SupervisorNotAssignWhy: string;
    cHInternalNotes: string;

    incVersion: number;
    incReportStatus: string;
    submittedDate: Date;
    isLatestVersion: boolean;

    attachmentFiles: IFileInfo[];
    masterListData: IMasterList[];


    showSubmitDialog: boolean;
    showConfirmDialog: boolean;
    showStatusDialog: boolean;
    showEmailDialog: boolean;
    submitDialogTitle: string;
    submitDialogText: string;
    statusDialogTitle: string;
    statusDialogText: string;
    confirmDialogText: string;
    onConfirmDialog: () => void;
    errorMessage: string;
    showSaveBtn: boolean;
    showSubmitBtn: boolean;
    showUnlockBtn: boolean;
    reportJson: string;

    footer: string;
    tooltips: any[];
}

import * as React from 'react';
import styles from './Gas60.module.scss';
import { IGas60Props } from './IGas60Props';
import { escape } from '@microsoft/sp-lodash-subset';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { TextField, Dropdown, IDropdownOption, DefaultButton, PrimaryButton, TooltipHost, CommandBarButton } from 'office-ui-fabric-react';
import { FontIcon } from 'office-ui-fabric-react/lib/Icon';
import { DateTimePicker, TimeConvention, TimeDisplayControlType } from '@pnp/spfx-controls-react/lib/DateTimePicker';
import ListService from '../../../services/ListService';
import PnPService from '../../../services/PnPService';
import SPHttpService from "../../../services/SPHttpService";
import * as Consts from '../../../common/constants';
import { IMasterList } from '../../../models/IMasterList';
import { IFileInfo } from '../../../models/IFileInfo';
import { IPGas60EventState } from './IPGas60EventState';
import { IUserProfile } from '../../../models/IUserProfile';
import { SubmitDialog } from "../../../common/components/SubmitDialog";
import { StatusDialog } from "../../../common/components/StatusDialog";
import { ConfirmDialog } from "../../../common/components/ConfirmDialog";
import PDFService from "../../../services/PDFService";
import Utilities from "../../../services/Utilities";
import { SendEmailDialog } from '../../../common/components/SendEmailDialog';
import WordService from '../../../services/WordService';

export default class Gas60Event extends React.Component<IGas60Props, IPGas60EventState> {

  private fileAttachRef;
  private isAdmin: boolean = false;
  private isContributor: boolean = false;
  private currentUserId: number;
  private attachments: string[] = [];

  constructor(props: IGas60Props, state: IPGas60EventState) {
    super(props);

    this.state = {
      item: null,
      attachmentFiles: [],
      masterListData: null,
      utilityCompanyIncidentNumber: null,
      utilityId: null,
      utilityName: null,
      selPersonnelReportingId: null,
      selPersonnelReportingEMail: null,
      selPersonnelReportingName: null,
      personnelReportingEmail: null,
      personnelReportingPhone: null,
      cHDivision: null,
      chDivision: [],
      CustomerName: null,
      CustomerAddress: null,
      CustomerTownZip: null,
      DispatchGasOrderNumber: null,
      OrderRecievedDt: null,
      CallReceived: null,
      EmployeeDispatchedDt: null,
      EmployeeName: null,
      MadeSafeDt: null,
      FirstQualifiedUtilityDt: null,
      ReceivedTimetoDispatch: null,
      ReceivedTimetoArrive: null,
      employeeDispatched: null,
      WhyResponsemorethan60: null,
      SupervisorAssigned: null,
      RecommendtoRemedy: null,
      SupervisorNotAssignWhy: null,
      cHInternalNotes: null,

      incVersion: 0,
      incReportStatus: null,
      submittedDate: null,
      isLatestVersion: false,

      showSubmitDialog: false,
      showConfirmDialog: false,
      showStatusDialog: false,
      showEmailDialog: false,
      submitDialogTitle: null,
      submitDialogText: null,
      statusDialogTitle: null,
      statusDialogText: null,
      confirmDialogText: null,
      onConfirmDialog: null,
      errorMessage: null,
      showSaveBtn: false,
      showSubmitBtn: false,
      showUnlockBtn: false,
      reportJson: null,

      footer: null,
      tooltips: null
    };
    this.fileAttachRef = React.createRef();
  }


  /** Event Handlers **/

  private onAttchSelect(e) {
    e.preventDefault();
    this.fileAttachRef.current.click();
  }

  private onAttachmentChange(event) {
    let resultFile = event.target.files;
    let fileInfos: IFileInfo[] = [];
    let promArr: Promise<any>[] = [];

    for (var i = 0; i < resultFile.length; i++) {
      var file = resultFile[i];
      var reader = new FileReader();
      promArr.push(new Promise((resolve, reject) => {
        reader.onload = ((fileToRead) => {
          return (e) => {
            //Push the converted file into array
            fileInfos.push({
              "name": fileToRead.name,
              "content": e.target.result
            });
            resolve();
          };
        })(file);
        reader.readAsArrayBuffer(file);
      }));
    }
    Promise.all(promArr).then(() => {
      this.setState({
        attachmentFiles: [...this.state.attachmentFiles, ...fileInfos]
      });
    });
  }

  private onCancelClick() {
    window.location.href = this.props.siteUrl;
  }

  private onDeleteAttachment(event, index) {
    let attachments = this.state.attachmentFiles;
    attachments.splice(index, 1);
    this.setState({
      attachmentFiles: attachments
    });
  }

  private onDropDownChange(event, selItem: IDropdownOption) {
    this.setState({
      ...this.state,
      [event.target.id]: selItem.text,
    });
  }

  private onExportPDFClick() {
    PDFService.ExportToPDFFromHTML(this.state.item["UtilityCompanyIncidentNumber"], this.state.item["Title"], this.state.reportJson);
  }

  /* export to word */
  private onExportWordClick() {
    WordService.generateDocument(this.state.item["UtilityCompanyIncidentNumber"], this.state.item["Title"], this.state.reportJson);
  }

  /* export to word */
  private onPrintlick() {
    Utilities.printHtml(this.state.item["UtilityCompanyIncidentNumber"], this.state.item["Title"], this.state.reportJson);
  }

  private onMultiDropdownChange(event, selItem: IDropdownOption) {
    this.setState({
      ...this.state,
      [event.target.id]: selItem.selected ? [...this.state[event.target.id], selItem.text] : this.state[event.target.id].filter(key => key !== selItem.key)
    });
  }

  private onPeoplePickerChange(items: any[]) {
    if (items.length > 0) {
      PnPService.getUserProfileProperties(items[0].loginName).then((userProps: IUserProfile) => {
        this.setState({
          selPersonnelReportingId: items[0].id,
          selPersonnelReportingEMail: userProps.WorkEmail,
          personnelReportingEmail: userProps.WorkEmail,
          personnelReportingPhone: userProps.WorkPhone
        });
      });
    }
    else {
      this.setState({
        selPersonnelReportingId: null,
        selPersonnelReportingEMail: null,
        personnelReportingEmail: null,
        personnelReportingPhone: null
      });
    }
  }

  /* On change event for text fields */
  private onTextChange(event) {
    const value = event.target.value;
    this.setState(
      {
        ...this.state,
        [event.target.name]: value
      }
    );
  }

  //=======================
  // date time order received 
  //==========================
  private OrderRecievedDt(value) {
    this.setState(
      {
        ...this.state,
        OrderRecievedDt: value
      }
    );
  }


  //===============================
  // date time employee dispatched 
  //===============================
  private EmployeeDispatchedDt(value) {
    this.setState(
      {
        ...this.state,
        EmployeeDispatchedDt: value
      }
    );
  }


  //===============================
  // date time made safe date 
  //===============================
  private MadeSafeDt(value) {
    this.setState(
      {
        ...this.state,
        MadeSafeDt: value
      }
    );
  }

  //===============================
  // date time made safe date 
  //===============================
  private FirstQualifiedUtilityDt(value) {
    this.setState(
      {
        ...this.state,
        FirstQualifiedUtilityDt: value
      }
    );
  }



  /**Helper Functions **/
  private bindAttachmentsFromList(resultFile) {
    let fileInfos: IFileInfo[] = [];
    let promArr: Promise<any>[] = [];

    for (var i = 0; i < resultFile.length; i++) {
      var attFile = resultFile[i];
      ((file) => {
        promArr.push(new Promise((resolve, reject) => {
          fetch(Consts.SITEURLS.ROOTSITE + file.ServerRelativeUrl).then(e => {
            let content = e.arrayBuffer();
            content.then(c => {
              fileInfos.push({
                "name": file.FileName,
                "content": c,
                "url": Consts.SITEURLS.ROOTSITE + file.ServerRelativeUrl
              });
              resolve();
            });
          });
        }));
      })(attFile);
    }

    Promise.all(promArr).then(() => {
      this.setState({
        attachmentFiles: fileInfos
      });
    });
  }


  private loadIncSubTypes(selIncTypes: string[]): IDropdownOption[] {
    let masterItems: IMasterList[] = this.state.masterListData;
    let incSubTypes: IMasterList[] = [];

    selIncTypes.forEach(selIncType => {
      masterItems.filter(masterItem => masterItem.SubCategory == selIncType).map(item => {
        incSubTypes.push(item);
      });
    });

    incSubTypes = this.removeDuplicatesFromArray(incSubTypes, "Value");
    let ddlOptions: IDropdownOption[] = [];
    incSubTypes.map(item => ddlOptions.push({
      key: item.Value, text: item.Value
    }));

    ddlOptions.sort((a, b) => a.text.localeCompare(b.text));
    return ddlOptions;
  }

  //==========================
  // LOAD REPORT DATA 
  //==========================

  private async loadReportData() {

    let allowSave: boolean = false;
    let allowSubmit: boolean = false;
    let allowUnlock: boolean = false;
    let submittedDt: Date = null;

    PnPService.getItemById(Consts.LISTTITLES.GL60, this.props.itemId, Consts.SELECTFIELDS.GL60, Consts.EXPANDFIELDS.GL60).then((item) => {

      if (item["Attachments"] == true) {
        item["AttachmentFiles"].forEach(file => {
          console.log(`${file.FileName}-${file.FileNameAsPath}-${file.ServerRelativePath}-${file.ServerRelativeUrl}`);
          this.attachments.push(file.FileName);
        });
        this.bindAttachmentsFromList(item["AttachmentFiles"]);
      }

      /* check save & submit conditions */
      if (this.isAdmin || this.isContributor) {
        /*Allow editing if it is a draft request */
        if (item[Consts.COMMONFIELDS.IncReportStatus] == Consts.INCSTATUS.Saved) {
          allowSave = true;
          allowSubmit = true;
        }
        /*Allow editing on latest versions of submitted request */
        else if (item[Consts.COMMONFIELDS.IncReportStatus] == Consts.INCSTATUS.Submitted && item[Consts.COMMONFIELDS.IsLatestVersion]) {

          if (item[Consts.COMMONFIELDS.SubmittedDate]) {

            submittedDt = new Date(item[Consts.COMMONFIELDS.SubmittedDate]);
            let elapsedTime = (new Date().getTime() - submittedDt.getTime()) / (1000 * 60 * 60);

            /*Allow editing within specified hours or if admin unlocked form */
            if (elapsedTime <= Consts.EditHours || item[Consts.COMMONFIELDS.LockStatus] == Consts.LOCKSTATUS.UNLOCKED) {
              allowSave = true;
              allowSubmit = true;
            }

            /*Allow unlock beyond specified time if user is admin */
            if (elapsedTime > Consts.EditHours && this.isAdmin && item[Consts.COMMONFIELDS.LockStatus] != Consts.LOCKSTATUS.UNLOCKED) {
              allowUnlock = true;
            }
          }
        }
      }

      /* Build HTML Table for Export to PDF, WORD and Send Mail */
      let repTable = Utilities.buildItemHTMLTable(item, Consts.SELECTFIELDS.GL60);


      this.setState({
        item: item,
        reportJson: repTable,
        utilityCompanyIncidentNumber: item[Consts.GAS60FIELDS.UtilityCompanyIncidentNumber],
        utilityId: item[Consts.GAS60FIELDS.UtilityId],
        utilityName: item[Consts.GAS60FIELDS.UtilityName],
        selPersonnelReportingId: item[Consts.GAS60FIELDS.UtilityPersonnelReportingId],
        selPersonnelReportingEMail: item[Consts.GAS60FIELDS.UtilityPersonnelReporting] ? item[Consts.GAS60FIELDS.UtilityPersonnelReporting]["EMail"] : null,
        selPersonnelReportingName: item[Consts.GAS60FIELDS.UtilityPersonnelReporting] ? item[Consts.GAS60FIELDS.UtilityPersonnelReporting]["Title"] : null,
        personnelReportingEmail: item[Consts.GAS60FIELDS.UtilityPersonnelEmail],
        personnelReportingPhone: item[Consts.GAS60FIELDS.UtilityPersonnelPhone],
        cHDivision: item[Consts.GAS60FIELDS.CHDivision],
        CustomerName: item[Consts.GAS60FIELDS.CustomerName],
        CustomerAddress: item[Consts.GAS60FIELDS.CustomerAddress],
        CustomerTownZip: item[Consts.GAS60FIELDS.CustomerTownZip],
        DispatchGasOrderNumber: item[Consts.GAS60FIELDS.DispatchGasOrderNumber],
        OrderRecievedDt: item[Consts.GAS60FIELDS.OrderRecievedDt] ? new Date(item[Consts.GAS60FIELDS.OrderRecievedDt]) : null,
        CallReceived: item[Consts.GAS60FIELDS.CallReceived],
        EmployeeDispatchedDt: item[Consts.GAS60FIELDS.EmployeeDispatchedDt] ? new Date(item[Consts.GAS60FIELDS.EmployeeDispatchedDt]) : null,
        employeeDispatched: item[Consts.GAS60FIELDS.EmployeeDispatched],
        EmployeeName: item[Consts.GAS60FIELDS.EmployeeName],
        MadeSafeDt: item[Consts.GAS60FIELDS.MadeSafeDt] ? new Date(item[Consts.GAS60FIELDS.MadeSafeDt]) : null,
        FirstQualifiedUtilityDt: item[Consts.GAS60FIELDS.FirstQualifiedUtilityDt] ? new Date(item[Consts.GAS60FIELDS.FirstQualifiedUtilityDt]) : null,
        ReceivedTimetoDispatch: item[Consts.GAS60FIELDS.ReceivedTimetoDispatch],
        ReceivedTimetoArrive: item[Consts.GAS60FIELDS.ReceivedTimetoArrive],
        WhyResponsemorethan60: item[Consts.GAS60FIELDS.WhyResponsemorethan60],
        SupervisorAssigned: item[Consts.GAS60FIELDS.SupervisorAssigned],
        RecommendtoRemedy: item[Consts.GAS60FIELDS.RecommendtoRemedy],
        SupervisorNotAssignWhy: item[Consts.GAS60FIELDS.SupervisorNotAssignWhy],

        incVersion: item[Consts.COMMONFIELDS.IncVersion],
        submittedDate: submittedDt,
        isLatestVersion: item[Consts.COMMONFIELDS.IsLatestVersion],
        incReportStatus: item[Consts.COMMONFIELDS.IncReportStatus],
        showSaveBtn: allowSave,
        showSubmitBtn: allowSubmit,
        showUnlockBtn: allowUnlock
      });
    }).catch(err => {
      console.log(err);
    });
  }

  private removeDuplicatesFromArray(arr: any[], key: string): any[] {
    return arr.reduce((accumulator, currentValue) => {
      const value = currentValue[key];
      if (!accumulator.some(item => item[key] === value)) {
        accumulator.push(currentValue);
      }
      return accumulator;
    }, []);
  }

  //======================== 
  // SAVE BUTTON
  //========================

  private saveIncident() {
    let incidentNumber: string;
    let url: string;

    if (this.props.formMode == Consts.FORMMODE.New) {
      let dt: Date = new Date();
      let year = dt.getFullYear();
      let month = ("0" + (dt.getMonth() + 1)).slice(-2);
      let date = ("0" + dt.getDate()).slice(-2);
      incidentNumber = `${Consts.REPORTCODES.GL60}-${year}${month}${date}-Draft`;
    }
    else if (this.props.formMode == Consts.FORMMODE.Edit) {
      incidentNumber = this.state.utilityCompanyIncidentNumber;
    }

    let body: string = JSON.stringify({
      '__metadata': {
        'type': Consts.LISTITEMENTTYPES.GL60
      },
      'Title': Consts.REPORTNAMES.GL60,
      [Consts.GAS60FIELDS.UtilityCompanyIncidentNumber]: incidentNumber,
      [Consts.GAS60FIELDS.UtilityId]: Consts.UtilityId,
      [Consts.GAS60FIELDS.UtilityName]: Consts.UtilityName,
      [Consts.GAS60FIELDS.UtilityPersonnelReportingId]: this.state.selPersonnelReportingId,
      [Consts.GAS60FIELDS.UtilityPersonnelEmail]: this.state.personnelReportingEmail,
      [Consts.GAS60FIELDS.UtilityPersonnelPhone]: this.state.personnelReportingPhone,
      [Consts.GAS60FIELDS.CustomerAddress]: this.state.CustomerAddress,
      [Consts.GAS60FIELDS.CHDivision]: this.state.cHDivision,
      [Consts.GAS60FIELDS.CustomerName]: this.state.CustomerName,
      [Consts.GAS60FIELDS.CustomerTownZip]: this.state.CustomerTownZip,
      [Consts.GAS60FIELDS.EmployeeDispatched]: this.state.employeeDispatched,
      [Consts.GAS60FIELDS.DispatchGasOrderNumber]: this.state.DispatchGasOrderNumber,
      [Consts.GAS60FIELDS.OrderRecievedDt]: this.state.OrderRecievedDt,
      [Consts.GAS60FIELDS.CallReceived]: this.state.CallReceived,
      [Consts.GAS60FIELDS.EmployeeDispatchedDt]: this.state.EmployeeDispatchedDt,
      [Consts.GAS60FIELDS.EmployeeName]: this.state.EmployeeName,
      [Consts.GAS60FIELDS.MadeSafeDt]: this.state.MadeSafeDt,
      [Consts.GAS60FIELDS.FirstQualifiedUtilityDt]: this.state.FirstQualifiedUtilityDt,
      [Consts.GAS60FIELDS.ReceivedTimetoDispatch]: this.state.ReceivedTimetoDispatch,
      [Consts.GAS60FIELDS.ReceivedTimetoArrive]: this.state.ReceivedTimetoArrive,
      [Consts.GAS60FIELDS.WhyResponsemorethan60]: this.state.WhyResponsemorethan60,
      [Consts.GAS60FIELDS.SupervisorAssigned]: this.state.SupervisorAssigned,
      [Consts.GAS60FIELDS.RecommendtoRemedy]: this.state.RecommendtoRemedy,
      [Consts.GAS60FIELDS.SupervisorNotAssignWhy]: this.state.SupervisorNotAssignWhy,
      [Consts.COMMONFIELDS.IncVersion]: Utilities.getNextMinorVersion(this.state.incVersion),
      [Consts.GAS60FIELDS.IncReportStatus]: Consts.INCSTATUS.Saved,
      [Consts.COMMONFIELDS.SubmittedDate]: new Date(),
      [Consts.COMMONFIELDS.LastEditedById]: this.currentUserId
    });

    /* if creating new incident or creating a new version of a submitted incident*/
    if (this.props.formMode == Consts.FORMMODE.New || this.state.incReportStatus == Consts.INCSTATUS.Submitted) {
      url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.GL60}')/items`;

      /* create list item */
      SPHttpService.Post(url, body).then((res) => {
        res.json().then((resJson) => {
          if (resJson && resJson.Id > 0) {
            /* attach files */
            PnPService.attachFilesToListItem(Consts.LISTTITLES.GL60, resJson.Id, this.state.attachmentFiles).then(() => {
              this.setState({
                showSubmitDialog: true,
                submitDialogText: `Incident report ${incidentNumber} saved successfully`
              });
            });
            /*Mark the current version as old*/
            if (this.state.incReportStatus == Consts.INCSTATUS.Submitted) {
              let reqBody: string = JSON.stringify({
                '__metadata': {
                  'type': Consts.LISTITEMENTTYPES.GL60
                },
                [Consts.COMMONFIELDS.LockStatus]: Consts.LOCKSTATUS.LOCKED,
                [Consts.COMMONFIELDS.IsLatestVersion]: false
              });

              let reqUrl = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.GL60}')/items(${this.props.itemId})`;
              SPHttpService.Update(reqUrl, reqBody).catch(err => console.log(err));
            }
          } else {
            this.setState({ errorMessage: "test" });
          }
        });
      }).catch((err) => {
        this.setState({ errorMessage: err });
      });
    }
    else if (this.props.formMode == Consts.FORMMODE.Edit && this.state.incReportStatus == Consts.INCSTATUS.Saved) {
      url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.GL60}')/items(${this.props.itemId})`;
      /* update list item and attach files */
      SPHttpService.Update(url, body).then((res) => {
        PnPService.attachFilesToListItem(Consts.LISTTITLES.GL60, this.props.itemId, this.state.attachmentFiles, this.attachments).then(() => {
          this.setState({
            showSubmitDialog: true,
            submitDialogText: `Incident report ${incidentNumber} saved successfully`
          });
        });
      }).catch((err) => {
        this.setState({ errorMessage: err });
      });
    }
  }
  //=======================
  //  SUBMIT BUTTON
  //=======================

  private submitIncident() {
    let url: string;
    let incidentNumber: string;
    let promiseIncNumber: Promise<any>[] = [];

    //Generate new incident number if it is new report
    if (this.props.formMode == Consts.FORMMODE.New ||
      Math.floor(this.state.incVersion) == 0) {
      promiseIncNumber.push(ListService.getNextIncidentNumber(Consts.REPORTCODES.GL60).then((incNum: number) => {
        let dt: Date = new Date();
        let year = dt.getFullYear();
        let month = ("0" + (dt.getMonth() + 1)).slice(-2);
        let date = ("0" + dt.getDate()).slice(-2);
        let num = incNum < 10 ? `0${incNum}` : incNum;
        incidentNumber = `${Consts.REPORTCODES.GL60}-${year}${month}${date}-${num}`;
      })
      );
    }
    else {
      incidentNumber = this.state.utilityCompanyIncidentNumber;
    }

    Promise.all(promiseIncNumber).then(() => {
      let body: string = JSON.stringify({
        '__metadata': {
          'type': Consts.LISTITEMENTTYPES.GL60
        },
        'Title': Consts.REPORTNAMES.GL60,
        [Consts.GAS60FIELDS.UtilityCompanyIncidentNumber]: incidentNumber,
        [Consts.GAS60FIELDS.UtilityId]: Consts.UtilityId,
        [Consts.GAS60FIELDS.UtilityName]: Consts.UtilityName,
        [Consts.GAS60FIELDS.UtilityPersonnelReportingId]: this.state.selPersonnelReportingId,
        [Consts.GAS60FIELDS.UtilityPersonnelEmail]: this.state.personnelReportingEmail,
        [Consts.GAS60FIELDS.UtilityPersonnelPhone]: this.state.personnelReportingPhone,
        [Consts.GAS60FIELDS.CHDivision]: this.state.cHDivision,
        [Consts.GAS60FIELDS.CustomerName]: this.state.CustomerName,
        [Consts.GAS60FIELDS.CustomerAddress]: this.state.CustomerAddress,
        [Consts.GAS60FIELDS.CustomerTownZip]: this.state.CustomerTownZip,
        [Consts.GAS60FIELDS.DispatchGasOrderNumber]: this.state.DispatchGasOrderNumber,
        [Consts.GAS60FIELDS.EmployeeDispatched]: this.state.employeeDispatched,
        [Consts.GAS60FIELDS.OrderRecievedDt]: this.state.OrderRecievedDt,
        [Consts.GAS60FIELDS.CallReceived]: this.state.CallReceived,
        [Consts.GAS60FIELDS.EmployeeDispatchedDt]: this.state.EmployeeDispatchedDt,
        [Consts.GAS60FIELDS.EmployeeName]: this.state.EmployeeName,
        [Consts.GAS60FIELDS.FirstQualifiedUtilityDt]: this.state.FirstQualifiedUtilityDt,
        [Consts.GAS60FIELDS.ReceivedTimetoDispatch]: this.state.ReceivedTimetoDispatch,
        [Consts.GAS60FIELDS.ReceivedTimetoArrive]: this.state.ReceivedTimetoArrive,
        [Consts.GAS60FIELDS.WhyResponsemorethan60]: this.state.WhyResponsemorethan60,
        [Consts.GAS60FIELDS.SupervisorAssigned]: this.state.SupervisorAssigned,
        [Consts.GAS60FIELDS.RecommendtoRemedy]: this.state.RecommendtoRemedy,
        [Consts.GAS60FIELDS.SupervisorNotAssignWhy]: this.state.SupervisorNotAssignWhy,
        [Consts.GAS60FIELDS.MadeSafeDt]: this.state.MadeSafeDt,
        [Consts.COMMONFIELDS.IncVersion]: (Math.floor(this.state.incVersion) + 1).toString(),
        [Consts.COMMONFIELDS.SubmittedDate]: new Date(),
        [Consts.COMMONFIELDS.IncReportStatus]: Consts.INCSTATUS.Submitted,
        [Consts.COMMONFIELDS.IsLatestVersion]: true,
        [Consts.COMMONFIELDS.SendEmail]: true,
        [Consts.COMMONFIELDS.LastEditedById]: this.currentUserId
      });

      if (this.props.formMode == Consts.FORMMODE.New ||
        (this.props.formMode == Consts.FORMMODE.Edit && this.state.incReportStatus == Consts.INCSTATUS.Submitted)) {

        url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.GL60}')/items`;

        SPHttpService.Post(url, body).then((res) => {
          res.json().then((resJson) => {
            if (resJson && resJson.Id > 0) {
              PnPService.attachFilesToListItem(Consts.LISTTITLES.GL60, resJson.Id, this.state.attachmentFiles).then(() => {
                this.setState({
                  showSubmitDialog: true,
                  submitDialogText: `Incident report ${incidentNumber} submitted successfully`
                });
              });

              /*Mark the current version as old*/
              if (this.props.formMode == Consts.FORMMODE.Edit) {
                let reqBody: string = JSON.stringify({
                  '__metadata': {
                    'type': Consts.LISTITEMENTTYPES.GL60
                  },
                  [Consts.COMMONFIELDS.LockStatus]: Consts.LOCKSTATUS.LOCKED,
                  [Consts.COMMONFIELDS.IsLatestVersion]: false
                });

                let reqUrl = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.GL60}')/items(${this.props.itemId})`;
                SPHttpService.Update(reqUrl, reqBody).catch(err => console.log(err));
              }
            }
            else {
              this.setState({ errorMessage: "test" });
            }
          });
        }).catch((err) => {
          this.setState({ errorMessage: err });
        });
      }
      else if (this.props.formMode == Consts.FORMMODE.Edit && this.state.incReportStatus == Consts.INCSTATUS.Saved) {
        url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.GL60}')/items(${this.props.itemId})`;
        SPHttpService.Update(url, body).then((res) => {
          PnPService.attachFilesToListItem(Consts.LISTTITLES.GL60, this.props.itemId, this.state.attachmentFiles, this.attachments).then(() => {
            this.setState({
              showSubmitDialog: true,
              submitDialogText: `Incident report ${incidentNumber} submitted successfully`
            });
          });
        }).catch((err) => {
          this.setState({ errorMessage: err });
        });
      }
    });
  }

  private unlockReport() {

    let body: string = JSON.stringify({
      '__metadata': {
        'type': Consts.LISTITEMENTTYPES.GL60
      },
      [Consts.COMMONFIELDS.LockStatus]: Consts.LOCKSTATUS.UNLOCKED
    });

    let url = `/_api/web/lists/getbytitle('${Consts.LISTTITLES.GL60}')/items(${this.props.itemId})`;
    SPHttpService.Update(url, body).then((res) => {
      this.setState({
        showConfirmDialog: false,
        showSubmitDialog: true,
        submitDialogText: `Incident report is unlocked`
      });
    }).catch((err) => {
      this.setState({ errorMessage: err });
    });
  }

  //==========================
  // COMPONENET DID MOUNT 
  //==========================  

  public componentDidMount() {

    /* load form boilerplate text */
    let formConfigPromise: Promise<any> = ListService.getFormConfigData(Consts.REPORTCODES.GL60);

    /* load form tooltips */
    let formTooltipsPromise: Promise<any> = ListService.getFormTooltips(Consts.REPORTCODES.GL60);

    /* load master list data for dropdowns */
    let masterListDataPromise: Promise<any> = ListService.getMasterListData(Consts.REPORTCODES.GL60);

    /* get current user permissions */
    let userGroupsPromise = PnPService.getCurrentUserGroups();

    Promise.all([formConfigPromise, formTooltipsPromise, masterListDataPromise, userGroupsPromise]).then((results) => {

      let footer: string = "";
      let tooltips = [];
      let items: IMasterList[] = [];

      /*boilerplate text */
      if (results[0] && results[0].value.length > 0) {
        footer = results[0].value[0]["Footer"];
      }

      /* get tooltips*/
      if (results[1] && results[1].value.length > 0) {
        results[1].value.forEach(item => {
          tooltips.push({
            key: item["Field"], value: item["Tooltip"]
          });
        });
      }

      /*master list data*/
      if (results[2]) {
        items = results[2].value;
      }

      /* user groups */
      if (results[3]) {
        this.isAdmin = results[3].indexOf(Consts.AdminGroup) > -1;
        this.isContributor = results[3].indexOf(Consts.ContributorsGroup) > -1;
      }

      /* update state */
      this.setState({
        footer: footer,
        tooltips: tooltips,
        masterListData: items,
        chDivision: this.getDropDownOptions(items, "CH Division")

      });

      /* get current user profile properties for new request */
      PnPService.spLoggedInUserDetails().then((user) => {
        this.currentUserId = user.Id;
        if (this.props.formMode == Consts.FORMMODE.New && (this.isAdmin || this.isContributor)) {
          this.setState({
            selPersonnelReportingId: user.Id,
            selPersonnelReportingEMail: this.props.currentUser.email,
            personnelReportingEmail: this.props.currentUser.email,
            personnelReportingPhone: user.WorkPhone,
            showSaveBtn: true,
            showSubmitBtn: true
          });
        }
        else if (this.props.formMode == Consts.FORMMODE.Edit) {
          this.loadReportData();
        }
      });
    });
  }
  private getDropDownOptions(items: IMasterList[], category: string, removeDuplicates: boolean = false, key: string = "", multiselect: boolean = false): IDropdownOption[] {
    let values: any[] = items.filter(item => item.Category == category);
    if (removeDuplicates) {
      values = this.removeDuplicatesFromArray(values, key);
    }
    let ddlOptions: IDropdownOption[] = [];
    if (!multiselect) {
      ddlOptions.push({ key: "", text: "" });
    }
    values.map(item => ddlOptions.push({
      key: item.SubCategory, text: item.SubCategory
    }));
    ddlOptions.sort((a, b) => a.text.localeCompare(b.text));
    return ddlOptions;
  }

  /* get tooltip of a fie,d from state */
  private getToolTipForField(fieldName: string): string {
    let tooltips = this.state.tooltips;
    let tooltip = "";
    if (tooltips && tooltips.length > 0) {
      let item = tooltips.filter(t => t.key == fieldName);
      if (item.length > 0) {
        tooltip = item[0].value;
      }
    }
    return tooltip;
  }

  public render(): React.ReactElement<IGas60Props> {
    const getKey = `datetime-${new Date().getTime()}`; /*Dummy key to forece render DateTime picker - to handle bug */
    const imgLogoI: string = require("../../../images/logoi.png");

    const {
      selPersonnelReportingId,
      personnelReportingEmail,
      personnelReportingPhone,
      CustomerName,
      CustomerAddress,
      CustomerTownZip,
      DispatchGasOrderNumber,
      EmployeeDispatchedDt,
      WhyResponsemorethan60,
      SupervisorNotAssignWhy

    } = this.state;

    let isFormValid: boolean = false;
    if (selPersonnelReportingId
      && personnelReportingEmail
      && personnelReportingPhone
      && CustomerName
      && CustomerAddress
      && CustomerTownZip
      && DispatchGasOrderNumber
      && EmployeeDispatchedDt

      && WhyResponsemorethan60
      && SupervisorNotAssignWhy
    ) {
      isFormValid = true;
    }

    return (
      <div>
        <div className={styles["content-megacontainer"]}>
          <form>
            <div className={styles["container-n"]}>
              <h5 className={styles["heading1"]}>Gas Odor Response 60 Minutes and Over</h5>
            </div>
            {this.props.formMode == Consts.FORMMODE.Edit && this.state.reportJson &&
              <div style={{ marginLeft: "65%" }}>
                {/* <CommandBarButton iconProps={{ iconName: "PDF" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Export as PDF" onClick={() => this.onExportPDFClick()} /> */}
                <CommandBarButton iconProps={{ iconName: "WordDocument" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Export as Word" onClick={() => this.onExportWordClick()} />
                <CommandBarButton iconProps={{ iconName: "Print" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Print / Save as PDF" onClick={() => this.onPrintlick()} />
                <CommandBarButton iconProps={{ iconName: "Mail" }} style={{ backgroundColor: "white", border: "0", height: "25px" }} text="Email" onClick={() => this.setState({ showEmailDialog: true })} />
              </div>
            }
            <hr className={styles["line"]} />
            <div className={styles["s"]}>
              {this.props.formMode == Consts.FORMMODE.Edit &&
                <p>Utilty Incident Number : <span className={styles["span1"]}>{this.state.utilityCompanyIncidentNumber}</span>
                  <span className={styles["span2"]}>CHGE "1001"</span>
                </p>
              }
              <p>Utilty Name : <span className={styles["span3"]}>Central Hudson Gas & Electric Corp.</span></p>
            </div>
            <div className={styles["content-container"]}>
              <p className={styles["heading"]}>Reporting Details<a href="#"><TooltipHost content={this.getToolTipForField("Reporting Details")}><img src={imgLogoI} /></TooltipHost></a></p>

              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Personnel Reporting <span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <PeoplePicker
                        context={this.props.context}
                        personSelectionLimit={1}
                        ensureUser={true}
                        onChange={(items) => this.onPeoplePickerChange(items)}
                        principalTypes={[PrincipalType.User]}
                        resolveDelay={100}
                        defaultSelectedUsers={[this.state.selPersonnelReportingEMail]} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Email<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="personnelReportingEmail" value={this.state.personnelReportingEmail} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Customer Name<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="CustomerName" value={this.state.CustomerName} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Customer Town and Zip<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="CustomerTownZip" value={this.state.CustomerTownZip} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Phone Number<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="personnelReportingPhone" value={this.state.personnelReportingPhone} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>CH Division :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <Dropdown id="cHDivision" placeholder="Select an option" calloutProps={{ className: styles["dropdownCalloutWidth"] }} className={styles["dropdownWidth"]} selectedKey={this.state.cHDivision} options={this.state.chDivision} onChange={(e, o) => this.onDropDownChange(e, o)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Customer Address <span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="CustomerAddress" value={this.state.CustomerAddress} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Gas Order Log Number <span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="DispatchGasOrderNumber" value={this.state.DispatchGasOrderNumber} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["two-columns-container"]}></div>
              <h5 className={styles["heading"]}>Date and Time Order Received <span className={styles["star"]}>*</span><a href="#"><TooltipHost content={this.getToolTipForField("Date and Time Order Received")}><img src={imgLogoI} /></TooltipHost></a></h5>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.OrderRecievedDt} onChange={(val) => this.OrderRecievedDt(val)} />
                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Call Received By :<a href="#"></a></label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="CallReceived" value={this.state.CallReceived} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles["two-columns-container"]}></div>
              <h5 className={styles["heading"]}>Date and Time Employee Dispatched<span className={styles["star"]}>*</span><a href="#"><TooltipHost content={this.getToolTipForField("Date and Time Employee Dispatched")}><img src={imgLogoI} /></TooltipHost></a></h5>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.EmployeeDispatchedDt} onChange={(val) => this.EmployeeDispatchedDt(val)} />
                </div>
                <div className={styles["column-2"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Employee Dispatched :</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField name="employeeDispatched" value={this.state.employeeDispatched} onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Supervisor Assigned:</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.SupervisorAssigned} name='SupervisorAssigned' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>
                  <h5 className={styles["heading"]}>Date and Time First Qualified Utility Personnel on scene<a href="#"><TooltipHost content={this.getToolTipForField("Date and Time First Qualified Utility Personnel on scene")}><img src={imgLogoI} /></TooltipHost></a></h5>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.FirstQualifiedUtilityDt} onChange={(val) => this.FirstQualifiedUtilityDt(val)} />
                </div>
                <div className={styles["column-2"]}>
                  <h5 className={styles["heading"]}>Calculated received time to dispatch time</h5>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>In Min</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.ReceivedTimetoDispatch} type="number" name='ReceivedTimetoDispatch' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["two-columns-container"]}>
                <div className={styles["column-1"]}>
                  <h5 className={styles["heading"]}>Date and Time made safe<a href="#"><TooltipHost content={this.getToolTipForField("Date and Time made safe")}><img src={imgLogoI} /></TooltipHost></a></h5>
                  <DateTimePicker key={getKey} timeConvention={TimeConvention.Hours24} timeDisplayControlType={TimeDisplayControlType.Dropdown} value={this.state.MadeSafeDt} onChange={(val) => this.MadeSafeDt(val)} />
                </div>
                <div className={styles["column-2"]}>
                  <h5 className={styles["heading"]}>Calculated received time to arrival time<a href="#"></a></h5>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>In Min</label>
                    </div>
                    <div className={styles["input-container"]}>
                      <TextField value={this.state.ReceivedTimetoArrive} type="number" name='ReceivedTimetoArrive' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Why was response time <br />60 minutes or over:<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["text-area-container"]}>
                      <TextField multiline rows={3} value={this.state.WhyResponsemorethan60} name='WhyResponsemorethan60' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Recommendation to <br />remedy the incident :</label>
                    </div>
                    <div className={styles["text-area-container"]}>
                      <TextField multiline rows={3} value={this.state.RecommendtoRemedy} name='RecommendtoRemedy' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>If supervisor was not <br />assigned, please explain<span className={styles["star"]}>*</span>:</label>
                    </div>
                    <div className={styles["text-area-container"]}>
                      <TextField multiline rows={3} value={this.state.SupervisorNotAssignWhy} name='SupervisorNotAssignWhy' onChange={(e) => this.onTextChange(e)} />
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["space-container"]}>
                <div className={styles["column-1"]}>
                  <div className={styles["label-input-conatiner"]}>
                    <div className={styles["label-conatiner"]}>
                      <label className={styles["label"]}>Additional Attachments:</label>
                      <PrimaryButton className={styles["attach"]} onClick={(e) => this.onAttchSelect(e)}>Choose Files</PrimaryButton>
                      <input type="file" ref={this.fileAttachRef} multiple={true} onChange={(e) => this.onAttachmentChange(e)} hidden />
                      {
                        this.state.attachmentFiles.length > 0 &&
                        <ul className={styles["attachment-list-alignment"]}>
                          {this.state.attachmentFiles.map((file: IFileInfo, index: number) => {
                            return (<li>{file.url ? (<a download={file.name} href={file.url} data-interception="off" target="_blank">{file.name}</a>) : <i>{file.name}</i>} <FontIcon iconName="Delete" onClick={(e) => this.onDeleteAttachment(e, index)} /></li>);
                          })
                          }
                        </ul>
                      }
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles["bottomButton"] + ' ' + styles["btn-gap"]}>
                <DefaultButton className={styles["bottomButton__one"]} text="Cancel" onClick={(e) => this.onCancelClick()} />
                {
                  this.state.showSaveBtn &&
                  <DefaultButton className={styles["bottomButton__two"]} text="Save" onClick={() => this.saveIncident()} />
                }
                {
                  this.state.showSubmitBtn &&
                  <PrimaryButton className={styles["bottomButton__three"]} text="Submit" disabled={!isFormValid} onClick={() => this.submitIncident()} />
                }
                {
                  this.state.showUnlockBtn &&
                  <PrimaryButton className={styles["bottomButton__three"]} text="Unlock Report"
                    onClick={() => this.setState({
                      showConfirmDialog: true,
                      confirmDialogText: "Are you sure you want to unlock this report?",
                      onConfirmDialog: () => this.unlockReport()
                    })} />
                }
              </div>
            </div>
            <hr className={styles["line"]} />
            <div className={styles["v"]}>
              <p className={styles["message"]}>{this.state.footer}</p>
            </div>
          </form>
        </div>
        <SubmitDialog
          showDialog={this.state.showSubmitDialog}
          hideDialog={() => { this.setState({ showSubmitDialog: false }); }}
          dialogTitle={this.state.submitDialogTitle}
          dialogText={this.state.submitDialogText}
          siteUrl={this.props.siteUrl}
          reportsPageUrl={this.props.siteUrl + Consts.REPORTPAGEURLS.GL60}
          className={styles.dialogContent} />
        <ConfirmDialog
          showDialog={this.state.showConfirmDialog}
          hideDialog={() => { this.setState({ showConfirmDialog: false }); }}
          onConfirm={this.state.onConfirmDialog}
          dialogText={this.state.confirmDialogText}
          className={styles.dialogContent} />
        <StatusDialog
          showDialog={this.state.showStatusDialog}
          hideDialog={() => { this.setState({ showStatusDialog: false }); }}
          dialogTitle={this.state.statusDialogTitle}
          dialogText={this.state.statusDialogText}
          className={styles.dialogContent} />
        <SendEmailDialog
          showDialog={this.state.showEmailDialog}
          hideDialog={() => { this.setState({ showEmailDialog: false }); }}
          title={this.state.item && this.state.item["Title"]}
          incidentNumber={this.state.utilityCompanyIncidentNumber}
          mailBody={this.state.reportJson}
          className={styles.dialogContent} />
      </div >
    );
  }
}

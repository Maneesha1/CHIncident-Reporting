import { IAttachmentFileInfo } from "@pnp/sp/attachments";

export interface IFileInfo extends IAttachmentFileInfo {
    name: string;
    content: ArrayBuffer;
    url?: string;
} 
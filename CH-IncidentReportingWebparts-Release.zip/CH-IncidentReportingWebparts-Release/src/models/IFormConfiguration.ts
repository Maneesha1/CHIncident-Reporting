export interface IFormConfiguration {
    Title: string;
    Header: string;
    Footer: string;
    
} 
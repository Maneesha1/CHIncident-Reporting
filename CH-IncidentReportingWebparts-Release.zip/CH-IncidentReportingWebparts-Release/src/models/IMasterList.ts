export interface IMasterList {
    Title: string;
    Category: string;
    SubCategory: string;
    Value: string;
} 
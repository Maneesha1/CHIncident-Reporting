import SPHttpService from "./SPHttpService";
import * as consts from '../common/constants';
import { SPHttpClientResponse } from '@microsoft/sp-http';


export default class ListService {
    

    /*get form boilerplate text*/
    public static getFormConfigData(reportCode: string): Promise<any> {

        let url: string = `/_api/web/lists/getbytitle('${consts.LISTTITLES.FORMCONFIG}')/items?$filter=Title eq '${reportCode}'&$top=500`;
        return SPHttpService.Get(url).then((response: SPHttpClientResponse) => {
            return response.json();
        });
    }

    /*get form tooltips*/
    public static getFormTooltips(reportCode: string): Promise<any> {

        let url: string = `/_api/web/lists/getbytitle('${consts.LISTTITLES.FORMTOOLTIPS}')/items?$filter=Title eq '${reportCode}'&$top=500`;
        return SPHttpService.Get(url).then((response: SPHttpClientResponse) => {
            return response.json();
        });
    }

    /*get master list data*/
    public static getMasterListData(reportCode: string): Promise<any> {

        const masterList: string = "Master List";
        let url: string = `/_api/web/lists/getbytitle('${masterList}')/items?$filter=Title eq '${reportCode}' or Title eq 'All' &$top=500`;
        //let url: string = `/_api/web/lists/getbytitle('${consts.LISTTITLES.MASTERLIST}')/items?$top=500`;
        return SPHttpService.Get(url).then((response: SPHttpClientResponse) => {
            return response.json();
        });
    }

    /*find last incident number and generate next incident sequence number*/
    public static getNextIncidentNumber(reportCode: string): Promise<number> {
        let url: string = `/_api/web/lists/getbytitle('${consts.LISTTITLES.INCNUMCOUNTER}')/items?$filter=Title eq '${reportCode}'`;
        let prevIncNumber: number;
        let newIncNumber: number;
        let id: number;
        let modifiedDate: Date;

        return new Promise<number>((resolve, reject) => {
            SPHttpService.Get(url).then((items) => {
                items.json().then((itemsJson) => {
                    if (itemsJson.value && itemsJson.value.length > 0) {
                        prevIncNumber = itemsJson.value[0][consts.INCNUMFIELDS.LASTINCNUM];
                        id = itemsJson.value[0].ID;
                        modifiedDate = new Date(itemsJson.value[0].Modified);

                        //Check if counter is updated today else reset counter
                        if (modifiedDate.setHours(0, 0, 0, 0) == new Date().setHours(0, 0, 0, 0)) {
                            newIncNumber = prevIncNumber + 1;
                        }
                        else {
                            newIncNumber = 1;
                        }

                        url = `/_api/web/lists/getbytitle('${consts.LISTTITLES.INCNUMCOUNTER}')/items(${id})`;
                        let body: string = JSON.stringify({
                            '__metadata': {
                                'type': consts.LISTITEMENTTYPES.INCNUMCOUNTER
                            },
                            [consts.INCNUMFIELDS.LASTINCNUM]: newIncNumber
                        });
                        SPHttpService.Update(url, body).then((res) => {
                            resolve(newIncNumber);
                        });
                    } else {
                        console.log("incident counter item not found");
                    }
                });
            });
        });
    }
}
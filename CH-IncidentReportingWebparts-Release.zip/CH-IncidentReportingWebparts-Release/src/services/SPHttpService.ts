import { SPHttpClient, SPHttpClientResponse, ISPHttpClientOptions } from '@microsoft/sp-http';

export default class SPHttpService {

    private static spHttpClient: SPHttpClient;
    private static siteUrl: string;

    public static init(spHttpClient: SPHttpClient, url: string) {
        this.spHttpClient = spHttpClient;
        this.siteUrl = url;
    }

    public static Get(reqUrl: string): Promise<SPHttpClientResponse> {
        var response = this.spHttpClient.get(this.siteUrl + reqUrl, SPHttpClient.configurations.v1);
        return response;
    }

    public static Post(reqUrl: string, reqBody: string): Promise<SPHttpClientResponse> {
        let options: ISPHttpClientOptions = {
            headers: {
                'Accept': 'application/json;odata=nometadata',
                'Content-type': 'application/json;odata=verbose',
                'odata-version': ''
            },
            body: reqBody
        };
        var response = this.spHttpClient.post(this.siteUrl + reqUrl, SPHttpClient.configurations.v1, options);
        return response;
    }

    public static Update(reqUrl: string, reqBody: string): Promise<SPHttpClientResponse> {
        let options: ISPHttpClientOptions = {
            headers: {
                'Accept': 'application/json;odata=nometadata',
                'Content-type': 'application/json;odata=verbose',
                'odata-version': '',
                'IF-MATCH': '*',
                'X-HTTP-Method': 'MERGE'
            },
            body: reqBody
        };
        var response = this.spHttpClient.post(this.siteUrl + reqUrl, SPHttpClient.configurations.v1, options);
        return response;
    }
}
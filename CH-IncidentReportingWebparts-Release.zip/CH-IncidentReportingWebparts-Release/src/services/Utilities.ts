import { sp } from "@pnp/sp";
import "@pnp/sp/sputilities";
import { IEmailProperties } from "@pnp/sp/sputilities";
export default class Utilities {

    /* send email using sp utility */
    public static sendEmail(to: string, title: string, incidentNumber: string, body: string) {

        Utilities.toDataURL(require('../images/chlogo.png'), (dataUrl) => {
            let headerHTML = `<img src="${dataUrl}"></img><h1>${title + " - " + incidentNumber}</h1><hr/>`;
            let emailProps: IEmailProperties = {
                To: to.split(";"),
                Body: headerHTML + body,
                Subject: incidentNumber
            };
            sp.utility.sendEmail(emailProps);
        });
    }

    /* print html */
    public static printHtml(incidentNumber: string, title: string, content: string) {
        let headerHTML = `<img src="${require('../images/chlogo.png')}" onload="javascript:window.print();window.close()"></img><h1>${title} - ${incidentNumber}</h1><hr/>`;
        var htmlBody = headerHTML + `<div id="source-html">${content}</div></body></html>`;
        let windowToPrint = window.open();
        windowToPrint.document.write(htmlBody);
    }

    /* generate html table for export and email purpose */
    public static buildItemHTMLTable(item: any, fields: any[]): string {
        let itemObj = {};

        /*skip internal fields*/
        let ignoreFields = ["ID", "Title", "Attachments", "AttachmentFiles", "IsLatestVersion", "LockStatus", "Modified", "Editor", "PSCAPIRequestBody", "PSCAPIResponse", "CHInternalNotes"];

        fields.forEach(field => {
            if (ignoreFields.indexOf(field.InternalName) == -1) {

                let fieldValue = "";
                if (field.Type == "Person") {
                    fieldValue = item[field.InternalName] ? item[field.InternalName]["Title"] : "";
                }
                else if (field.Type == "Date") {
                    fieldValue = item[field.InternalName] ? new Date(item[field.InternalName]).toLocaleString() : "";
                }
                else if (field.Type == "YesNo") {
                    fieldValue = item[field.InternalName] ? "Yes" : "No";
                }
                else if (field.Type == "Number") {
                    fieldValue = item[field.InternalName];
                }
                else {
                    fieldValue = item[field.InternalName] ? item[field.InternalName] : "";
                }

                itemObj[field.DisplayName] = fieldValue;

            }
        });

        let rows: string = "";
        Object.keys(itemObj).forEach(key => {
            rows +=
                "<tr>" +
                "<td style='border: 1px solid #dddddd; text-align: left; padding: 4px'><b>" + key + "</b></td>" +
                "<td style='border: 1px solid #dddddd; text-align: left; padding: 4px'>" + itemObj[key] + "</td>" +
                "</tr>";
        });

        let repTable = `<table style='border-collapse: collapse;'>` + rows + `</table>`;
        
        let footer = "<div><b><br/>Please contact</b> &nbsp;<u>CHG&E Dispatch Center</u>&nbsp; <b>at</b> &nbsp;<u>845-486-5604</u>&nbsp; <b>with any questions.</b><br /><p style='color:red;'>This report contains potentially confidential information. This report is intended for internal distribution only.</p></div>";
        repTable = repTable + footer;

        return repTable;
    }

    /* format a phone number to 888-888-8888 format*/
    public static formatPhoneNumber(phoneNumberString): string {
        var cleaned = ('' + phoneNumberString).replace(/\D/g, '');
        var match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
        if (match) {
            return match[1] + '-' + match[2] + '-' + match[3];
        }
        return phoneNumberString;
    }

    /* get next minor version number*/
    public static getNextMinorVersion(ver: number) {
        if (ver) {
            console.log('ver log 1');
            let arr = ver.toString().split('.');
            return arr.length > 1 ? `${arr[0]}.${(Number(arr[1]) + 1)}` : `${arr[0]}.1`;
        } else {
            console.log('ver log 2');
            return '0.1';
        }
    }

    /* convert image to base64 encoded format */
    public static toDataURL(url, callback) {
        var xhr = new XMLHttpRequest();
        xhr.onload = () => {
            var reader = new FileReader();
            reader.onloadend = () => {
                callback(reader.result);
            };
            reader.readAsDataURL(xhr.response);
        };
        xhr.open('GET', url);
        xhr.responseType = 'blob';
        xhr.send();
    }
}



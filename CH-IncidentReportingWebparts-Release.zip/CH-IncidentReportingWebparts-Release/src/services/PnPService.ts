import { sp } from "@pnp/sp/presets/all";
import { IFileInfo } from '../models/IFileInfo';
import { BaseWebPartContext } from "@microsoft/sp-webpart-base";
import { IItem, _Items } from "@pnp/sp/items/types";
import { IUserProfile } from "../models/IUserProfile";
import { ISiteUserInfo } from "@pnp/sp/site-users/types";

export default class PnPService {

    public static context: BaseWebPartContext;
    public static init(ctx: BaseWebPartContext) {
        sp.setup({
            spfxContext: ctx
        });
    }

    /* add attachments to list item*/
    public static async attachFilesToListItem(listTitle: string, ID: number, files: IFileInfo[], existingFiles?: string[]) {
        let item = await sp.web.lists.getByTitle(listTitle).items.getById(ID);
        //remove existing attachments
        if (existingFiles && existingFiles.length > 0) {
            try {
                await item.attachmentFiles.recycleMultiple(...existingFiles);
            } catch (error) {
                console.log(error);
            }
        }
        //add new attachments
        await item.attachmentFiles.addMultiple(files).then(v => {
            console.log(v);
        });
    }

    /* get all groups of current user*/
    public static getCurrentUserGroups(): Promise<string[]> {
        return sp.web.currentUser.groups.get()
            .then(groupInfo => {
                let groups: string[] = [];
                groupInfo.map(grp => {
                    groups.push(grp.Title);
                });
                return groups;
            });
    }

    /* check if current user belongs to a group*/
    public static checkUserIsInGroup(groupName: string): Promise<boolean> {
        return sp.web.currentUser.groups.getByName(groupName).get()
            .then((groupInfo) => {
                return groupInfo ? true : false;
            })
            .catch(err => {
                return false;
            });
    }

    /* get user profile properties */
    public static async getUserProfileProperties(loginName: string): Promise<any> {
        let userProps: {} = {};
        try {
            return sp.profiles.getPropertiesFor(loginName).then
                ((userProperties) => {
                    if (userProperties && userProperties.UserProfileProperties.length > 0) {
                        userProperties.UserProfileProperties.forEach(prop => {
                            userProps[prop.Key] = prop.Value;
                        });
                    }
                    return userProps;
                });
        }
        catch (error) {
            console.log("Error in getUserProfileProperties : " + error);
        }
    }

    /* get current user profile properties */
    public static async getMyProfileProperties(): Promise<any> {
        let userProps: {} = {};
        try {
            return sp.profiles.myProperties.get().then
                ((userProperties) => {
                    if (userProperties && userProperties.UserProfileProperties.length > 0) {
                        userProperties.UserProfileProperties.forEach(prop => {
                            userProps[prop.Key] = prop.Value;
                        });
                    }
                    return userProps;
                });
        }
        catch (error) {
            console.log("Error in getUserProfileProperties : " + error);
        }
    }

    /* get multiple items from a list with selected fields and filters */
    public static async getListItems(listTitle: string, selectFields: any[], expandFields: string, filter: string): Promise<any[]> {
        let selFields: string[] = [];
        selectFields.forEach((field: any) => {
            if (field.Type != "Person") {
                selFields.push(field.InternalName);
            }
            else {
                selFields.push(field.InternalName + "Id");
                selFields.push(field.InternalName + "/Title");
                selFields.push(field.InternalName + "/EMail");
            }
        });
        return await sp.web.lists.getByTitle(listTitle).items
            .filter(filter ? filter : "")
            .select(selFields.toString())
            .expand(expandFields ? expandFields : "")
            .orderBy("ID", false)
            .get();
    }

    /* get a list item by id */
    public static async getItemById(listTitle: string, id: number, selectFields: any[], expandFields: string[]): Promise<IItem> {

        let selFields: string[] = [];
        selectFields.forEach((field: any) => {
            if (field.Type != "Person") {
                selFields.push(field.InternalName);
            }
            else {
                selFields.push(field.InternalName + "Id");
                selFields.push(field.InternalName + "/Title");
                selFields.push(field.InternalName + "/EMail");
            }
        });
        return await sp.web.lists.getByTitle(listTitle).items.getById(id)
            .select(selFields.toString())
            .expand(expandFields.toString())
            .get();
    }

    /* get current logged in user details */
    public static async spLoggedInUserDetails(): Promise<any> {
        try {
            return new Promise<{ Id: number, WorkPhone: string }>(async (resolve, reject) => {
                let userId = await sp.web.currentUser.get().then((user: ISiteUserInfo) => { return user.Id; });
                //let userPhone = await this.getUserProfileProperties('i:0#.f|membership|sgorman@cenhud.com').then((userProps: IUserProfile) => { return userProps.WorkPhone });
                let userPhone = await this.getMyProfileProperties().then((userProps: IUserProfile) => { return userProps.WorkPhone; });
                resolve({ Id: userId, WorkPhone: userPhone });
            });
        } catch (error) {
            console.log("Error in spLoggedInUserDetails : " + error);
        }
    }

}
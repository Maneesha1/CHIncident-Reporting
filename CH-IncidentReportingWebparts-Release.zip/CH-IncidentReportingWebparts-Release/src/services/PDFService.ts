import { jsPDF, HTMLOptions } from "jspdf";
import Utilities from "./Utilities";
export default class PDFService {
    /* use jspdf plugin to export html table to pdf document*/
    public static ExportToPDFFromHTML(incidentNumber: string, title: string, content: string) {
        const pdf = new jsPDF('p', 'pt', 'letter');
        /* insert logo and title at the top of document */
        Utilities.toDataURL(require('../images/chlogo.png'), (dataUrl) => {
            pdf.addImage(dataUrl, 'png', 10, 10, 144, 46);
            pdf.text(title + " - " + incidentNumber, 160, 50);
            let options: HTMLOptions = {
                html2canvas: { width: 500 },
                callback: () => pdf.save(incidentNumber + '.pdf'),
                x: 25,
                y: 75
            };
            pdf.html(content, options);
        });
    }
}
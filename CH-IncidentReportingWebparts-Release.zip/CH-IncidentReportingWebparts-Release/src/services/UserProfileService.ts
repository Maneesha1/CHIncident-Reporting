import { IUserProfile } from '../models/IUserProfile';
import SPHttpService from "./SPHttpService";
import { SPHttpClientResponse } from '@microsoft/sp-http';

export default class UserProfileService {

    public static getCurrentUserProfileProps() {
        let url: string = `/_api/SP.UserProfiles.PeopleManager/GetMyProperties`;
        SPHttpService.Get(url).then((response: SPHttpClientResponse) => {
            response.json().then((userProfile: IUserProfile) => {
                console.log(userProfile);
            });
        });
    }

    public static getUserProfileProperties(userEmail: string) {
        let url: string = `/_api/SP.UserProfiles.PeopleManager/GetPropertiesFor(accountName=@v)?@v='${userEmail}'`;
        SPHttpService.Get(url).then((response: SPHttpClientResponse) => {
            response.json().then((userProfile: IUserProfile) => {
                console.log(userProfile);
            });
        });
    }
}  
import { HttpClient, HttpClientResponse } from '@microsoft/sp-http';
import * as Consts from "../common/constants";
export default class HttpService {

    private static httpClient: HttpClient;
    private static siteUrl: string;

    public static init(httpClient: HttpClient, url: string) {
        this.httpClient = httpClient;
        this.siteUrl = url;
    }

    public static async Get(reqUrl: string): Promise<HttpClientResponse> {
        return this.httpClient.get(this.siteUrl + reqUrl, HttpClient.configurations.v1);
    }

    public static async GetLatLongFromAddress(address: string): Promise<HttpClientResponse> {
        let url: string = `https://dev.virtualearth.net/REST/v1/Locations?q=${address}&key=${Consts.latlongAPIKey}`;
        return this.httpClient.get(url, HttpClient.configurations.v1);
    }

    public static async SubmitToPSCAPI(reqBody: string): Promise<any> {
        let authUrl: string;
        let submitUrl: string;
        let userName: string;
        let password: string;
        let authToken: string;

        if (this.siteUrl.toLocaleLowerCase() == Consts.SITEURLS.DEV.toLowerCase() || this.siteUrl.toLocaleLowerCase() == Consts.SITEURLS.TEST.toLowerCase()) {

            authUrl = Consts.PSCAPI.TEST_AUTH_ENDPOINT;
            submitUrl = Consts.PSCAPI.TEST_SUBMIT_ENDPOINT;
            userName = Consts.PSCAPI.TEST_USERNAME;
            password = Consts.PSCAPI.TEST_PWD;
        }
        else if (this.siteUrl.toLocaleLowerCase() == Consts.SITEURLS.PROD.toLowerCase()) {

            authUrl = Consts.PSCAPI.PROD_AUTH_ENDPOINT;
            submitUrl = Consts.PSCAPI.PROD_SUBMIT_ENDPOINT;
            userName = Consts.PSCAPI.PROD_USERNAME;
            password = Consts.PSCAPI.PROD_PWD;
        }

        /*Authenticate to API and get access token*/
        let authReqBody = JSON.stringify({ "Username": userName, "Password": password });
        try {
            let response = await this.httpClient.post(authUrl, HttpClient.configurations.v1,
                {
                    headers: { 'Content-Type': 'application/json' },
                    body: authReqBody
                });

            if (response) {
                let resJson = await response.json();
                authToken = resJson["token"];
            }

            if (authToken) {
                let incSubmitResponse = await this.httpClient.post(submitUrl, HttpClient.configurations.v1, {
                    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + authToken },
                    body: reqBody
                });
                let incSubmitResponseJson = await incSubmitResponse.json();
                if (incSubmitResponseJson) {
                    return incSubmitResponseJson;
                }
            }
        }
        catch (err) {
            return err;
        }
    }
}
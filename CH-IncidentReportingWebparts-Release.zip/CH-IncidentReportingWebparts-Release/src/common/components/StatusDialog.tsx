import * as React from 'react';
import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';
import { PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/Button';

export interface IStatusDialogProps {
    showDialog: boolean;
    dialogTitle: string;
    dialogText: string;
    redirectUrl?: string;
    className: string;
    hideDialog: () => void;
}

export const StatusDialog: React.FunctionComponent<IStatusDialogProps> = (props) => {

    return (
        <>
            <Dialog
                hidden={!props.showDialog}
                onDismiss={props.hideDialog}
                dialogContentProps={{
                    type: DialogType.normal,
                    title: props.dialogTitle,
                    subText: props.dialogText,
                    className: props.className
                }}
                modalProps={{
                    className: props.className
                }}
            >
                {props.redirectUrl &&
                    <DialogFooter>
                        <PrimaryButton onClick={() => { window.location.href = props.redirectUrl; }} text="OK" />
                    </DialogFooter>
                }
            </Dialog>
        </>
    );
};

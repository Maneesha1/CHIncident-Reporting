import * as React from 'react';
import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';
import { PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/Button';

export interface ISubmitDialogProps {
    showDialog: boolean;
    dialogTitle: string;
    dialogText: string;
    siteUrl: string;
    reportsPageUrl: string;
    className: string;
    hideDialog: () => void;
}

export const SubmitDialog: React.FunctionComponent<ISubmitDialogProps> = (props) => {

    return (
        <>
            <Dialog
                hidden={!props.showDialog}
                onDismiss={props.hideDialog}
                dialogContentProps={{
                    type: DialogType.normal,
                    title: props.dialogTitle,
                    subText: props.dialogText,
                    className: props.className
                }}
                modalProps={{
                    className: props.className
                }}
            >
                <DialogFooter>
                    <PrimaryButton onClick={() => { window.location.href = props.siteUrl; }} text="OK" />
                    <DefaultButton onClick={() => { window.location.href = props.reportsPageUrl; }} text="VIEW REPORTS" />
                </DialogFooter>
            </Dialog>
        </>
    );
};

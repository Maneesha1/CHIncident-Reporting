import * as React from 'react';
import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';
import { PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/Button';

export interface IConfirmDialogProps {
    showDialog: boolean;
    dialogText: string;
    className: string;
    hideDialog: () => void;
    onConfirm: () => void;
}

export const ConfirmDialog: React.FunctionComponent<IConfirmDialogProps> = (props) => {

    return (
        <>
            <Dialog
                hidden={!props.showDialog}
                onDismiss={props.hideDialog}
                dialogContentProps={{
                    type: DialogType.normal,
                    title: "Are you sure?",
                    subText: props.dialogText,
                    className: props.className
                }}
                modalProps={{
                    className: props.className
                }}
            >
                <DialogFooter>
                    <DefaultButton onClick={props.onConfirm} text="OK" />
                    <PrimaryButton onClick={props.hideDialog} text="Cancel" />
                </DialogFooter>
            </Dialog>
        </>
    );
};

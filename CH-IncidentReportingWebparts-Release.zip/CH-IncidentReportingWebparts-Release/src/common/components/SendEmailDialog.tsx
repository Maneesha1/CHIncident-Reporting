import * as React from 'react';
import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';
import { PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/Button';
import { TextField } from 'office-ui-fabric-react';
import Utilities from "../../services/Utilities";

export interface ISendEmailDialogProps {
    showDialog: boolean;
    className: string;
    hideDialog: () => void;
    title: string;
    incidentNumber: string;
    mailBody: string;
}

export const SendEmailDialog: React.FunctionComponent<ISendEmailDialogProps> = (props) => {

    const [to, setTo] = React.useState("");
    const [btnText, setBtnTxt] = React.useState("Cancel");
    const [message, setMessage] = React.useState("");
    const [showSendBtn, toggleSendBtn] = React.useState(true);

    function sendEmail() {
        if (to) {
            Utilities.sendEmail(to, props.title, props.incidentNumber, props.mailBody);
            setBtnTxt("OK");
            setMessage("Email sent");
            toggleSendBtn(false);
        }
    }

    function closeDialog() {
        props.hideDialog();
        setTo("");
        setBtnTxt("Cancel");
        setMessage("");
        toggleSendBtn(true);
    }

    return (
        <>
            <Dialog
                hidden={!props.showDialog}
                onDismiss={closeDialog}
                dialogContentProps={{
                    type: DialogType.normal,
                    title: "Send Email",
                    className: props.className
                }}
                modalProps={{
                    className: props.className
                }}
            >{message}
                {showSendBtn &&
                    <TextField multiline rows={3} placeholder="Enter email IDs separated by semicolon"
                        value={to} onChange={(ev, val) => setTo(val)} ></TextField>
                }
                <DialogFooter>
                    <DefaultButton onClick={sendEmail} text="Send Email" hidden={!showSendBtn} />
                    <PrimaryButton onClick={closeDialog} text={btnText} />
                </DialogFooter>
            </Dialog>
        </>
    );
};

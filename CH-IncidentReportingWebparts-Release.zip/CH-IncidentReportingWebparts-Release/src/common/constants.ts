
/*Bing maps API Key*/
export const latlongAPIKey = "AiplLn-NHMh63-nZ3jNKDzHGKkBqDbLiSV5XJCT4c7c7XGBdPrRFol8O-gw4zbPX";

/*Group Names */
export const AdminGroup = "Administrators";
export const ContributorsGroup = "Contributors";

/*Duation to allow edit*/
export const EditHours = 72;
export const SpillreportEditHours = 240;

/*Utility Id*/
export const UtilityId = '1001';
export const UtilityName ="Central Hudson Gas and Electric";

/*Report Names*/
export class REPORTNAMES {
    public static PSCE = "PSC Electric Event";
    public static PSCG = "PSC Gas or CO Event";
    public static TSA = "TSA Pipeline Security Events";
    public static SPL = "Spill Report";
    public static GTMO = "Gas Transmission Mark out";
    public static GL45 = "Gas Leak 45 and Over";
    public static GL60 = "Gas Leak 60 and Over";
    public static SAF = "Safety Event";
    public static DOT = "DOT";

}

/*Report Codes*/
export class REPORTCODES {
    public static PSCE = "PSCE";
    public static PSCG = "PSCG";
    public static TSA = "TSA";
    public static SPL = "SPL";
    public static GTMO = "GTMO";
    public static GL45 = "45GL";
    public static GL60 = "60GL";
    public static SAF = "SAF";
    public static DOT = "DOT";
}

/*Form Modes */
export enum FORMMODE {
    New = 0,
    Edit = 1
}

/*Statuses*/
export class INCSTATUS {
    public static Saved = "Saved";
    public static Submitted = "Submitted";
    public static Deleted = "Deleted";
}

/*List Titles*/
export class LISTTITLES {
    public static MASTERLIST: string = "Master List";
    public static INCNUMCOUNTER: string = "Incident Number Counter";
    public static EMAILCONFIG: string = "EmailConfiguration";
    public static FORMCONFIG: string = "FormConfiguration";
    public static FORMTOOLTIPS: string = "FormTooltips";
    public static PSCE: string = "PSC Electric Events";
    public static PSCG: string = "PSC Gas or CO Events";
    public static TSA: string = "TSA Pipeline Security Events";
    public static SPL: string = "Spill Reports";
    public static GTMO: string = "Gas Transmission Mark out";
    public static GL45: string = "Gas Leak 45 and Over";
    public static GL60: string = "Gas Leak 60 and Over";
    public static SAF: string = "Safety Reports";
    public static DOT: string = "DOT";
}

/*Lock Status*/
export class LOCKSTATUS {
    public static LOCKED = "Locked";
    public static UNLOCKED = "Unlocked";
}


/*List URLs */
export class LISTURLS {
    public static INCNUMCOUNTER: string = "IncNumCounter";
    public static PSCE: string = "PSCE";
    public static PSCG: string = "PSCG";
    public static TSA: string = "TSA";
    public static GTMO: string = "GTMO";
    public static SPL: string = "SPL";
    public static GL45: string = "GL45";
    public static GL60: string = "GL60";
    public static SAF: string = "SAF";
    public static DOT: string = "DOT";
}

/*List Item Entity Types*/
export class LISTITEMENTTYPES {
    public static INCNUMCOUNTER: string = "SP.Data.IncNumCounterListItem";
    public static PSCE: string = "SP.Data.PSCEListItem";
    public static PSCG: string = "SP.Data.PSCGListItem";
    public static TSA: string = "SP.Data.TSAListItem";
    public static SPL: string = "SP.Data.SPLListItem";
    public static GTMO: string = "SP.Data.GTMOListItem";
    public static GL45: string = "SP.Data.GL45ListItem";
    public static GL60: string = "SP.Data.GL60ListItem";
    public static SAF: string = "SP.Data.SAFListItem";
    public static DOT: string = "SP.Data.DOTListItem";
}

/************************* Field Internal Names *************************/

/*Incident Number Counter List Fields*/
export class INCNUMFIELDS {
    public static LASTINCNUM: string = "LastIncidentNum";
}

/* Common fields for business logic purpose */
export class COMMONFIELDS {
    public static IncVersion: string = "IncVersion";
    public static IncReportStatus: string = "IncReportStatus";
    public static SubmittedDate: string = "SubmittedDate";
    public static LockStatus: string = "LockStatus";
    public static IsLatestVersion: string = "IsLatestVersion";
    public static SendEmail: string = "SendEmail";
    public static SentToPSC: string = "SentToPSC";
    public static PSCAPIRequestBody: string = "PSCAPIRequestBody";
    public static PSCAPIResponse: string = "PSCAPIResponse";
    public static LastEditedById: string = "LastEditedById";
}

/*PSC Electric Event List Fields*/
export class PSCEFIELDS {
    public static ID: string = "ID";
    public static Attachments: string = "Attachments";
    public static AttachmentsFiles: string = "AttachmentFiles";
    public static UtilityCompanyIncidentNumber: string = "UtilityCompanyIncidentNumber";
    public static UtilityId: string = "UtilityId";
    public static UtilityName: string = "UtilityName";
    public static UtilityPersonnelReportingId: string = "UtilityPersonnelReportingId";
    public static UtilityPersonnelReporting: string = "UtilityPersonnelReporting";
    public static UtilityPersonnelPhone: string = "UtilityPersonnelPhone";
    public static UtilityPersonnelEmail: string = "UtilityPersonnelEmail";
    public static IncidentReportedToUtilityCompanyDt: string = "IncReportedToUtilityCompanyDt";
    public static IncidentReportedToDPSDt: string = "IncidentReportedToDPSDt";
    public static DPSStaffNotified: string = "DPSStaffNotified";
    public static IncidentOccurredDt: string = "IncidentOccurredDt";
    public static FinalRestorationDt: string = "FinalRestorationDt";
    public static IncidentType: string = "IncidentType";
    public static IncidentSubType: string = "IncidentSubType";
    public static IncidentDescription: string = "IncidentDescription";
    public static DeviceTypeAffected: string = "DeviceTypeAffected";
    public static FirstEmployeeArrivalDt: string = "FirstEmployeeArrivalDt";
    public static FirstQualifiedArrivalDt: string = "FirstQualifiedArrivalDt";
    public static LatitudeEquipmentImpacted: string = "LatitudeEquipmentImpacted";
    public static LongitudeEquipmentImpacted: string = "LongitudeEquipmentImpacted";
    public static AddressIncidentOccurred: string = "AddressIncidentOccurred";
    public static ClosestCrossStreetToIncident: string = "ClosestCrossStreetToIncident";
    public static TownLocalityIncidentOccurred: string = "TownLocalityIncidentOccurred";
    public static CountyIncidentOccurred: string = "CountyIncidentOccurred";
    public static ServicesInterruptedCount: string = "ServicesInterruptedCount";
    public static OutageJobNumberConnected: string = "OutageJobNumberConnected";
    public static EmployeeInjuriesReportedCount: string = "EmployeeInjuriesReportedCount";
    public static PublicInjuriesReportedCount: string = "PublicInjuriesReportedCount";
    public static EmployeeFatalitiesCount: string = "EmployeeFatalitiesCount";
    public static PublicFatalitiesCount: string = "PublicFatalitiesCount";
    public static TypeOfInjury: string = "TypeOfInjury";
    public static AreaAffectedInjury: string = "AreaAffectedInjury";
    public static InjurySeverity: string = "InjurySeverity";
    public static HospitalName: string = "HospitalName";
    public static AffectedCriticalFacilitiesCount: string = "AffectedCriticalFacilitiesCount";
    public static AffectedCriticalFacilityName: string = "AffectedCriticalFacilityName";
    public static CHInternalNotes: string = "CHInternalNotes";
    public static LastEditedBy: string = "LastEditedBy";
}

/*PSC Gas or CO Events List Fields*/
export class PSCGFIELDS {
    public static ID: string = "ID";
    public static Attachments: string = "Attachments";
    public static AttachmentsFiles: string = "AttachmentFiles";
    public static UtilityCompanyIncidentNumber: string = "UtilityCompanyIncidentNumber";
    public static UtilityId: string = "UtilityId";
    public static UtilityName: string = "UtilityName";
    public static UtilityPersonnelReportingId: string = "UtilityPersonnelReportingId";
    public static UtilityPersonnelReporting: string = "UtilityPersonnelReporting";
    public static UtilityPersonnelPhone: string = "UtilityPersonnelPhone";
    public static UtilityPersonnelEmail: string = "UtilityPersonnelEmail";
    public static IncidentReportedToUtilityCompanyDt: string = "IncReportedToUtilityCompanyDt";
    public static IncidentReportedToDPSDt: string = "IncidentReportedToDPSDt";
    public static DPSStaffNotified: string = "DPSStaffNotified";
    public static IncidentOccurredDt: string = "IncidentOccurredDt";
    public static IncidentDescription: string = "IncidentDescription";
    public static LatitudeEquipmentImpacted: string = "LatitudeEquipmentImpacted";
    public static LongitudeEquipmentImpacted: string = "LongitudeEquipmentImpacted";
    public static AddressIncidentOccurred: string = "AddressIncidentOccurred";
    public static ClosestCrossStreetToIncident: string = "ClosestCrossStreetToIncident";
    public static TownLocalityIncidentOccurred: string = "TownLocalityIncidentOccurred";
    public static CountyIncidentOccurred: string = "CountyIncidentOccurred";
    public static ServicesInterruptedCount: string = "ServicesInterruptedCount";
    public static EmployeeInjuriesReportedCount: string = "EmployeeInjuriesReportedCount";
    public static PublicInjuriesReportedCount: string = "PublicInjuriesReportedCount";
    public static MediaCoverage: string = "Mediacoverage";
    public static DispatchDt: string = "DispatchDt";
    public static CrewArrivalDt: string = "CrewArrivalDt";
    public static MadeSafeDt: string = "MadeSafeDt";
    public static DispatchGasOrderNumber: string = "DispatchGasOrderNumber";
    public static ReportUpdateDt: string = "ReportUpdateDt";
    public static ReportUpdateDesc: string = "ReportUpdateDesc";
    public static ReportSubType: string = "ReportSubType";
    public static LastEditedBy: string = "LastEditedBy";
}

/*Gas 45 List Fields*/
export class GAS45FIELDS {
    public static ID: string = "ID";
    public static Attachments: string = "Attachments";
    public static AttachmentsFiles: string = "AttachmentFiles";
    public static UtilityCompanyIncidentNumber: string = "UtilityCompanyIncidentNumber";
    public static UtilityId: string = "UtilityId";
    public static UtilityName: string = "UtilityName";
    public static UtilityPersonnelReportingId: string = "UtilityPersonnelReportingId";
    public static UtilityPersonnelReporting: string = "UtilityPersonnelReporting";
    public static UtilityPersonnelPhone: string = "UtilityPersonnelPhone";
    public static UtilityPersonnelEmail: string = "UtilityPersonnelEmail";
    public static CHDivision: string = "CHDivision";
    public static CustomerName: string = "CustomerName";
    public static CustomerAddress: string = "CustomerAddress";
    public static CustomerTownZip: string = "CustomerTownZip";
    public static CustomerZip: string = "CustomerZip";
    public static DispatchGasOrderNumber: string = "DispatchGasOrderNumber";
    public static MadeSafeDt: string = "MadeSafeDt";
    public static OrderRecievedDt: string = "OrderRecievedDt";
    public static CallReceived: string = "CallReceived";
    public static EmployeeDispatchedDt: string = "EmployeeDispatchedDt";
    public static EmployeeNumber: string = "EmployeeNumber";
    public static FirstQualifiedUtilityDt: string = "FirstQualifiedUtilityDt";
    public static ReceivedTimetoDispatch: string = "ReceivedTimetoDispatch";
    public static ReceivedTimetoArrive: string = "ReceivedTimetoArrive";
    public static WhyResponsemorethan45: string = "WhyResponsemorethan45";
    public static SupervisorAssigned: string = "SupervisorAssigned";
    public static RecommendtoRemedy: string = "RecommendtoRemedy";
    public static SupervisorNotAssignWhy: string = "SupervisorNotAssignWhy";
    public static IncVersion: string = "IncVersion";
    public static IncReportStatus: string = "IncReportStatus";
    public static SubmittedDate: string = "SubmittedDate";
    public static IsLatestVersion: string = "IsLatestVersion";
    public static LockStatus: string = "LockStatus";
    public static LastEditedBy: string = "LastEditedBy";
}

/*Gas 60 List Fields*/
export class GAS60FIELDS {
    public static IsLatestVersion: string = "IsLatestVersion";
    public static LockStatus: string = "LockStatus";
    public static ID: string = "ID";
    public static Attachments: string = "Attachments";
    public static AttachmentsFiles: string = "AttachmentFiles";
    public static UtilityCompanyIncidentNumber: string = "UtilityCompanyIncidentNumber";
    public static UtilityId: string = "UtilityId";
    public static UtilityName: string = "UtilityName";
    public static UtilityPersonnelReportingId: string = "UtilityPersonnelReportingId";
    public static UtilityPersonnelReporting: string = "UtilityPersonnelReporting";
    public static UtilityPersonnelPhone: string = "UtilityPersonnelPhone";
    public static UtilityPersonnelEmail: string = "UtilityPersonnelEmail";
    public static CHDivision: string = "CHDivision";
    public static CustomerName: string = "CustomerName";
    public static CustomerAddress: string = "CustomerAddress";
    public static CustomerTownZip: string = "CustomerTownZip";
    public static CustomerZip: string = "CustomerZip";
    public static DispatchGasOrderNumber: string = "DispatchGasOrderNumber";
    public static MadeSafeDt: string = "MadeSafeDt";
    public static OrderRecievedDt: string = "OrderRecievedDt";
    public static CallReceived: string = "CallReceived";
    public static EmployeeDispatchedDt: string = "EmployeeDispatchedDt";
    public static EmployeeDispatched: string = "EmployeeDispatched";
    public static EmployeeName: string = "EmployeeName";
    public static FirstQualifiedUtilityDt: string = "FirstQualifiedUtilityDt";
    public static FirstEmployeeArrivalDt: string = "FirstEmployeeArrivalDt";
    public static UtilityPersonnelArrivalDt: string = "UtilityPersonnelArrivalDt";
    public static ReceivedTimetoDispatch: string = "ReceivedTimetoDispatch";
    public static ReceivedTimetoArrive: string = "ReceivedTimetoArrive";
    public static WhyResponsemorethan60: string = "WhyResponsemorethan60";
    public static SupervisorAssigned: string = "SupervisorAssigned";
    public static RecommendtoRemedy: string = "RecommendtoRemedy";
    public static SupervisorNotAssignWhy: string = "SupervisorNotAssignWhy";
    public static IncVersion: string = "IncVersion";
    public static IncReportStatus: string = "IncReportStatus";
    public static SubmittedDate: string = "SubmittedDate";
    public static LastEditedBy: string = "LastEditedBy";
}

/* Gas Transmission Line Markout List Fields*/
export class GTMOFIELDS {
    public static ID: string = "ID";
    public static Attachments: string = "Attachments";
    public static UtilityPersonnelReportingId: string = "UtilityPersonnelReportingId";
    public static UtilityPersonnelReporting: string = "UtilityPersonnelReporting";
    public static UtilityPersonnelPhone: string = "UtilityPersonnelPhone";
    public static LineDesignation: string = "LineDesignation";
    public static CHDivision: string = "CHDivision";
    public static SupervisorNotified: string = "SupervisorNotified";
    public static SupervisorNotifiedDt: string = "SupervisorNotifiedDt";
    public static FormCompletedBy: string = "FormCompletedBy";
    public static FormCompletedById: string = "FormCompletedById";
    public static FormCompletedByDt: string = "FormCompletedByDt";
    public static FollowUpComments: string = "FollowUpComments";
    public static UtilityCompanyIncidentNumber: string = "UtilityCompanyIncidentNumber";
    public static UtilityId: string = "UtilityId";
    public static UtilityName: string = "UtilityName";
    public static UtilityPersonnelEmail: string = "UtilityPersonnelEmail";
    public static IncReportStatus: string = "IncReportStatus";
    public static IncVersion: string = "IncVersion";
    public static LockStatus: string = "LockStatus";
    public static IncidentOccurredDt: string = "IncidentOccurredDt";
    public static SubmittedDate: string = "SubmittedDate";
    public static IsLatestVersion: string = "IsLatestVersion";
    public static LastEditedBy: string = "LastEditedBy";

}

/*TSA Pipeline Security Events Fields*/
export class TSAFIELDS {
    public static ID: string = "ID";
    public static Attachments: string = "Attachments";
    public static AttachmentsFiles: string = "AttachmentFiles";
    public static UtilityId: string = "UtilityId";
    public static UtilityName: string = "UtilityName";
    public static UtilityCompanyIncidentNumber: string = "UtilityCompanyIncidentNumber";
    public static UtilityPersonnelReportingId: string = "UtilityPersonnelReportingId";
    public static UtilityPersonnelReporting: string = "UtilityPersonnelReporting";
    public static UtilityPersonnelPhone: string = "UtilityPersonnelPhone";
    public static UtilityPersonnelEmail: string = "UtilityPersonnelEmail";
    public static AddressIncidentOccurred: string = "AddressIncidentOccurred";
    public static ClosestCrossStreetToIncident: string = "ClosestCrossStreetToIncident";
    public static CountyIncidentOccurred: string = "CountyIncidentOccurred";
    public static IncidentDescription: string = "IncidentDescription";
    public static LatitudeEquipmentImpacted: string = "LatitudeEquipmentImpacted";
    public static LongitudeEquipmentImpacted: string = "LongitudeEquipmentImpacted";
    public static TownLocalityIncidentOccurred: string = "TownLocalityIncidentOccurred";
    public static IncidentReportedToTSOCDt: string = "IncidentReportedToTSOCDt";
    public static AgencyNotified: string = "AgencyNotified";
    public static IncidentReportedToUtilityCompanyDt: string = "IncReportedToUtilityCompanyDt";
    public static TSOCStaffNotified: string = "TSOCStaffNotified";
    public static TSAShortDescription: string = "TSAShortDescription";
    public static IncidentOccurredDt: string = "IncidentOccurredDt";
    public static IncVersion: string = "IncVersion";
    public static IncReportStatus: string = "IncReportStatus";
    public static SubmittedDate: string = "SubmittedDate";
    public static LockStatus: string = "LockStatus";
    public static IsLatestVersion: string = "IsLatestVersion";
    public static LastEditedBy: string = "LastEditedBy";
}

/*DOT List Fields*/
export class DOTFIELDS {
    public static ID: string = "ID";
    public static Attachments: string = "Attachments";
    public static AttachmentsFiles: string = "AttachmentFiles";
    public static UtilityCompanyIncidentNumber: string = "UtilityCompanyIncidentNumber";
    public static UtilityId: string = "UtilityId";
    public static UtilityName: string = "UtilityName";
    public static UtilityPersonnelReportingId: string = "UtilityPersonnelReportingId";
    public static UtilityPersonnelReporting: string = "UtilityPersonnelReporting";
    public static UtilityPersonnelPhone: string = "UtilityPersonnelPhone";
    public static UtilityPersonnelEmail: string = "UtilityPersonnelEmail";
    public static AddressIncidentOccurred: string = "AddressIncidentOccurred";
    public static ClosestCrossStreetToIncident: string = "ClosestCrossStreetToIncident";
    public static IncidentDescription: string = "IncidentDescription";
    public static IncidentOccurredDt: string = "IncidentOccurredDt";
    public static IncidentReportedToUtilityCompanyDt: string = "IncReportedToUtilityCompanyDt";
    public static LatitudeEquipmentImpacted: string = "LatitudeEquipmentImpacted";
    public static LongitudeEquipmentImpacted: string = "LongitudeEquipmentImpacted";
    public static MadeSafeDt: string = "MadeSafeDt";
    public static ServicesInterruptedCount: string = "ServicesInterruptedCount";
    public static TownLocalityIncidentOccurred: string = "TownLocalityIncidentOccurred";
    public static CountyIncidentOccurred: string = "CountyIncidentOccurred";
    public static Mediacoverage: string = "Mediacoverage";
    public static DispatchDt: string = "DispatchDt";
    public static CrewArrivalDt: string = "CrewArrivalDt";
    public static ReportUpdateDt: string = "ReportUpdateDt";
    public static ReportUpdateDesc: string = "ReportUpdateDesc";
    public static EmployeePriClass: string = "EmployeePriClass";
    public static DOTReportDt: string = "DOTReportDt";
    public static DOTReportNumber: string = "DOTReportNumber";
    public static DOTTroubleDispatch: string = "DOTTroubleDispatch";
    public static UtilityReportedDt: string = "UtilityReportedDt";
    public static IncVersion: string = "IncVersion";
    public static IncReportStatus: string = "IncReportStatus";
    public static SubmittedDate: string = "SubmittedDate";
    public static LockStatus: string = "LockStatus";
    public static IsLatestVersion: string = "IsLatestVersion";
    public static LastEditedBy: string = "LastEditedBy";
}

/*safety  Event List Fields*/
export class SAFFIELDS {

    public static ID: string = "ID";
    public static Attachments: string = "Attachments";
    public static AttachmentsFiles: string = "AttachmentFiles";
    public static UtilityCompanyIncidentNumber: string = "UtilityCompanyIncidentNumber";
    public static UtilityId: string = "UtilityId";
    public static UtilityName: string = "UtilityName";
    public static UtilityPersonnelReportingId: string = "UtilityPersonnelReportingId";
    public static UtilityPersonnelReporting: string = "UtilityPersonnelReporting";
    public static UtilityPersonnelPhone: string = "UtilityPersonnelPhone";
    public static UtilityPersonnelEmail: string = "UtilityPersonnelEmail";
    public static InjuryDescription: string = "InjuryDescription";
    public static EmployeeDepartment: string = "EmployeeDepartment";
    public static EmployeePriClass: string = "EmployeePriClass";
    public static SafetyDeptPersonnel: string = "SafetyDeptPersonnel";
    public static SupervisorName: string = "SupervisorName";
    public static SupervisorPhone: string = "SupervisorPhone";
    public static SafetyReportType: string = "SafetyReportType";
    public static IncidentDescription: string = "IncidentDescription";
    public static IncidentOccurredDt: string = "IncidentOccurredDt";
    public static ReportUpdateDt: string = "ReportUpdateDt";
    public static IncidentReportDt: string = "IncidentReportDt";
    public static ReportUpdateDesc: string = "ReportUpdateDesc";
    public static AddressIncidentOccurred: string = "AddressIncidentOccurred";
    public static ClosestCrossStreetToIncident: string = "ClosestCrossStreetToIncident";
    public static TownLocalityIncidentOccurred: string = "TownLocalityIncidentOccurred";
    public static CountyIncidentOccurred: string = "CountyIncidentOccurred";
    public static IncVersion: string = "IncVersion";
    public static IncReportStatus: string = "IncReportStatus";
    public static SubmittedDate: string = "SubmittedDate";
    public static LockStatus: string = "LockStatus";
    public static IsLatestVersion: string = "IsLatestVersion";
    public static LastEditedBy: string = "LastEditedBy";
}


/*PSC API*/
export class PSCAPI {
    public static TEST_AUTH_ENDPOINT: string = "https://uedqa.dps.ny.gov/api/V1/users/Authenticate";
    public static TEST_SUBMIT_ENDPOINT: string = "https://uedqa.dps.ny.gov/api/V1/Incidents/SubmitIncidentData";
    public static TEST_USERNAME: string = "CHGE";
    public static TEST_PWD: string = "5id7h43cWxcN9DakOd+ENw==";
    public static PROD_AUTH_ENDPOINT: string = "TBD";
    public static PROD_SUBMIT_ENDPOINT: string = "TBD";
    public static PROD_USERNAME: string = "TBD";
    public static PROD_PWD: string = "TBD";
}

/*Spills report*/
export class SPLFIELDS {
    public static IsLatestVersion: string = "IsLatestVersion";
    public static LockStatus: string = "LockStatus";
    public static ID: string = "ID";
    public static Attachments: string = "Attachments";
    public static AttachmentsFiles: string = "AttachmentFiles";
    public static UtilityCompanyIncidentNumber: string = "UtilityCompanyIncidentNumber";
    public static UtilityId: string = "UtilityId";
    public static UtilityName: string = "UtilityName";
    public static UtilityPersonnelReportingId: string = "UtilityPersonnelReportingId";
    public static UtilityPersonnelReporting: string = "UtilityPersonnelReporting";
    public static UtilityPersonnelPhone: string = "UtilityPersonnelPhone";
    public static UtilityPersonnelEmail: string = "UtilityPersonnelEmail";
    public static SpillOccurredDt: string = "SpillOccurredDt";
    public static SpillReportedDt: string = "SpillReportedDt";
    public static TD: string = "T_x0023_orD_x0023_";
    public static MaterialTypeSpilled: string = "MaterialTypeSpilled";
    public static ReasonForSpill: string = "ReasonforSpill";
    public static SpillQuantity: string = "SpillQuantity";
    public static SpillQuantityUnit: string = "SpillQuantityUnit";
    public static PCBDetermination: string = "PCBDetermination";
    public static PCMDeterminationMEthod: string = "PCMDeterminationMEthod";
    public static PCMDeterminationComments: string = "PCMDeterminationComments";
    public static TransformCapitalMonthYear: string = "TransformCapitalMonthYear";
    public static AddressIncidentOccurred: string = "AddressIncidentOccurred";
    public static ClosestCrossStreetToIncident: string = "ClosestCrossStreetToIncident";
    public static LatitudeEquipmentImpacted: string = "LatitudeEquipmentImpacted";
    public static LongitudeEquipmentImpacted: string = "LongitudeEquipmentImpacted";
    public static TownLocalityIncidentOccurred: string = "TownLocalityIncidentOccurred";
    public static CountyIncidentOccurred: string = "CountyIncidentOccurred";
    public static FacilityType: string = "FacilityType";
    public static SpillDescription: string = "SpillDescription";
    public static UpdatedSpillDesc: string = "UpdatedSpillDesc";
    public static IncVersion: string = "IncVersion";
    public static IncReportStatus: string = "IncReportStatus";
    public static SubmittedDate: string = "SubmittedDate";
    public static EmergencyMeasure: string = "EmergencyMeasure";
    public static RecoverdMaterialQty: string = "RecoverdMaterialQty";
    public static HazardtoHuman: string = "HazardtoHuman";
    public static AgencyNotified: string = "AgencyNotified";
    public static CHGEForemanonSite: string = "CHGEForemanonSite";
    public static AgencyNotifiedDt: string = "AgencyNotifiedDt";
    public static CHGEForemanonSitePhone: string = "CHGEForemanonSitePhone";
    public static EnvironmentalSOC: string = "EnvironmentalSOC";
    public static EnvironmentalCleanupContractor: string = "EnvironmentalCleanupContractor";
    public static ContractorOnSiteDt: string = "ContractorOnSiteDt";
    public static EnvironmentalComments: string = "EnvironmentalComments";
    public static DecSpfiill: string = "DecSpill_x0023_";
    public static PolePadVehicleNumber: string = "PolePadVehicleNumber";
    public static OperatingDistrict: string = "OperatingDistrict";
    public static TransformerNum: string = "TransformerNum";
    public static InjuriesSustained: string = "InjuriesSustained";
    public static ClearofStreamsPonds: string = "ClearofStreamsPonds";
    public static LastEditedBy: string = "LastEditedBy";
}

export class SITEURLS {
    public static ROOTSITE: string = "https://centralhudson.sharepoint.com";
    public static DEV: string = "https://centralhudson.sharepoint.com/sites/CentralHudsonIncidentReportingDev";
    public static TEST: string = "https://centralhudson.sharepoint.com/sites/CentralHudsonIncidentReportingTest";
    public static PROD: string = "TBD";
}

export class FORMURLS {
    public static PSCE: string = "/SitePages/PSCEForm.aspx";
    public static PSCG: string = "/SitePages/PSCGForm.aspx";
    public static TSA: string = "/SitePages/TSAForm.aspx";
    public static SPL: string = "/SitePages/SPLForm.aspx";
    public static GTMO: string = "/SitePages/GTMOForm.aspx";
    public static GL45: string = "/SitePages/GL45Form.aspx";
    public static GL60: string = "/SitePages/GL60Form.aspx";
    public static SAF: string = "/SitePages/SAFForm.aspx";
    public static DOT: string = "/SitePages/DOTForm.aspx";
}

export class REPORTPAGEURLS {
    public static ALLREPORTS: string = "/SitePages/AllReports.aspx";
    public static PSCE: string = "/SitePages/PSCEReports.aspx";
    public static PSCG: string = "/SitePages/PSCGReports.aspx";
    public static TSA: string = "/SitePages/TSAReports.aspx";
    public static SPL: string = "/SitePages/SPLReports.aspx";
    public static GTMO: string = "/SitePages/GTMOReports.aspx";
    public static GL45: string = "/SitePages/GL45Reports.aspx";
    public static GL60: string = "/SitePages/GL60Reports.aspx";
    public static SAF: string = "/SitePages/SAFReports.aspx";
    public static DOT: string = "/SitePages/DOTReports.aspx";
}

export class SELECTFIELDS {
    public static PSCE = [
        { InternalName: 'UtilityName', DisplayName: 'Utility Name', Type: 'Text' },
        { InternalName: 'ID', DisplayName: 'ID', Type: 'Text' },
        { InternalName: 'Attachments', DisplayName: 'Attachments', Type: 'YesNo' },
        { InternalName: 'AttachmentFiles', DisplayName: 'AttachmentFiles', Type: 'Text' },
        { InternalName: 'IncVersion', DisplayName: 'Incident Version', Type: 'Text' },
        { InternalName: 'IsLatestVersion', DisplayName: 'Is Latest Version', Type: 'YesNo' },
        { InternalName: 'IncReportStatus', DisplayName: 'Status', Type: 'Text' },
        { InternalName: 'LockStatus', DisplayName: 'Lock Status', Type: 'Text' },
        { InternalName: 'SubmittedDate', DisplayName: 'Time Submitted', Type: 'Date' },
        { InternalName: 'Modified', DisplayName: 'Modified', Type: 'Date' },
        { InternalName: 'Title', DisplayName: 'Title', Type: 'Text' },
        { InternalName: 'Editor', DisplayName: 'Editor', Type: 'Person' },
        { InternalName: 'LastEditedBy', DisplayName: 'Last Edited By', Type: 'Person' },
        { InternalName: 'UtilityCompanyIncidentNumber', DisplayName: 'Incident Number', Type: 'Text' },
        { InternalName: 'IncidentType', DisplayName: 'Incident Type', Type: 'Text' },
        { InternalName: 'IncidentSubType', DisplayName: 'Incident Sub Type', Type: 'Text' },
        { InternalName: 'UtilityId', DisplayName: 'Utility Id', Type: 'Text' },
        { InternalName: 'UtilityPersonnelReporting', DisplayName: 'Person Placing Report', Type: 'Person' },
        { InternalName: 'UtilityPersonnelPhone', DisplayName: 'Reported By Phone', Type: 'Text' },
        { InternalName: 'UtilityPersonnelEmail', DisplayName: 'Reported By Email', Type: 'Text' },
        { InternalName: 'IncidentOccurredDt', DisplayName: 'Time Incident Occurred', Type: 'Date' },
        { InternalName: 'IncReportedToUtilityCompanyDt', DisplayName: 'Time Incident Reported to Utility', Type: 'Date' },
        { InternalName: 'IncidentReportedToDPSDt', DisplayName: 'Time Incident Reported to DPS', Type: 'Date' },
        { InternalName: 'DPSStaffNotified', DisplayName: 'DPS Staff Notified', Type: 'Text' },
        { InternalName: 'FirstEmployeeArrivalDt', DisplayName: 'Time First Employee Arrived', Type: 'Date' },
        { InternalName: 'FirstQualifiedArrivalDt', DisplayName: 'Time First Qualified Personnel Arrived', Type: 'Date' },
        { InternalName: 'FinalRestorationDt', DisplayName: 'Time of Final Restoration', Type: 'Date' },
        { InternalName: 'AddressIncidentOccurred', DisplayName: 'Location of Incident', Type: 'Text' },
        { InternalName: 'ClosestCrossStreetToIncident', DisplayName: 'Closest Cross Street to Incident', Type: 'Text' },
        { InternalName: 'TownLocalityIncidentOccurred', DisplayName: 'Town/Locality Incident Occurred', Type: 'Text' },
        { InternalName: 'CountyIncidentOccurred', DisplayName: 'County Incident Occurred', Type: 'Text' },
        { InternalName: 'IncidentDescription', DisplayName: 'Incident Description', Type: 'Text' },
        { InternalName: 'DeviceTypeAffected', DisplayName: 'Device Type Affected', Type: 'Text' },
        { InternalName: 'LatitudeEquipmentImpacted', DisplayName: 'Incident Location Latitude', Type: 'Text' },
        { InternalName: 'LongitudeEquipmentImpacted', DisplayName: 'Incident Location Longitude', Type: 'Text' },
        { InternalName: 'ServicesInterruptedCount', DisplayName: 'Services Interrupted Count', Type: 'Number' },
        { InternalName: 'OutageJobNumberConnected', DisplayName: 'Order/Case Number', Type: 'Text' },
        { InternalName: 'EmployeeInjuriesReportedCount', DisplayName: 'Employee Injuries Reported', Type: 'Number' },
        { InternalName: 'PublicInjuriesReportedCount', DisplayName: 'Public Injuries Reported', Type: 'Number' },
        { InternalName: 'EmployeeFatalitiesCount', DisplayName: 'Employee Fatalities Reported', Type: 'Number' },
        { InternalName: 'PublicFatalitiesCount', DisplayName: 'Public Fatalities Reported', Type: 'Number' },
        { InternalName: 'TypeOfInjury', DisplayName: 'Type of Injury', Type: 'Text' },
        { InternalName: 'AreaAffectedInjury', DisplayName: 'Areas Affected by Injury', Type: 'Text' },
        { InternalName: 'InjurySeverity', DisplayName: 'Injury Severity', Type: 'Text' },
        { InternalName: 'HospitalName', DisplayName: 'Hospital Name', Type: 'Text' },
        { InternalName: 'AffectedCriticalFacilitiesCount', DisplayName: 'Count of Affected Critical Facilities', Type: 'Number' },
        { InternalName: 'AffectedCriticalFacilityName', DisplayName: 'Affected Critical Facility Name', Type: 'Text' },
        { InternalName: 'CHInternalNotes', DisplayName: 'CH Internal Notes', Type: 'Text' },
        { InternalName: 'SentToPSC', DisplayName: 'Sent to PSC', Type: 'YesNo' },
        { InternalName: 'PSCAPIRequestBody', DisplayName: 'PSCAPIRequestBody', Type: 'Text' },
        { InternalName: 'PSCAPIResponse', DisplayName: 'PSCAPIResponse', Type: 'Text' }
    ];

    public static PSCG = [
        { InternalName: 'UtilityName', DisplayName: 'Utility Name', Type: 'Text' },
        { InternalName: 'ID', DisplayName: 'ID', Type: 'Text' },
        { InternalName: 'Attachments', DisplayName: 'Attachments', Type: 'YesNo' },
        { InternalName: 'AttachmentFiles', DisplayName: 'Attachment Files', Type: 'Text' },
        { InternalName: 'IncVersion', DisplayName: 'Incident Version', Type: 'Text' },
        { InternalName: 'IsLatestVersion', DisplayName: 'Is Latest Version', Type: 'YesNo' },
        { InternalName: 'IncReportStatus', DisplayName: 'Status', Type: 'Text' },
        { InternalName: 'LockStatus', DisplayName: 'LockS tatus', Type: 'Text' },
        { InternalName: 'SubmittedDate', DisplayName: 'Time Submitted', Type: 'Date' },
        { InternalName: 'Modified', DisplayName: 'Modified', Type: 'Date' },
        { InternalName: 'Title', DisplayName: 'Title', Type: 'Text' },
        { InternalName: 'Editor', DisplayName: 'Editor', Type: 'Person' },
        { InternalName: 'LastEditedBy', DisplayName: 'Last Edited By', Type: 'Person' },
        { InternalName: 'UtilityCompanyIncidentNumber', DisplayName: 'Incident Number', Type: 'Text' },
        { InternalName: 'UtilityPersonnelReporting', DisplayName: 'Person Placing Report', Type: 'Person' },
        { InternalName: 'UtilityPersonnelPhone', DisplayName: 'Reported By Phone', Type: 'Text' },
        { InternalName: 'UtilityPersonnelEmail', DisplayName: 'Reported By Email', Type: 'Text' },
        { InternalName: 'IncidentOccurredDt', DisplayName: 'Time Incident Occurred', Type: 'Date' },
        { InternalName: 'IncReportedToUtilityCompanyDt', DisplayName: 'Time Incident Reported to Utility', Type: 'Date' },
        { InternalName: 'IncidentReportedToDPSDt', DisplayName: 'Time Incident Reported to DPS', Type: 'Date' },
        { InternalName: 'DPSStaffNotified', DisplayName: 'Name of DPS Staff Notified', Type: 'Text' },
        { InternalName: 'ReportSubType', DisplayName: 'Report Sub Type', Type: 'Text' },
        { InternalName: 'IncidentDescription', DisplayName: 'Incident Description', Type: 'Text' },        
        { InternalName: 'AddressIncidentOccurred', DisplayName: 'Location of Incident', Type: 'Text' },
        { InternalName: 'ClosestCrossStreetToIncident', DisplayName: 'Cross Street/<br/>Location Description', Type: 'Text' },
        { InternalName: 'TownLocalityIncidentOccurred', DisplayName: 'Town/Locality Incident Occurred', Type: 'Text' },
        { InternalName: 'CountyIncidentOccurred', DisplayName: 'County Incident Occurred', Type: 'Text' },
        { InternalName: 'LatitudeEquipmentImpacted', DisplayName: 'Incident Location Latitude', Type: 'Text' },
        { InternalName: 'LongitudeEquipmentImpacted', DisplayName: 'Incident Location Longitude', Type: 'Text' },
        { InternalName: 'ServicesInterruptedCount', DisplayName: 'Estimated # of Services Interrupted', Type: 'Number' },
        { InternalName: 'EmployeeInjuriesReportedCount', DisplayName: 'Employee Injuries Reported', Type: 'Number' },
        { InternalName: 'PublicInjuriesReportedCount', DisplayName: 'Public Injuries Reported', Type: 'Number' },
        { InternalName: 'Mediacoverage', DisplayName: 'Media coverage', Type: 'Text' },
        { InternalName: 'DispatchDt', DisplayName: 'Dispatch Time', Type: 'Date' },
        { InternalName: 'CrewArrivalDt', DisplayName: 'Crew Arrival Time', Type: 'Date' },
        { InternalName: 'MadeSafeDt', DisplayName: 'Made Safe Time', Type: 'Date' },
        { InternalName: 'DispatchGasOrderNumber', DisplayName: 'Order Number', Type: 'Text' },
        { InternalName: 'ReportUpdateDt', DisplayName: 'Time Report Updated', Type: 'Date' },
        { InternalName: 'ReportUpdateDesc', DisplayName: 'Report Update Description', Type: 'Text' }        
    ];

    public static TSA = [
        { InternalName: 'UtilityName', DisplayName: 'Utility Name', Type: 'Text' },
        { InternalName: 'ID', DisplayName: 'ID', Type: 'Text' },
        { InternalName: 'Attachments', DisplayName: 'Attachments', Type: 'YesNo' },
        { InternalName: 'AttachmentFiles', DisplayName: 'Attachment Files', Type: 'Text' },
        { InternalName: 'IncVersion', DisplayName: 'Incident Version', Type: 'Text' },
        { InternalName: 'IsLatestVersion', DisplayName: 'Is Latest Version', Type: 'YesNo' },
        { InternalName: 'IncReportStatus', DisplayName: 'Status', Type: 'Text' },
        { InternalName: 'LockStatus', DisplayName: 'Lock Status', Type: 'Text' },
        { InternalName: 'SubmittedDate', DisplayName: 'Time Submitted', Type: 'Date' },
        { InternalName: 'Modified', DisplayName: 'Modified', Type: 'Date' },
        { InternalName: 'Title', DisplayName: 'Title', Type: 'Text' },
        { InternalName: 'Editor', DisplayName: 'Editor', Type: 'Person' },
        { InternalName: 'LastEditedBy', DisplayName: 'Last Edited By', Type: 'Person' },
        { InternalName: 'UtilityCompanyIncidentNumber', DisplayName: 'Incident Number', Type: 'Text' },
        { InternalName: 'UtilityId', DisplayName: 'Utility Id', Type: 'Text' },
        { InternalName: 'UtilityPersonnelReporting', DisplayName: 'Person Placing Report', Type: 'Person' },
        { InternalName: 'UtilityPersonnelPhone', DisplayName: 'Reported By Phone', Type: 'Text' },
        { InternalName: 'UtilityPersonnelEmail', DisplayName: 'Reported By Email', Type: 'Text' },
        { InternalName: 'AddressIncidentOccurred', DisplayName: 'Location of Incident', Type: 'Text' },
        { InternalName: 'ClosestCrossStreetToIncident', DisplayName: 'Location Description/Cross Street', Type: 'Text' },
        { InternalName: 'CountyIncidentOccurred', DisplayName: 'County Incident Occurred', Type: 'Text' },
        { InternalName: 'IncidentDescription', DisplayName: 'Incident Description', Type: 'Text' },
        { InternalName: 'LatitudeEquipmentImpacted', DisplayName: 'Incident Location Latitude', Type: 'Text' },
        { InternalName: 'LongitudeEquipmentImpacted', DisplayName: 'Incident Location Longitude', Type: 'Text' },
        { InternalName: 'TownLocalityIncidentOccurred', DisplayName: 'Town/Locality Incident Occurred', Type: 'Text' },
        { InternalName: 'TSOCStaffNotified', DisplayName: 'TSOC Staff Notified', Type: 'Text' },
        { InternalName: 'IncidentReportedToTSOCDt', DisplayName: 'Date Incident Reported to TSOC', Type: 'Date' },
        { InternalName: 'IncidentOccurredDt', DisplayName: 'Date Incident Occurred', Type: 'Date' },
        { InternalName: 'AgencyNotified', DisplayName: 'Agency Notified', Type: 'Text' },
        { InternalName: 'IncReportedToUtilityCompanyDt', DisplayName: 'Time Incident Reported to Utility', Type: 'Date' },
        { InternalName: 'TSAShortDescription', DisplayName: 'TSA Short Description', Type: 'Text' }
    ];

    public static SPL = [
        { InternalName: 'UtilityName', DisplayName: 'Utility Name', Type: 'Text' },
        { InternalName: 'ID', DisplayName: 'ID', Type: 'Text' },
        { InternalName: 'Attachments', DisplayName: 'Attachments', Type: 'YesNo' },
        { InternalName: 'AttachmentFiles', DisplayName: 'Attachment Files', Type: 'Text' },
        { InternalName: 'IncVersion', DisplayName: 'Incident Version', Type: 'Text' },
        { InternalName: 'IsLatestVersion', DisplayName: 'Is Latest Version', Type: 'YesNo' },
        { InternalName: 'IncReportStatus', DisplayName: 'Status', Type: 'Text' },
        { InternalName: 'LockStatus', DisplayName: 'Lock Status', Type: 'Text' },
        { InternalName: 'SubmittedDate', DisplayName: 'Time Submitted', Type: 'Date' },
        { InternalName: 'Modified', DisplayName: 'Modified', Type: 'Date' },
        { InternalName: 'Title', DisplayName: 'Title', Type: 'Text' },
        { InternalName: 'Editor', DisplayName: 'Editor', Type: 'Person' },
        { InternalName: 'LastEditedBy', DisplayName: 'Last Edited By', Type: 'Person' },
        { InternalName: 'UtilityCompanyIncidentNumber', DisplayName: 'Incident Number', Type: 'Text' },
        { InternalName: 'UtilityId', DisplayName: 'Utility Id', Type: 'Text' },
        { InternalName: 'UtilityPersonnelReporting', DisplayName: 'Person Placing Report', Type: 'Person' },
        { InternalName: 'UtilityPersonnelPhone', DisplayName: 'Reported By Phone', Type: 'Text' },
        { InternalName: 'UtilityPersonnelEmail', DisplayName: 'Reported By Email', Type: 'Text' },
        { InternalName: 'AddressIncidentOccurred', DisplayName: 'Location of Incident', Type: 'Text' },
        { InternalName: 'CountyIncidentOccurred', DisplayName: 'County Incident Occurred', Type: 'Text' },
        { InternalName: 'LatitudeEquipmentImpacted', DisplayName: 'Incident Location Latitude', Type: 'Text' },
        { InternalName: 'LongitudeEquipmentImpacted', DisplayName: 'Incident Location Longitude', Type: 'Text' },
        { InternalName: 'TownLocalityIncidentOccurred', DisplayName: 'Town Locality Incident Occurred', Type: 'Text' },
        { InternalName: 'DecSpill_x0023_', DisplayName: 'NYSDEC (800-457-7362) Spill #', Type: 'Text' },
        { InternalName: 'T_x0023_orD_x0023_', DisplayName: 'T# or D#', Type: 'Text' },
        { InternalName: 'AgencyNotified', DisplayName: 'Other Agencies', Type: 'Text' },
        { InternalName: 'SpillOccurredDt', DisplayName: 'Spill Discovered Date', Type: 'Date' },
        { InternalName: 'SpillReportedDt', DisplayName: 'Spill Reported Date', Type: 'Date' },
        { InternalName: 'MaterialTypeSpilled', DisplayName: 'Material Type Spilled', Type: 'Text' },
        { InternalName: 'ReasonforSpill', DisplayName: 'Reason for Spill', Type: 'Text' },
        { InternalName: 'SpillQuantity', DisplayName: 'Spill Quantity', Type: 'Text' },
        { InternalName: 'SpillQuantityUnit', DisplayName: 'Quantity Spilled Units', Type: 'Text' },
        { InternalName: 'PCBDetermination', DisplayName: 'PCB Determination', Type: 'Text' },
        { InternalName: 'PCMDeterminationMEthod', DisplayName: 'PCM Determination Method', Type: 'Text' },
        { InternalName: 'PCMDeterminationComments', DisplayName: 'PCM Determination Comments', Type: 'Text' },
        { InternalName: 'TransformCapitalMonthYear', DisplayName: 'Transform Capital Month Year', Type: 'Text' },
        { InternalName: 'PolePadVehicleNumber', DisplayName: 'Pole/Pad/Vehicle #', Type: 'Text' },
        { InternalName: 'FacilityType', DisplayName: 'Facility Type', Type: 'Text' },
        { InternalName: 'SpillDescription', DisplayName: 'Spill Description', Type: 'Text' },
        { InternalName: 'UpdatedSpillDesc', DisplayName: 'Updated Spill Description', Type: 'Text' },
        { InternalName: 'EmergencyMeasure', DisplayName: 'Emergency Measure', Type: 'Text' },
        { InternalName: 'RecoverdMaterialQty', DisplayName: 'Quantity of Recovered Material', Type: 'Text' },
        { InternalName: 'HazardtoHuman', DisplayName: 'Hazard to Human', Type: 'Text' },
        { InternalName: 'CHGEForemanonSite', DisplayName: 'CHGE Foreman on Site', Type: 'Text' },
        { InternalName: 'CHGEForemanonSitePhone', DisplayName: 'CHGE Foreman on Site Phone', Type: 'Text' },
        { InternalName: 'EnvironmentalSOC', DisplayName: 'Environmental SOC', Type: 'Text' },
        { InternalName: 'EnvironmentalCleanupContractor', DisplayName: 'Environmental Cleanup Contractor', Type: 'Text' },
        { InternalName: 'ContractorOnSiteDt', DisplayName: 'Contractor on Site Date', Type: 'Date' },
        { InternalName: 'EnvironmentalComments', DisplayName: 'Environmental Comments', Type: 'Text' },
        { InternalName: 'OperatingDistrict', DisplayName: 'Operating District', Type: 'Text' },
        { InternalName: 'TransformerNum', DisplayName: 'Transformer S/N', Type: 'Text' },
        { InternalName: 'InjuriesSustained', DisplayName: 'Injuries Sustained', Type: 'Text' },
        { InternalName: 'ClearofStreamsPonds', DisplayName: 'Clear of Streams, Ponds', Type: 'YesNo' }
    ];

    public static GTMO = [
        { InternalName: 'UtilityName', DisplayName: 'Utility Name', Type: 'Text' },
        { InternalName: 'ID', DisplayName: 'ID', Type: 'Text' },
        { InternalName: 'Attachments', DisplayName: 'Attachments', Type: 'YesNo' },
        { InternalName: 'AttachmentFiles', DisplayName: 'Attachment Files', Type: 'Text' },
        { InternalName: 'UtilityCompanyIncidentNumber', DisplayName: 'Mark Out ID', Type: 'Text' },
        { InternalName: 'IncVersion', DisplayName: 'Version', Type: 'Text' },
        { InternalName: 'IsLatestVersion', DisplayName: 'Is Latest Version', Type: 'YesNo' },
        { InternalName: 'IncReportStatus', DisplayName: 'Status', Type: 'Text' },
        { InternalName: 'LockStatus', DisplayName: 'Lock Status', Type: 'Text' },
        { InternalName: 'SubmittedDate', DisplayName: 'Time Submitted', Type: 'Date' },
        { InternalName: 'Modified', DisplayName: 'Modified', Type: 'Date' },
        { InternalName: 'Title', DisplayName: 'Title', Type: 'Text' },
        { InternalName: 'Editor', DisplayName: 'Editor', Type: 'Person' },
        { InternalName: 'LastEditedBy', DisplayName: 'Last Edited By', Type: 'Person' },
        { InternalName: 'UtilityPersonnelReporting', DisplayName: 'Person Placing Report', Type: 'Text' },
        { InternalName: 'UtilityPersonnelPhone', DisplayName: 'Contact Phone', Type: 'Text' },
        { InternalName: 'LineDesignation', DisplayName: 'Line Designation', Type: 'Text' },
        { InternalName: 'CHDivision', DisplayName: 'CH Division', Type: 'Text' },
        { InternalName: 'FormCompletedBy', DisplayName: 'Form Completed By', Type: 'Person' },
        { InternalName: 'FormCompletedByDt', DisplayName: 'Time Form Completed', Type: 'Date' },
        { InternalName: 'SupervisorNotified', DisplayName: 'Supervisor Notified', Type: 'Text' },
        { InternalName: 'SupervisorNotifiedDt', DisplayName: 'Time Supervisor Notified', Type: 'Date' },
        { InternalName: 'FollowUpComments', DisplayName: 'Follow Up Comments', Type: 'Text' },
    ];

    public static GL45 = [
        { InternalName: 'UtilityName', DisplayName: 'Utility Name', Type: 'Text' },
        { InternalName: 'UtilityCompanyIncidentNumber', DisplayName: 'Incident Number', Type: 'Text' },
        { InternalName: 'ID', DisplayName: 'ID', Type: 'Text' },
        { InternalName: 'Attachments', DisplayName: 'Attachments', Type: 'YesNo' },
        { InternalName: 'AttachmentFiles', DisplayName: 'AttachmentFiles', Type: 'Text' },
        { InternalName: 'IncVersion', DisplayName: 'Incident Version', Type: 'Text' },
        { InternalName: 'IsLatestVersion', DisplayName: 'Is Latest Version', Type: 'YesNo' },
        { InternalName: 'IncReportStatus', DisplayName: 'Status', Type: 'Text' },
        { InternalName: 'LockStatus', DisplayName: 'Lock Status', Type: 'Text' },
        { InternalName: 'SubmittedDate', DisplayName: 'Time Submitted', Type: 'Date' },
        { InternalName: 'Modified', DisplayName: 'Modified', Type: 'Date' },
        { InternalName: 'Title', DisplayName: 'Title', Type: 'Text' },
        { InternalName: 'Editor', DisplayName: 'Editor', Type: 'Person' },
        { InternalName: 'LastEditedBy', DisplayName: 'Last Edited By', Type: 'Person' },        
        { InternalName: 'UtilityPersonnelReporting', DisplayName: 'Person Placing Report', Type: 'Person' },
        { InternalName: 'UtilityPersonnelPhone', DisplayName: 'Reported By Phone', Type: 'Text' },
        { InternalName: 'UtilityPersonnelEmail', DisplayName: 'Reported By Email', Type: 'Text' },
        { InternalName: 'CHDivision', DisplayName: 'CH Division', Type: 'Text' },
        { InternalName: 'CustomerName', DisplayName: 'Customer Name', Type: 'Text' },
        { InternalName: 'CustomerAddress', DisplayName: 'Customer Address', Type: 'Text' },
        { InternalName: 'CustomerTownZip', DisplayName: 'Customer Town Zip', Type: 'Text' },
        { InternalName: 'DispatchGasOrderNumber', DisplayName: 'Dispatch Gas Order Number', Type: 'Text' },
        { InternalName: 'OrderRecievedDt', DisplayName: 'Order Received Time', Type: 'Date' },
        { InternalName: 'CallReceived', DisplayName: 'Order Received By', Type: 'Text' },
        { InternalName: 'EmployeeDispatchedDt', DisplayName: 'Dispatched Time', Type: 'Date' },
        { InternalName: 'EmployeeNumber', DisplayName: 'Employee Dispatched', Type: 'Text' },
        { InternalName: 'SupervisorAssigned', DisplayName: 'Supervisor Assigned', Type: 'Text' },
        { InternalName: 'FirstQualifiedUtilityDt', DisplayName: 'First Qualified Utility Personnel Arrival Date', Type: 'Date' },
        { InternalName: 'MadeSafeDt', DisplayName: 'Made Safe Date', Type: 'Date' },        
        { InternalName: 'ReceivedTimetoDispatch', DisplayName: 'Calc. Received Time to Dispatch Time (Minutes)', Type: 'Number' },
        { InternalName: 'ReceivedTimetoArrive', DisplayName: 'Calc. Received Time to Arrive Time (Minutes)', Type: 'Number' },
        { InternalName: 'WhyResponsemorethan45', DisplayName: 'Why Response was not under 45 Minutes', Type: 'Text' },        
        { InternalName: 'RecommendtoRemedy', DisplayName: 'Recommendation to Remedy Incident', Type: 'Text' },
        { InternalName: 'SupervisorNotAssignWhy', DisplayName: 'Supervisor Assigned? (If not, explain)', Type: 'Text' }
    ];

    public static GL60 = [
        { InternalName: 'UtilityName', DisplayName: 'Utility Name', Type: 'Text' },
        { InternalName: 'UtilityCompanyIncidentNumber', DisplayName: 'Incident Number', Type: 'Text' },
        { InternalName: 'ID', DisplayName: 'ID', Type: 'Text' },
        { InternalName: 'Attachments', DisplayName: 'Attachments', Type: 'YesNo' },
        { InternalName: 'AttachmentFiles', DisplayName: 'Attachment Files', Type: 'Text' },
        { InternalName: 'IncVersion', DisplayName: 'Incident Version', Type: 'Text' },
        { InternalName: 'IsLatestVersion', DisplayName: 'Is Latest Version', Type: 'YesNo' },
        { InternalName: 'IncReportStatus', DisplayName: 'Status', Type: 'Text' },
        { InternalName: 'LockStatus', DisplayName: 'Lock Status', Type: 'Text' },
        { InternalName: 'SubmittedDate', DisplayName: 'Time Submitted', Type: 'Date' },
        { InternalName: 'Modified', DisplayName: 'Modified', Type: 'Date' },
        { InternalName: 'Title', DisplayName: 'Title', Type: 'Text' },
        { InternalName: 'Editor', DisplayName: 'Editor', Type: 'Person' },
        { InternalName: 'LastEditedBy', DisplayName: 'Last Edited By', Type: 'Person' },       
        { InternalName: 'UtilityPersonnelReporting', DisplayName: 'Person Placing Report', Type: 'Person' },
        { InternalName: 'UtilityPersonnelPhone', DisplayName: 'Reported By Phone', Type: 'Text' },
        { InternalName: 'UtilityPersonnelEmail', DisplayName: 'Reported By Email', Type: 'Text' },
        { InternalName: 'CHDivision', DisplayName: 'CH Division', Type: 'Text' },
        { InternalName: 'CustomerName', DisplayName: 'Customer Name', Type: 'Text' },
        { InternalName: 'CustomerAddress', DisplayName: 'Customer Address', Type: 'Text' },
        { InternalName: 'CustomerTownZip', DisplayName: 'Customer Town Zip', Type: 'Text' },
        { InternalName: 'DispatchGasOrderNumber', DisplayName: 'Dispatch Gas Order Number', Type: 'Text' },
        { InternalName: 'OrderRecievedDt', DisplayName: 'Order Received Time', Type: 'Date' },
        { InternalName: 'CallReceived', DisplayName: 'Order Received By', Type: 'Text' },
        { InternalName: 'EmployeeDispatchedDt', DisplayName: 'Dispatched Time', Type: 'Date' },
        { InternalName: 'EmployeeDispatched', DisplayName: 'Employee Dispatched', Type: 'Text' },
        { InternalName: 'SupervisorAssigned', DisplayName: 'Supervisor Assigned', Type: 'Text' },
        { InternalName: 'FirstQualifiedUtilityDt', DisplayName: 'Date and Time First Qualified Utility Personnel on scene', Type: 'Date' },
        { InternalName: 'MadeSafeDt', DisplayName: 'Made Safe Date', Type: 'Date' },        
        { InternalName: 'ReceivedTimetoDispatch', DisplayName: 'Calc. Received Time to Dispatch Time (Minutes)', Type: 'Number' },
        { InternalName: 'ReceivedTimetoArrive', DisplayName: 'Calc. Received Time to Arrive Time (Minutes)', Type: 'Number' },
        { InternalName: 'WhyResponsemorethan60', DisplayName: 'Why Response was not under 60 Minutes', Type: 'Text' },        
        { InternalName: 'RecommendtoRemedy', DisplayName: 'Recommendation to Remedy Incident', Type: 'Text' },
        { InternalName: 'SupervisorNotAssignWhy', DisplayName: 'Supervisor Assigned? (If not, explain)', Type: 'Text' }
    ];

    public static SAF = [
        { InternalName: 'UtilityName', DisplayName: 'Utility Name', Type: 'Text' },
        { InternalName: 'ID', DisplayName: 'ID', Type: 'Text' },
        { InternalName: 'Attachments', DisplayName: 'Attachments', Type: 'YesNo' },
        { InternalName: 'AttachmentFiles', DisplayName: 'AttachmentFiles', Type: 'Text' },
        { InternalName: 'UtilityCompanyIncidentNumber', DisplayName: 'Incident Number', Type: 'Text' },
        { InternalName: 'IncVersion', DisplayName: 'Incident Version', Type: 'Text' },
        { InternalName: 'IsLatestVersion', DisplayName: 'Is Latest Version', Type: 'YesNo' },
        { InternalName: 'IncReportStatus', DisplayName: 'Status', Type: 'Text' },
        { InternalName: 'LockStatus', DisplayName: 'Lock Status', Type: 'Text' },
        { InternalName: 'SafetyReportType', DisplayName: 'Safety Report Type', Type: 'Text' },
        { InternalName: 'SubmittedDate', DisplayName: 'Time Submitted', Type: 'Date' },
        { InternalName: 'Modified', DisplayName: 'Modified', Type: 'Date' },
        { InternalName: 'Title', DisplayName: 'Title', Type: 'Text' },
        { InternalName: 'Editor', DisplayName: 'Editor', Type: 'Person' },
        { InternalName: 'LastEditedBy', DisplayName: 'Last Edited By', Type: 'Person' },
        { InternalName: 'UtilityPersonnelReporting', DisplayName: 'Person Placing Report', Type: 'Person' },
        { InternalName: 'UtilityPersonnelPhone', DisplayName: 'Reported By Phone', Type: 'Text' },
        { InternalName: 'IncidentOccurredDt', DisplayName: 'Time Incident Occurred', Type: 'Date' },
        { InternalName: 'IncidentReportDt', DisplayName: 'Incident Report Time', Type: 'Date' },
        { InternalName: 'AddressIncidentOccurred', DisplayName: 'Location of Incident', Type: 'Text' },
        { InternalName: 'ClosestCrossStreetToIncident', DisplayName: 'Location Description/Cross Street', Type: 'Text' },
        { InternalName: 'TownLocalityIncidentOccurred', DisplayName: 'Town/Locality Incident Occurred', Type: 'Text' },
        { InternalName: 'CountyIncidentOccurred', DisplayName: 'County Incident Occurred', Type: 'Text' },
        { InternalName: 'InjuryDescription', DisplayName: 'Injury Description', Type: 'Text' },
        { InternalName: 'IncidentDescription', DisplayName: 'Incident Description', Type: 'Text' },
        { InternalName: 'EmployeeDepartment', DisplayName: 'Employee Department', Type: 'Text' },
        { InternalName: 'EmployeePriClass', DisplayName: 'Employee Pri Class', Type: 'Text' },
        { InternalName: 'SafetyDeptPersonnel', DisplayName: 'Safety Dept Personnel', Type: 'Text' },
        { InternalName: 'SupervisorName', DisplayName: 'Supervisor Name', Type: 'Text' },
        { InternalName: 'SupervisorPhone', DisplayName: 'Supervisor Phone', Type: 'Text' },
        { InternalName: 'ReportUpdateDt', DisplayName: 'Report Update Time', Type: 'Date' },
        { InternalName: 'ReportUpdateDesc', DisplayName: 'Report Update Description', Type: 'Text' }        
    ];

    public static DOT = [
        { InternalName: 'UtilityName', DisplayName: 'Utility Name', Type: 'Text' },
        { InternalName: 'UtilityCompanyIncidentNumber', DisplayName: 'Incident Number', Type: 'Text' },       
        { InternalName: 'ID', DisplayName: 'ID', Type: 'Text' },
        { InternalName: 'Attachments', DisplayName: 'Attachments', Type: 'YesNo' },
        { InternalName: 'AttachmentFiles', DisplayName: 'Attachment Files', Type: 'Text' },
        { InternalName: 'IncVersion', DisplayName: 'Incident Version', Type: 'Text' },
        { InternalName: 'IsLatestVersion', DisplayName: 'Is Latest Version', Type: 'YesNo' },
        { InternalName: 'IncReportStatus', DisplayName: 'Status', Type: 'Text' },
        { InternalName: 'LockStatus', DisplayName: 'Lock Status', Type: 'Text' },
        { InternalName: 'SubmittedDate', DisplayName: 'Time Submitted', Type: 'Date' },
        { InternalName: 'Modified', DisplayName: 'Modified', Type: 'Date' },
        { InternalName: 'Title', DisplayName: 'Title', Type: 'Text' },
        { InternalName: 'Editor', DisplayName: 'Editor', Type: 'Person' },
        { InternalName: 'LastEditedBy', DisplayName: 'Last Edited By', Type: 'Person' },        
        { InternalName: 'UtilityPersonnelReporting', DisplayName: 'Person Placing Report', Type: 'Person' },
        { InternalName: 'UtilityPersonnelPhone', DisplayName: 'Reported By Phone', Type: 'Text' },
        { InternalName: 'UtilityPersonnelEmail', DisplayName: 'Reported By Email', Type: 'Text' },
        { InternalName: 'AddressIncidentOccurred', DisplayName: 'Location of Incident', Type: 'Text' },
        { InternalName: 'ClosestCrossStreetToIncident', DisplayName: 'Location Description/Cross Street', Type: 'Text' },
        { InternalName: 'CountyIncidentOccurred', DisplayName: 'County Incident Occurred', Type: 'Text' },
        { InternalName: 'IncidentDescription', DisplayName: 'Incident Description', Type: 'Text' },
        { InternalName: 'IncidentOccurredDt', DisplayName: 'Time Incident Occurred', Type: 'Date' },
        { InternalName: 'UtilityReportedDt', DisplayName: 'Time Utility Notified of Incident', Type: 'Date' },
        { InternalName: 'LatitudeEquipmentImpacted', DisplayName: 'Incident Location Latitude', Type: 'Text' },
        { InternalName: 'LongitudeEquipmentImpacted', DisplayName: 'Incident Location Longitude', Type: 'Text' },
        { InternalName: 'ServicesInterruptedCount', DisplayName: 'Estimated Number of Services Interrupted', Type: 'Number' },
        { InternalName: 'TownLocalityIncidentOccurred', DisplayName: 'Town/Locality Incident Occurred', Type: 'Text' },
        { InternalName: 'DOTTroubleDispatch', DisplayName: 'Order Number', Type: 'Date' },
        { InternalName: 'Mediacoverage', DisplayName: 'Media coverage', Type: 'Text' },
        { InternalName: 'DispatchDt', DisplayName: 'Crew Dispatch Time', Type: 'Date' },
        { InternalName: 'CrewArrivalDt', DisplayName: 'Crew Arrival Time', Type: 'Date' },
        { InternalName: 'MadeSafeDt', DisplayName: 'Made Safe Time', Type: 'Date' },
        { InternalName: 'EmployeePriClass', DisplayName: 'DOT Contact Receiving Report', Type: 'Text' },
        { InternalName: 'DOTReportDt', DisplayName: 'Time of Dot Notification', Type: 'Date' },
        { InternalName: 'DOTReportNumber', DisplayName: 'DOT Report Number', Type: 'Text' },
        { InternalName: 'ReportUpdateDt', DisplayName: 'Report Update Time', Type: 'Date' },
        { InternalName: 'ReportUpdateDesc', DisplayName: 'Report Update Description', Type: 'Text' }
    ];

    public static EMAILCONFIG = [
        { InternalName: 'Title', DisplayName: 'Title', Type: 'Text' },
        { InternalName: 'To', DisplayName: 'To', Type: 'Text' }
    ];
}

export class EXPANDFIELDS {
    public static PSCE: string[] = ["Editor", "UtilityPersonnelReporting", "AttachmentFiles", "LastEditedBy"];
    public static PSCG: string[] = ["Editor", "UtilityPersonnelReporting", "AttachmentFiles", "LastEditedBy"];
    public static TSA: string[] = ["Editor", "UtilityPersonnelReporting", "AttachmentFiles", "LastEditedBy"];
    public static SPL: string[] = ["Editor", "UtilityPersonnelReporting", "AttachmentFiles", "LastEditedBy"];
    public static GTMO: string[] = ["Editor", "AttachmentFiles", "FormCompletedBy", "LastEditedBy"];
    public static GL45: string[] = ["Editor", "UtilityPersonnelReporting", "AttachmentFiles", "LastEditedBy"];
    public static GL60: string[] = ["Editor", "UtilityPersonnelReporting", "AttachmentFiles", "LastEditedBy"];
    public static SAF: string[] = ["Editor", "UtilityPersonnelReporting", "AttachmentFiles", "LastEditedBy"];
    public static DOT: string[] = ["Editor", "UtilityPersonnelReporting", "AttachmentFiles", "LastEditedBy"];
}